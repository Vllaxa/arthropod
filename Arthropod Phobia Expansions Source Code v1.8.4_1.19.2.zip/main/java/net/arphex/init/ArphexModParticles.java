
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.arphex.client.particle.TinySpiderParticle;
import net.arphex.client.particle.TinyMothParticle;
import net.arphex.client.particle.ThinWebParticle;
import net.arphex.client.particle.SpiderBloodParticle;
import net.arphex.client.particle.SolidSmokeParticle;
import net.arphex.client.particle.RopeWebParticle;
import net.arphex.client.particle.HeavySmokeParticle;
import net.arphex.client.particle.HeavyRedSmokeParticle;
import net.arphex.client.particle.GhostTeleportParticle;
import net.arphex.client.particle.CharredBloodParticle;
import net.arphex.client.particle.CharcoalParticle;
import net.arphex.client.particle.AbyssalCrystalParticleParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ArphexModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.register(ArphexModParticleTypes.HEAVY_SMOKE.get(), HeavySmokeParticle::provider);
		event.register(ArphexModParticleTypes.THIN_WEB.get(), ThinWebParticle::provider);
		event.register(ArphexModParticleTypes.CHARCOAL.get(), CharcoalParticle::provider);
		event.register(ArphexModParticleTypes.CHARRED_BLOOD.get(), CharredBloodParticle::provider);
		event.register(ArphexModParticleTypes.TINY_SPIDER.get(), TinySpiderParticle::provider);
		event.register(ArphexModParticleTypes.SOLID_SMOKE.get(), SolidSmokeParticle::provider);
		event.register(ArphexModParticleTypes.ABYSSAL_CRYSTAL_PARTICLE.get(), AbyssalCrystalParticleParticle::provider);
		event.register(ArphexModParticleTypes.HEAVY_RED_SMOKE.get(), HeavyRedSmokeParticle::provider);
		event.register(ArphexModParticleTypes.ROPE_WEB.get(), RopeWebParticle::provider);
		event.register(ArphexModParticleTypes.TINY_MOTH.get(), TinyMothParticle::provider);
		event.register(ArphexModParticleTypes.GHOST_TELEPORT.get(), GhostTeleportParticle::provider);
		event.register(ArphexModParticleTypes.SPIDER_BLOOD.get(), SpiderBloodParticle::provider);
	}
}
