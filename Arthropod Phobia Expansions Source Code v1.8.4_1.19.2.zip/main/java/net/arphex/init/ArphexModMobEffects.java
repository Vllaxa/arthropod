
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.arphex.potion.WebbedMobEffect;
import net.arphex.potion.ThunderSenseMobEffect;
import net.arphex.potion.SpiderSilkTouchMobEffect;
import net.arphex.potion.NecrosisMobEffect;
import net.arphex.potion.MothCurseMobEffect;
import net.arphex.potion.AbyssalDetectorMobEffect;
import net.arphex.ArphexMod;

public class ArphexModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ArphexMod.MODID);
	public static final RegistryObject<MobEffect> MOTH_CURSE = REGISTRY.register("moth_curse", () -> new MothCurseMobEffect());
	public static final RegistryObject<MobEffect> SPIDER_SILK_TOUCH = REGISTRY.register("spider_silk_touch", () -> new SpiderSilkTouchMobEffect());
	public static final RegistryObject<MobEffect> WEBBED = REGISTRY.register("webbed", () -> new WebbedMobEffect());
	public static final RegistryObject<MobEffect> ABYSSAL_DETECTOR = REGISTRY.register("abyssal_detector", () -> new AbyssalDetectorMobEffect());
	public static final RegistryObject<MobEffect> NECROSIS = REGISTRY.register("necrosis", () -> new NecrosisMobEffect());
	public static final RegistryObject<MobEffect> THUNDER_SENSE = REGISTRY.register("thunder_sense", () -> new ThunderSenseMobEffect());
}
