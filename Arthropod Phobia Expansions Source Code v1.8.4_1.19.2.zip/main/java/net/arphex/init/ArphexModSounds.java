
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.arphex.ArphexMod;

public class ArphexModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ArphexMod.MODID);
	public static final RegistryObject<SoundEvent> MOTHSCARE = REGISTRY.register("mothscare", () -> new SoundEvent(new ResourceLocation("arphex", "mothscare")));
	public static final RegistryObject<SoundEvent> MOTHCHASE = REGISTRY.register("mothchase", () -> new SoundEvent(new ResourceLocation("arphex", "mothchase")));
	public static final RegistryObject<SoundEvent> MOTHCHASE2 = REGISTRY.register("mothchase2", () -> new SoundEvent(new ResourceLocation("arphex", "mothchase2")));
	public static final RegistryObject<SoundEvent> SPIDERMOTHAMBIENT = REGISTRY.register("spidermothambient", () -> new SoundEvent(new ResourceLocation("arphex", "spidermothambient")));
	public static final RegistryObject<SoundEvent> HEARTBEATS = REGISTRY.register("heartbeats", () -> new SoundEvent(new ResourceLocation("arphex", "heartbeats")));
	public static final RegistryObject<SoundEvent> TELEPORTERMOTH = REGISTRY.register("teleportermoth", () -> new SoundEvent(new ResourceLocation("arphex", "teleportermoth")));
	public static final RegistryObject<SoundEvent> MOTHSCREAM = REGISTRY.register("mothscream", () -> new SoundEvent(new ResourceLocation("arphex", "mothscream")));
	public static final RegistryObject<SoundEvent> MOTHSCREAM2 = REGISTRY.register("mothscream2", () -> new SoundEvent(new ResourceLocation("arphex", "mothscream2")));
	public static final RegistryObject<SoundEvent> HORRORCRASH = REGISTRY.register("horrorcrash", () -> new SoundEvent(new ResourceLocation("arphex", "horrorcrash")));
	public static final RegistryObject<SoundEvent> CREEPY_ARTHROPOD_TINY = REGISTRY.register("creepy_arthropod_tiny", () -> new SoundEvent(new ResourceLocation("arphex", "creepy_arthropod_tiny")));
	public static final RegistryObject<SoundEvent> CREEPY_ARTHROPOD = REGISTRY.register("creepy_arthropod", () -> new SoundEvent(new ResourceLocation("arphex", "creepy_arthropod")));
	public static final RegistryObject<SoundEvent> CREEPY_ARTHROPOD_LARGE = REGISTRY.register("creepy_arthropod_large", () -> new SoundEvent(new ResourceLocation("arphex", "creepy_arthropod_large")));
	public static final RegistryObject<SoundEvent> RHINOBEETLEFLY = REGISTRY.register("rhinobeetlefly", () -> new SoundEvent(new ResourceLocation("arphex", "rhinobeetlefly")));
	public static final RegistryObject<SoundEvent> FLYINGMOTH1 = REGISTRY.register("flyingmoth1", () -> new SoundEvent(new ResourceLocation("arphex", "flyingmoth1")));
	public static final RegistryObject<SoundEvent> FLYINGMOTH2 = REGISTRY.register("flyingmoth2", () -> new SoundEvent(new ResourceLocation("arphex", "flyingmoth2")));
	public static final RegistryObject<SoundEvent> SPIDERMOTHCROAK = REGISTRY.register("spidermothcroak", () -> new SoundEvent(new ResourceLocation("arphex", "spidermothcroak")));
	public static final RegistryObject<SoundEvent> HORNETBUZZLONG = REGISTRY.register("hornetbuzzlong", () -> new SoundEvent(new ResourceLocation("arphex", "hornetbuzzlong")));
	public static final RegistryObject<SoundEvent> HORNETBUZZSHORT = REGISTRY.register("hornetbuzzshort", () -> new SoundEvent(new ResourceLocation("arphex", "hornetbuzzshort")));
}
