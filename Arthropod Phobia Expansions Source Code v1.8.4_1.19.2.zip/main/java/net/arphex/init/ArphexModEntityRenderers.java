
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.arphex.client.renderer.WebHarnessRenderer;
import net.arphex.client.renderer.WebFunnelRenderer;
import net.arphex.client.renderer.WaterRoachRenderer;
import net.arphex.client.renderer.TinyCentipedeBreacherRenderer;
import net.arphex.client.renderer.TeleportGhostRenderer;
import net.arphex.client.renderer.TamedTarantulaRenderer;
import net.arphex.client.renderer.SunScorpionTinyRenderer;
import net.arphex.client.renderer.SunScorpionRenderer;
import net.arphex.client.renderer.SpiderWidowRenderer;
import net.arphex.client.renderer.SpiderMothLarvaeRenderer;
import net.arphex.client.renderer.SpiderMothDwellerRenderer;
import net.arphex.client.renderer.SpiderLurkerRenderer;
import net.arphex.client.renderer.SpiderLarvaeTinyRenderer;
import net.arphex.client.renderer.SpiderLarvaeRenderer;
import net.arphex.client.renderer.SpiderGoliathRenderer;
import net.arphex.client.renderer.SpiderFunnelRenderer;
import net.arphex.client.renderer.SpiderFlatRenderer;
import net.arphex.client.renderer.SpiderBroodRenderer;
import net.arphex.client.renderer.SkyStalkerRenderer;
import net.arphex.client.renderer.SilverfishSpectreRenderer;
import net.arphex.client.renderer.RushScareRenderer;
import net.arphex.client.renderer.PureStalkingRenderer;
import net.arphex.client.renderer.MothShadowCloneRenderer;
import net.arphex.client.renderer.MaggotRenderer;
import net.arphex.client.renderer.LongLegsTinyRenderer;
import net.arphex.client.renderer.LongLegsRenderer;
import net.arphex.client.renderer.InvisibleStalkerRenderer;
import net.arphex.client.renderer.HornetHarbingerRenderer;
import net.arphex.client.renderer.HornetHarbingerGiantRenderer;
import net.arphex.client.renderer.DwellerSleepSpawnerRenderer;
import net.arphex.client.renderer.CentipedeStalkerRenderer;
import net.arphex.client.renderer.CentipedeEvictorRenderer;
import net.arphex.client.renderer.CentipedeEvictorLarvaeRenderer;
import net.arphex.client.renderer.BloodWormRenderer;
import net.arphex.client.renderer.BeetleTickMiteRenderer;
import net.arphex.client.renderer.BeetleRhinoRenderer;
import net.arphex.client.renderer.AntGiantRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ArphexModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ArphexModEntities.BLOOD_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_MOTH_DWELLER.get(), SpiderMothDwellerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_MOTH_LARVAE.get(), SpiderMothLarvaeRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.TELEPORT_GHOST.get(), TeleportGhostRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.MOTH_SHADOW_CLONE.get(), MothShadowCloneRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_LARVAE.get(), SpiderLarvaeRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_LARVAE_TINY.get(), SpiderLarvaeTinyRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SUN_SCORPION.get(), SunScorpionRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SUN_SCORPION_TINY.get(), SunScorpionTinyRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.LONG_LEGS.get(), LongLegsRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.LONG_LEGS_TINY.get(), LongLegsTinyRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.DWELLER_SLEEP_SPAWNER.get(), DwellerSleepSpawnerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.CENTIPEDE_STALKER.get(), CentipedeStalkerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.MAGGOT.get(), MaggotRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.BLOOD_WORM.get(), BloodWormRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.WATER_ROACH.get(), WaterRoachRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.BEETLE_TICK_MITE.get(), BeetleTickMiteRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.PURE_STALKING.get(), PureStalkingRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.RUSH_SCARE.get(), RushScareRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_BROOD.get(), SpiderBroodRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_BROOD_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SKY_STALKER.get(), SkyStalkerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_WIDOW.get(), SpiderWidowRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_FLAT.get(), SpiderFlatRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.WEBBED_ARROW.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.ANT_GIANT.get(), AntGiantRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.CENTIPEDE_EVICTOR.get(), CentipedeEvictorRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.CENTIPEDE_EVICTOR_LARVAE.get(), CentipedeEvictorLarvaeRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.TINY_CENTIPEDE_BREACHER.get(), TinyCentipedeBreacherRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_LURKER.get(), SpiderLurkerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.INVISIBLE_STALKER.get(), InvisibleStalkerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_FUNNEL.get(), SpiderFunnelRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.WEB_HOOK.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.WEB_HARNESS.get(), WebHarnessRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.WEB_ROPE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.WEB_FUNNEL.get(), WebFunnelRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SPIDER_GOLIATH.get(), SpiderGoliathRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.SILVERFISH_SPECTRE.get(), SilverfishSpectreRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.BEETLE_RHINO.get(), BeetleRhinoRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.POWER_HOOK.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.TAMED_TARANTULA.get(), TamedTarantulaRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.HORNET_HARBINGER.get(), HornetHarbingerRenderer::new);
		event.registerEntityRenderer(ArphexModEntities.HORNET_HARBINGER_GIANT.get(), HornetHarbingerGiantRenderer::new);
	}
}
