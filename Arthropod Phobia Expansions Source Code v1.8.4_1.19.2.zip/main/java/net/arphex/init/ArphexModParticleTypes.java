
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.arphex.ArphexMod;

public class ArphexModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, ArphexMod.MODID);
	public static final RegistryObject<SimpleParticleType> HEAVY_SMOKE = REGISTRY.register("heavy_smoke", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> THIN_WEB = REGISTRY.register("thin_web", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> CHARCOAL = REGISTRY.register("charcoal", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> CHARRED_BLOOD = REGISTRY.register("charred_blood", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> TINY_SPIDER = REGISTRY.register("tiny_spider", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> SOLID_SMOKE = REGISTRY.register("solid_smoke", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> ABYSSAL_CRYSTAL_PARTICLE = REGISTRY.register("abyssal_crystal_particle", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> HEAVY_RED_SMOKE = REGISTRY.register("heavy_red_smoke", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> ROPE_WEB = REGISTRY.register("rope_web", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> TINY_MOTH = REGISTRY.register("tiny_moth", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> GHOST_TELEPORT = REGISTRY.register("ghost_teleport", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> SPIDER_BLOOD = REGISTRY.register("spider_blood", () -> new SimpleParticleType(true));
}
