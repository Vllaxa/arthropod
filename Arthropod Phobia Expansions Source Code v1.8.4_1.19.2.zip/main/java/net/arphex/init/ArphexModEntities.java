
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.arphex.entity.WebbedArrowEntity;
import net.arphex.entity.WebRopeEntity;
import net.arphex.entity.WebHookEntity;
import net.arphex.entity.WebHarnessEntity;
import net.arphex.entity.WebFunnelEntity;
import net.arphex.entity.WaterRoachEntity;
import net.arphex.entity.TinyCentipedeBreacherEntity;
import net.arphex.entity.TeleportGhostEntity;
import net.arphex.entity.TamedTarantulaEntity;
import net.arphex.entity.SunScorpionTinyEntity;
import net.arphex.entity.SunScorpionEntity;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderMothLarvaeEntity;
import net.arphex.entity.SpiderMothDwellerEntity;
import net.arphex.entity.SpiderLurkerEntity;
import net.arphex.entity.SpiderLarvaeTinyEntity;
import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.entity.SpiderGoliathEntity;
import net.arphex.entity.SpiderFunnelEntity;
import net.arphex.entity.SpiderFlatEntity;
import net.arphex.entity.SpiderBroodEntityProjectile;
import net.arphex.entity.SpiderBroodEntity;
import net.arphex.entity.SkyStalkerEntity;
import net.arphex.entity.SilverfishSpectreEntity;
import net.arphex.entity.RushScareEntity;
import net.arphex.entity.PureStalkingEntity;
import net.arphex.entity.PowerHookEntity;
import net.arphex.entity.MothShadowCloneEntity;
import net.arphex.entity.MaggotEntity;
import net.arphex.entity.LongLegsTinyEntity;
import net.arphex.entity.LongLegsEntity;
import net.arphex.entity.InvisibleStalkerEntity;
import net.arphex.entity.HornetHarbingerGiantEntity;
import net.arphex.entity.HornetHarbingerEntity;
import net.arphex.entity.DwellerSleepSpawnerEntity;
import net.arphex.entity.CentipedeStalkerEntity;
import net.arphex.entity.CentipedeEvictorLarvaeEntity;
import net.arphex.entity.CentipedeEvictorEntity;
import net.arphex.entity.BloodWormEntity;
import net.arphex.entity.BloodProjectileEntity;
import net.arphex.entity.BeetleTickMiteEntity;
import net.arphex.entity.BeetleRhinoEntity;
import net.arphex.entity.AntGiantEntity;
import net.arphex.ArphexMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ArphexModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ArphexMod.MODID);
	public static final RegistryObject<EntityType<BloodProjectileEntity>> BLOOD_PROJECTILE = register("projectile_blood_projectile", EntityType.Builder.<BloodProjectileEntity>of(BloodProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(BloodProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SpiderMothDwellerEntity>> SPIDER_MOTH_DWELLER = register("spider_moth_dweller", EntityType.Builder.<SpiderMothDwellerEntity>of(SpiderMothDwellerEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(130).setUpdateInterval(3).setCustomClientFactory(SpiderMothDwellerEntity::new).fireImmune().sized(0.99f, 0.99f));
	public static final RegistryObject<EntityType<SpiderMothLarvaeEntity>> SPIDER_MOTH_LARVAE = register("spider_moth_larvae", EntityType.Builder.<SpiderMothLarvaeEntity>of(SpiderMothLarvaeEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(74).setUpdateInterval(3).setCustomClientFactory(SpiderMothLarvaeEntity::new).fireImmune().sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TeleportGhostEntity>> TELEPORT_GHOST = register("teleport_ghost", EntityType.Builder.<TeleportGhostEntity>of(TeleportGhostEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TeleportGhostEntity::new).fireImmune().sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<MothShadowCloneEntity>> MOTH_SHADOW_CLONE = register("moth_shadow_clone", EntityType.Builder.<MothShadowCloneEntity>of(MothShadowCloneEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(MothShadowCloneEntity::new).fireImmune().sized(5f, 5f));
	public static final RegistryObject<EntityType<SpiderLarvaeEntity>> SPIDER_LARVAE = register("spider_larvae",
			EntityType.Builder.<SpiderLarvaeEntity>of(SpiderLarvaeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderLarvaeEntity::new)

					.sized(0.7f, 0.7f));
	public static final RegistryObject<EntityType<SpiderLarvaeTinyEntity>> SPIDER_LARVAE_TINY = register("spider_larvae_tiny",
			EntityType.Builder.<SpiderLarvaeTinyEntity>of(SpiderLarvaeTinyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderLarvaeTinyEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<SunScorpionEntity>> SUN_SCORPION = register("sun_scorpion", EntityType.Builder.<SunScorpionEntity>of(SunScorpionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SunScorpionEntity::new).fireImmune().sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<SunScorpionTinyEntity>> SUN_SCORPION_TINY = register("sun_scorpion_tiny", EntityType.Builder.<SunScorpionTinyEntity>of(SunScorpionTinyEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SunScorpionTinyEntity::new).fireImmune().sized(0.8f, 0.8f));
	public static final RegistryObject<EntityType<LongLegsEntity>> LONG_LEGS = register("long_legs",
			EntityType.Builder.<LongLegsEntity>of(LongLegsEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LongLegsEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<LongLegsTinyEntity>> LONG_LEGS_TINY = register("long_legs_tiny",
			EntityType.Builder.<LongLegsTinyEntity>of(LongLegsTinyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LongLegsTinyEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<DwellerSleepSpawnerEntity>> DWELLER_SLEEP_SPAWNER = register("dweller_sleep_spawner", EntityType.Builder.<DwellerSleepSpawnerEntity>of(DwellerSleepSpawnerEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DwellerSleepSpawnerEntity::new).fireImmune().sized(0.99f, 3f));
	public static final RegistryObject<EntityType<CentipedeStalkerEntity>> CENTIPEDE_STALKER = register("centipede_stalker",
			EntityType.Builder.<CentipedeStalkerEntity>of(CentipedeStalkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3).setCustomClientFactory(CentipedeStalkerEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<MaggotEntity>> MAGGOT = register("maggot",
			EntityType.Builder.<MaggotEntity>of(MaggotEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(6).setUpdateInterval(3).setCustomClientFactory(MaggotEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<BloodWormEntity>> BLOOD_WORM = register("blood_worm",
			EntityType.Builder.<BloodWormEntity>of(BloodWormEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(60).setUpdateInterval(3).setCustomClientFactory(BloodWormEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<WaterRoachEntity>> WATER_ROACH = register("water_roach", EntityType.Builder.<WaterRoachEntity>of(WaterRoachEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(WaterRoachEntity::new).fireImmune().sized(0.8f, 0.8f));
	public static final RegistryObject<EntityType<BeetleTickMiteEntity>> BEETLE_TICK_MITE = register("beetle_tick_mite",
			EntityType.Builder.<BeetleTickMiteEntity>of(BeetleTickMiteEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BeetleTickMiteEntity::new)

					.sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<PureStalkingEntity>> PURE_STALKING = register("pure_stalking", EntityType.Builder.<PureStalkingEntity>of(PureStalkingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(120).setUpdateInterval(3).setCustomClientFactory(PureStalkingEntity::new).fireImmune().sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<RushScareEntity>> RUSH_SCARE = register("rush_scare", EntityType.Builder.<RushScareEntity>of(RushScareEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(120)
			.setUpdateInterval(3).setCustomClientFactory(RushScareEntity::new).fireImmune().sized(1.9f, 1.9f));
	public static final RegistryObject<EntityType<SpiderBroodEntity>> SPIDER_BROOD = register("spider_brood",
			EntityType.Builder.<SpiderBroodEntity>of(SpiderBroodEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderBroodEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<SpiderBroodEntityProjectile>> SPIDER_BROOD_PROJECTILE = register("projectile_spider_brood", EntityType.Builder.<SpiderBroodEntityProjectile>of(SpiderBroodEntityProjectile::new, MobCategory.MISC)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(SpiderBroodEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SkyStalkerEntity>> SKY_STALKER = register("sky_stalker", EntityType.Builder.<SkyStalkerEntity>of(SkyStalkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(50)
			.setUpdateInterval(3).setCustomClientFactory(SkyStalkerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SpiderWidowEntity>> SPIDER_WIDOW = register("spider_widow",
			EntityType.Builder.<SpiderWidowEntity>of(SpiderWidowEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3).setCustomClientFactory(SpiderWidowEntity::new)

					.sized(1.4f, 1.4f));
	public static final RegistryObject<EntityType<SpiderFlatEntity>> SPIDER_FLAT = register("spider_flat",
			EntityType.Builder.<SpiderFlatEntity>of(SpiderFlatEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3).setCustomClientFactory(SpiderFlatEntity::new)

					.sized(0.95f, 0.95f));
	public static final RegistryObject<EntityType<WebbedArrowEntity>> WEBBED_ARROW = register("projectile_webbed_arrow",
			EntityType.Builder.<WebbedArrowEntity>of(WebbedArrowEntity::new, MobCategory.MISC).setCustomClientFactory(WebbedArrowEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<AntGiantEntity>> ANT_GIANT = register("ant_giant",
			EntityType.Builder.<AntGiantEntity>of(AntGiantEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(20).setUpdateInterval(3).setCustomClientFactory(AntGiantEntity::new)

					.sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<CentipedeEvictorEntity>> CENTIPEDE_EVICTOR = register("centipede_evictor", EntityType.Builder.<CentipedeEvictorEntity>of(CentipedeEvictorEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(60).setUpdateInterval(3).setCustomClientFactory(CentipedeEvictorEntity::new).fireImmune().sized(1.95f, 1.95f));
	public static final RegistryObject<EntityType<CentipedeEvictorLarvaeEntity>> CENTIPEDE_EVICTOR_LARVAE = register("centipede_evictor_larvae",
			EntityType.Builder.<CentipedeEvictorLarvaeEntity>of(CentipedeEvictorLarvaeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(60).setUpdateInterval(3)
					.setCustomClientFactory(CentipedeEvictorLarvaeEntity::new).fireImmune().sized(0.95f, 0.95f));
	public static final RegistryObject<EntityType<TinyCentipedeBreacherEntity>> TINY_CENTIPEDE_BREACHER = register("tiny_centipede_breacher", EntityType.Builder.<TinyCentipedeBreacherEntity>of(TinyCentipedeBreacherEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(60).setUpdateInterval(3).setCustomClientFactory(TinyCentipedeBreacherEntity::new).fireImmune().sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SpiderLurkerEntity>> SPIDER_LURKER = register("spider_lurker",
			EntityType.Builder.<SpiderLurkerEntity>of(SpiderLurkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(60).setUpdateInterval(3).setCustomClientFactory(SpiderLurkerEntity::new)

					.sized(0.99f, 0.99f));
	public static final RegistryObject<EntityType<InvisibleStalkerEntity>> INVISIBLE_STALKER = register("invisible_stalker", EntityType.Builder.<InvisibleStalkerEntity>of(InvisibleStalkerEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(300).setUpdateInterval(3).setCustomClientFactory(InvisibleStalkerEntity::new).fireImmune().sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<SpiderFunnelEntity>> SPIDER_FUNNEL = register("spider_funnel",
			EntityType.Builder.<SpiderFunnelEntity>of(SpiderFunnelEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderFunnelEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<WebHookEntity>> WEB_HOOK = register("projectile_web_hook",
			EntityType.Builder.<WebHookEntity>of(WebHookEntity::new, MobCategory.MISC).setCustomClientFactory(WebHookEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WebHarnessEntity>> WEB_HARNESS = register("web_harness",
			EntityType.Builder.<WebHarnessEntity>of(WebHarnessEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WebHarnessEntity::new).fireImmune().sized(1f, 2f));
	public static final RegistryObject<EntityType<WebRopeEntity>> WEB_ROPE = register("projectile_web_rope",
			EntityType.Builder.<WebRopeEntity>of(WebRopeEntity::new, MobCategory.MISC).setCustomClientFactory(WebRopeEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<WebFunnelEntity>> WEB_FUNNEL = register("web_funnel",
			EntityType.Builder.<WebFunnelEntity>of(WebFunnelEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(50).setUpdateInterval(3).setCustomClientFactory(WebFunnelEntity::new)

					.sized(0.99f, 0.99f));
	public static final RegistryObject<EntityType<SpiderGoliathEntity>> SPIDER_GOLIATH = register("spider_goliath",
			EntityType.Builder.<SpiderGoliathEntity>of(SpiderGoliathEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderGoliathEntity::new)

					.sized(1.4f, 1.4f));
	public static final RegistryObject<EntityType<SilverfishSpectreEntity>> SILVERFISH_SPECTRE = register("silverfish_spectre",
			EntityType.Builder.<SilverfishSpectreEntity>of(SilverfishSpectreEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(20).setUpdateInterval(3).setCustomClientFactory(SilverfishSpectreEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<BeetleRhinoEntity>> BEETLE_RHINO = register("beetle_rhino", EntityType.Builder.<BeetleRhinoEntity>of(BeetleRhinoEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BeetleRhinoEntity::new).fireImmune().sized(0.8f, 0.8f));
	public static final RegistryObject<EntityType<PowerHookEntity>> POWER_HOOK = register("projectile_power_hook",
			EntityType.Builder.<PowerHookEntity>of(PowerHookEntity::new, MobCategory.MISC).setCustomClientFactory(PowerHookEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<TamedTarantulaEntity>> TAMED_TARANTULA = register("tamed_tarantula",
			EntityType.Builder.<TamedTarantulaEntity>of(TamedTarantulaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TamedTarantulaEntity::new)

					.sized(1.2f, 1.2f));
	public static final RegistryObject<EntityType<HornetHarbingerEntity>> HORNET_HARBINGER = register("hornet_harbinger",
			EntityType.Builder.<HornetHarbingerEntity>of(HornetHarbingerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(70).setUpdateInterval(3).setCustomClientFactory(HornetHarbingerEntity::new)

					.sized(0.8f, 0.8f));
	public static final RegistryObject<EntityType<HornetHarbingerGiantEntity>> HORNET_HARBINGER_GIANT = register("hornet_harbinger_giant",
			EntityType.Builder.<HornetHarbingerGiantEntity>of(HornetHarbingerGiantEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(70).setUpdateInterval(3)
					.setCustomClientFactory(HornetHarbingerGiantEntity::new)

					.sized(1f, 1f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SpiderMothDwellerEntity.init();
			SpiderMothLarvaeEntity.init();
			TeleportGhostEntity.init();
			MothShadowCloneEntity.init();
			SpiderLarvaeEntity.init();
			SpiderLarvaeTinyEntity.init();
			SunScorpionEntity.init();
			SunScorpionTinyEntity.init();
			LongLegsEntity.init();
			LongLegsTinyEntity.init();
			DwellerSleepSpawnerEntity.init();
			CentipedeStalkerEntity.init();
			MaggotEntity.init();
			BloodWormEntity.init();
			WaterRoachEntity.init();
			BeetleTickMiteEntity.init();
			PureStalkingEntity.init();
			RushScareEntity.init();
			SpiderBroodEntity.init();
			SkyStalkerEntity.init();
			SpiderWidowEntity.init();
			SpiderFlatEntity.init();
			AntGiantEntity.init();
			CentipedeEvictorEntity.init();
			CentipedeEvictorLarvaeEntity.init();
			TinyCentipedeBreacherEntity.init();
			SpiderLurkerEntity.init();
			InvisibleStalkerEntity.init();
			SpiderFunnelEntity.init();
			WebHarnessEntity.init();
			WebFunnelEntity.init();
			SpiderGoliathEntity.init();
			SilverfishSpectreEntity.init();
			BeetleRhinoEntity.init();
			TamedTarantulaEntity.init();
			HornetHarbingerEntity.init();
			HornetHarbingerGiantEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SPIDER_MOTH_DWELLER.get(), SpiderMothDwellerEntity.createAttributes().build());
		event.put(SPIDER_MOTH_LARVAE.get(), SpiderMothLarvaeEntity.createAttributes().build());
		event.put(TELEPORT_GHOST.get(), TeleportGhostEntity.createAttributes().build());
		event.put(MOTH_SHADOW_CLONE.get(), MothShadowCloneEntity.createAttributes().build());
		event.put(SPIDER_LARVAE.get(), SpiderLarvaeEntity.createAttributes().build());
		event.put(SPIDER_LARVAE_TINY.get(), SpiderLarvaeTinyEntity.createAttributes().build());
		event.put(SUN_SCORPION.get(), SunScorpionEntity.createAttributes().build());
		event.put(SUN_SCORPION_TINY.get(), SunScorpionTinyEntity.createAttributes().build());
		event.put(LONG_LEGS.get(), LongLegsEntity.createAttributes().build());
		event.put(LONG_LEGS_TINY.get(), LongLegsTinyEntity.createAttributes().build());
		event.put(DWELLER_SLEEP_SPAWNER.get(), DwellerSleepSpawnerEntity.createAttributes().build());
		event.put(CENTIPEDE_STALKER.get(), CentipedeStalkerEntity.createAttributes().build());
		event.put(MAGGOT.get(), MaggotEntity.createAttributes().build());
		event.put(BLOOD_WORM.get(), BloodWormEntity.createAttributes().build());
		event.put(WATER_ROACH.get(), WaterRoachEntity.createAttributes().build());
		event.put(BEETLE_TICK_MITE.get(), BeetleTickMiteEntity.createAttributes().build());
		event.put(PURE_STALKING.get(), PureStalkingEntity.createAttributes().build());
		event.put(RUSH_SCARE.get(), RushScareEntity.createAttributes().build());
		event.put(SPIDER_BROOD.get(), SpiderBroodEntity.createAttributes().build());
		event.put(SKY_STALKER.get(), SkyStalkerEntity.createAttributes().build());
		event.put(SPIDER_WIDOW.get(), SpiderWidowEntity.createAttributes().build());
		event.put(SPIDER_FLAT.get(), SpiderFlatEntity.createAttributes().build());
		event.put(ANT_GIANT.get(), AntGiantEntity.createAttributes().build());
		event.put(CENTIPEDE_EVICTOR.get(), CentipedeEvictorEntity.createAttributes().build());
		event.put(CENTIPEDE_EVICTOR_LARVAE.get(), CentipedeEvictorLarvaeEntity.createAttributes().build());
		event.put(TINY_CENTIPEDE_BREACHER.get(), TinyCentipedeBreacherEntity.createAttributes().build());
		event.put(SPIDER_LURKER.get(), SpiderLurkerEntity.createAttributes().build());
		event.put(INVISIBLE_STALKER.get(), InvisibleStalkerEntity.createAttributes().build());
		event.put(SPIDER_FUNNEL.get(), SpiderFunnelEntity.createAttributes().build());
		event.put(WEB_HARNESS.get(), WebHarnessEntity.createAttributes().build());
		event.put(WEB_FUNNEL.get(), WebFunnelEntity.createAttributes().build());
		event.put(SPIDER_GOLIATH.get(), SpiderGoliathEntity.createAttributes().build());
		event.put(SILVERFISH_SPECTRE.get(), SilverfishSpectreEntity.createAttributes().build());
		event.put(BEETLE_RHINO.get(), BeetleRhinoEntity.createAttributes().build());
		event.put(TAMED_TARANTULA.get(), TamedTarantulaEntity.createAttributes().build());
		event.put(HORNET_HARBINGER.get(), HornetHarbingerEntity.createAttributes().build());
		event.put(HORNET_HARBINGER_GIANT.get(), HornetHarbingerGiantEntity.createAttributes().build());
	}
}
