
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.arphex.item.ThunderSensorItem;
import net.arphex.item.TarantulaTetherItem;
import net.arphex.item.SpiderJarItem;
import net.arphex.item.SpiderFlatJarItem;
import net.arphex.item.SlingWebItem;
import net.arphex.item.RoachNymphItem;
import net.arphex.item.PickDisplayItem;
import net.arphex.item.NecroticFangItem;
import net.arphex.item.MantleOfVitalityItem;
import net.arphex.item.MaggotGrubItem;
import net.arphex.item.GiantSpinneretItem;
import net.arphex.item.DaggerOfDissolutionItem;
import net.arphex.item.BucketOfRoachesItem;
import net.arphex.item.BucketOfMaggotsItem;
import net.arphex.item.BladeDisplayItem;
import net.arphex.item.BaneOfTheDarknessItem;
import net.arphex.item.AbyssalShardItem;
import net.arphex.item.AbyssalPickaxeItem;
import net.arphex.item.AbyssalDaggerItem;
import net.arphex.item.AbyssalCrystalItem;
import net.arphex.item.AbyssalBladeItem;
import net.arphex.ArphexMod;

public class ArphexModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ArphexMod.MODID);
	public static final RegistryObject<Item> ABYSSAL_CRYSTAL = REGISTRY.register("abyssal_crystal", () -> new AbyssalCrystalItem());
	public static final RegistryObject<Item> SPIDER_MOTH_DWELLER_SPAWN_EGG = REGISTRY.register("spider_moth_dweller_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_MOTH_DWELLER, -13434880, -16777216, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SPIDER_MOTH_LARVAE_SPAWN_EGG = REGISTRY.register("spider_moth_larvae_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_MOTH_LARVAE, -10092493, -13434829, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> MANGLED_SPIDER_FLESH = block(ArphexModBlocks.MANGLED_SPIDER_FLESH, CreativeModeTab.TAB_DECORATIONS);
	public static final RegistryObject<Item> BANE_OF_THE_DARKNESS = REGISTRY.register("bane_of_the_darkness", () -> new BaneOfTheDarknessItem());
	public static final RegistryObject<Item> TELEPORT_GHOST_SPAWN_EGG = REGISTRY.register("teleport_ghost_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.TELEPORT_GHOST, -10066330, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SPIDER_LARVAE_SPAWN_EGG = REGISTRY.register("spider_larvae_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_LARVAE, -13434880, -10092493, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ABYSSAL_PICKAXE = REGISTRY.register("abyssal_pickaxe", () -> new AbyssalPickaxeItem());
	public static final RegistryObject<Item> SUN_SCORPION_SPAWN_EGG = REGISTRY.register("sun_scorpion_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.SUN_SCORPION, -26215, -13159, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> LONG_LEGS_SPAWN_EGG = REGISTRY.register("long_legs_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.LONG_LEGS, -26317, -13159, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> CENTIPEDE_STALKER_SPAWN_EGG = REGISTRY.register("centipede_stalker_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.CENTIPEDE_STALKER, -26368, -10079488, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> MAGGOT_GRUB = REGISTRY.register("maggot_grub", () -> new MaggotGrubItem());
	public static final RegistryObject<Item> MAGGOT_SPAWN_EGG = REGISTRY.register("maggot_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.MAGGOT, -13108, -52, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> BLOOD_WORM_SPAWN_EGG = REGISTRY.register("blood_worm_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.BLOOD_WORM, -26215, -16777216, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> WATER_ROACH_SPAWN_EGG = REGISTRY.register("water_roach_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.WATER_ROACH, -3381760, -13434880, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> BEETLE_TICK_MITE_SPAWN_EGG = REGISTRY.register("beetle_tick_mite_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.BEETLE_TICK_MITE, -10079488, -10066432, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SPIDER_BROOD_SPAWN_EGG = REGISTRY.register("spider_brood_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_BROOD, -13434880, -6653046, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SPIDER_WIDOW_SPAWN_EGG = REGISTRY.register("spider_widow_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_WIDOW, -16777216, -3407872, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SPIDER_FLAT_SPAWN_EGG = REGISTRY.register("spider_flat_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_FLAT, -13434880, -8233401, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ANT_GIANT_SPAWN_EGG = REGISTRY.register("ant_giant_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.ANT_GIANT, -11658983, -14871532, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> CENTIPEDE_EVICTOR_SPAWN_EGG = REGISTRY.register("centipede_evictor_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.CENTIPEDE_EVICTOR, -10072832, -8377586, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> BUCKET_OF_ROACHES = REGISTRY.register("bucket_of_roaches", () -> new BucketOfRoachesItem());
	public static final RegistryObject<Item> BUCKET_OF_MAGGOTS = REGISTRY.register("bucket_of_maggots", () -> new BucketOfMaggotsItem());
	public static final RegistryObject<Item> ROACH_NYMPH = REGISTRY.register("roach_nymph", () -> new RoachNymphItem());
	public static final RegistryObject<Item> CENTIPEDE_EVICTOR_LARVAE_SPAWN_EGG = REGISTRY.register("centipede_evictor_larvae_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.CENTIPEDE_EVICTOR_LARVAE, -10066432, -3394816, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> ABYSSAL_SHARD = REGISTRY.register("abyssal_shard", () -> new AbyssalShardItem());
	public static final RegistryObject<Item> SPIDER_LURKER_SPAWN_EGG = REGISTRY.register("spider_lurker_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_LURKER, -3355648, -10066432, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SPIDER_FLAT_JAR = REGISTRY.register("spider_flat_jar", () -> new SpiderFlatJarItem());
	public static final RegistryObject<Item> MANTLE_OF_VITALITY = REGISTRY.register("mantle_of_vitality", () -> new MantleOfVitalityItem());
	public static final RegistryObject<Item> SPIDER_JAR = REGISTRY.register("spider_jar", () -> new SpiderJarItem());
	public static final RegistryObject<Item> SPIDER_FUNNEL_SPAWN_EGG = REGISTRY.register("spider_funnel_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_FUNNEL, -15527149, -13421824, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SLING_WEB = REGISTRY.register("sling_web", () -> new SlingWebItem());
	public static final RegistryObject<Item> GIANT_SPINNERET = REGISTRY.register("giant_spinneret", () -> new GiantSpinneretItem());
	public static final RegistryObject<Item> BLADE_DISPLAY = REGISTRY.register("blade_display", () -> new BladeDisplayItem());
	public static final RegistryObject<Item> PICK_DISPLAY = REGISTRY.register("pick_display", () -> new PickDisplayItem());
	public static final RegistryObject<Item> ABYSSAL_BLADE = REGISTRY.register("abyssal_blade", () -> new AbyssalBladeItem());
	public static final RegistryObject<Item> SPIDER_GOLIATH_SPAWN_EGG = REGISTRY.register("spider_goliath_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SPIDER_GOLIATH, -10072832, -13421824, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> SILVERFISH_SPECTRE_SPAWN_EGG = REGISTRY.register("silverfish_spectre_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.SILVERFISH_SPECTRE, -13027015, -12566745, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> BEETLE_RHINO_SPAWN_EGG = REGISTRY.register("beetle_rhino_spawn_egg", () -> new ForgeSpawnEggItem(ArphexModEntities.BEETLE_RHINO, -14674668, -10794727, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> NECROTIC_FANG = REGISTRY.register("necrotic_fang", () -> new NecroticFangItem());
	public static final RegistryObject<Item> DAGGER_OF_DISSOLUTION = REGISTRY.register("dagger_of_dissolution", () -> new DaggerOfDissolutionItem());
	public static final RegistryObject<Item> ABYSSAL_DAGGER = REGISTRY.register("abyssal_dagger", () -> new AbyssalDaggerItem());
	public static final RegistryObject<Item> TARANTULA_TETHER = REGISTRY.register("tarantula_tether", () -> new TarantulaTetherItem());
	public static final RegistryObject<Item> HORNET_HARBINGER_SPAWN_EGG = REGISTRY.register("hornet_harbinger_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.HORNET_HARBINGER, -16356, -14346473, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> HORNET_HARBINGER_GIANT_SPAWN_EGG = REGISTRY.register("hornet_harbinger_giant_spawn_egg",
			() -> new ForgeSpawnEggItem(ArphexModEntities.HORNET_HARBINGER_GIANT, -11681, -16777216, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));
	public static final RegistryObject<Item> THUNDER_SENSOR = REGISTRY.register("thunder_sensor", () -> new ThunderSensorItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
