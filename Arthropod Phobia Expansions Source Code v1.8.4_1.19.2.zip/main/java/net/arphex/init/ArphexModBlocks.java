
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.arphex.block.MangledSpiderFleshBlock;
import net.arphex.ArphexMod;

public class ArphexModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ArphexMod.MODID);
	public static final RegistryObject<Block> MANGLED_SPIDER_FLESH = REGISTRY.register("mangled_spider_flesh", () -> new MangledSpiderFleshBlock());
}
