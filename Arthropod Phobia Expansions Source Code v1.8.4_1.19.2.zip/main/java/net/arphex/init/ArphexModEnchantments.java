
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.arphex.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.arphex.enchantment.WitherAuraEnchantment;
import net.arphex.ArphexMod;

public class ArphexModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, ArphexMod.MODID);
	public static final RegistryObject<Enchantment> WITHER_AURA = REGISTRY.register("wither_aura", () -> new WitherAuraEnchantment());
}
