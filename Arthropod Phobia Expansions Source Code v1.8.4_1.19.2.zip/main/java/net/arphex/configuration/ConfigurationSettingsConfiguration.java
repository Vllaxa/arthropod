package net.arphex.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class ConfigurationSettingsConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DWELLER_REQUIRE_THUNDER;
	public static final ForgeConfigSpec.ConfigValue<Boolean> SPAWN_DWELLER_NATURALLY;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DWELLER_INCLUSION;
	public static final ForgeConfigSpec.ConfigValue<Double> DWELLER_FREQUENCY;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DWELLER_HEALTH;
	static {
		BUILDER.push("Spawning");
		DWELLER_REQUIRE_THUNDER = BUILDER.comment("This controls whether all dweller versions will require thunderstorm weather to spawn").define("Dweller_requires_thunder?", true);
		SPAWN_DWELLER_NATURALLY = BUILDER.comment("Do you want the dweller and clone versions to spawn naturally?").define("Dweller Spawning", true);
		DWELLER_INCLUSION = BUILDER.comment("This controls whether the dweller boss is included in general. Set to false if you only want the other mobs, and the dweller will become unable to be spawned in any way.").define("Dweller Inclusion",
				true);
		DWELLER_FREQUENCY = BUILDER.comment("Dweller and variant spawns are rare by default. 1=twice as common. 2=default rarity. 3=twice as rare. 4=three times rarer.").define("Dweller Rarity", (double) 2);
		BUILDER.pop();
		BUILDER.push("Difficulty");
		DWELLER_HEALTH = BUILDER.comment("By default, the dweller boss has 350 health. Choose true to decrease this to 60 health,").define("Dweller Health", false);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
