
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.CentipedeEvictorModel;
import net.arphex.entity.CentipedeEvictorEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class CentipedeEvictorRenderer extends GeoEntityRenderer<CentipedeEvictorEntity> {
	public CentipedeEvictorRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new CentipedeEvictorModel());
		this.shadowRadius = 2f;
	}

	@Override
	public RenderType getRenderType(CentipedeEvictorEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(4.5f, 4.5f, 4.5f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}

	@Override
	protected float getDeathMaxRotation(CentipedeEvictorEntity entityLivingBaseIn) {
		return 0.0F;
	}
}
