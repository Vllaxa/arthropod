
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.WebFunnelModel;
import net.arphex.entity.WebFunnelEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class WebFunnelRenderer extends GeoEntityRenderer<WebFunnelEntity> {
	public WebFunnelRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new WebFunnelModel());
		this.shadowRadius = 1f;
	}

	@Override
	public RenderType getRenderType(WebFunnelEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(1.3f, 1.3f, 1.3f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}
}
