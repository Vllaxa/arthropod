
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.HornetHarbingerGiantModel;
import net.arphex.entity.HornetHarbingerGiantEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class HornetHarbingerGiantRenderer extends GeoEntityRenderer<HornetHarbingerGiantEntity> {
	public HornetHarbingerGiantRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new HornetHarbingerGiantModel());
		this.shadowRadius = 0.3f;
	}

	@Override
	public RenderType getRenderType(HornetHarbingerGiantEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(2.6f, 2.6f, 2.6f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}

	@Override
	protected float getDeathMaxRotation(HornetHarbingerGiantEntity entityLivingBaseIn) {
		return 0.0F;
	}
}
