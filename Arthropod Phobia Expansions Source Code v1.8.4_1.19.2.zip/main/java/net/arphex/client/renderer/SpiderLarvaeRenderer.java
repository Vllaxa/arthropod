
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.SpiderLarvaeModel;
import net.arphex.entity.layer.SpiderLarvaeLayer;
import net.arphex.entity.SpiderLarvaeEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SpiderLarvaeRenderer extends GeoEntityRenderer<SpiderLarvaeEntity> {
	public SpiderLarvaeRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new SpiderLarvaeModel());
		this.shadowRadius = 0.1f;
		this.addLayer(new SpiderLarvaeLayer(this));
	}

	@Override
	public RenderType getRenderType(SpiderLarvaeEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(1f, 1f, 1f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}
}
