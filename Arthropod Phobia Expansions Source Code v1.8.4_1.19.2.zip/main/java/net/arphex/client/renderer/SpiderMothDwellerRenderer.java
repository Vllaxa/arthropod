
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.procedures.SpiderMothDwellerEntityVisualScaleProcedure;
import net.arphex.entity.model.SpiderMothDwellerModel;
import net.arphex.entity.layer.SpiderMothDwellerLayer;
import net.arphex.entity.SpiderMothDwellerEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SpiderMothDwellerRenderer extends GeoEntityRenderer<SpiderMothDwellerEntity> {
	public SpiderMothDwellerRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new SpiderMothDwellerModel());
		this.shadowRadius = 3f;
		this.addLayer(new SpiderMothDwellerLayer(this));
	}

	@Override
	public RenderType getRenderType(SpiderMothDwellerEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		Level world = entity.level;
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float scale = (float) SpiderMothDwellerEntityVisualScaleProcedure.execute(world, x, y, z, entity);
		stack.scale(scale, scale, scale);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}

	@Override
	protected float getDeathMaxRotation(SpiderMothDwellerEntity entityLivingBaseIn) {
		return 0.0F;
	}
}
