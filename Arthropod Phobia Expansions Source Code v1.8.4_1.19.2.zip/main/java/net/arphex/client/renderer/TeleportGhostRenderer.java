
package net.arphex.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.arphex.entity.TeleportGhostEntity;
import net.arphex.client.model.ModelSpiderMothEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class TeleportGhostRenderer extends MobRenderer<TeleportGhostEntity, ModelSpiderMothEntity<TeleportGhostEntity>> {
	public TeleportGhostRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelSpiderMothEntity(context.bakeLayer(ModelSpiderMothEntity.LAYER_LOCATION)), 0.5f);
	}

	@Override
	protected void scale(TeleportGhostEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.6f, 0.6f, 0.6f);
	}

	@Override
	public ResourceLocation getTextureLocation(TeleportGhostEntity entity) {
		return new ResourceLocation("arphex:textures/entities/horrormothlowhealthfixed.png");
	}

	@Override
	protected boolean isBodyVisible(TeleportGhostEntity entity) {
		return false;
	}

	@Override
	protected boolean isShaking(TeleportGhostEntity entity) {
		return true;
	}
}
