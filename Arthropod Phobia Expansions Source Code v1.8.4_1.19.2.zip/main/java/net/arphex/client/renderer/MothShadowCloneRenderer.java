
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.world.level.Level;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.procedures.MothShadowCloneEntityVisualScaleProcedure;
import net.arphex.entity.model.MothShadowCloneModel;
import net.arphex.entity.MothShadowCloneEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class MothShadowCloneRenderer extends GeoEntityRenderer<MothShadowCloneEntity> {
	public MothShadowCloneRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new MothShadowCloneModel());
		this.shadowRadius = 0f;
	}

	@Override
	public RenderType getRenderType(MothShadowCloneEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		Level world = entity.level;
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float scale = (float) MothShadowCloneEntityVisualScaleProcedure.execute(world);
		stack.scale(scale, scale, scale);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}

	@Override
	protected float getDeathMaxRotation(MothShadowCloneEntity entityLivingBaseIn) {
		return 0.0F;
	}
}
