
package net.arphex.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CodModel;

import net.arphex.entity.WebHarnessEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class WebHarnessRenderer extends MobRenderer<WebHarnessEntity, CodModel<WebHarnessEntity>> {
	public WebHarnessRenderer(EntityRendererProvider.Context context) {
		super(context, new CodModel(context.bakeLayer(ModelLayers.COD)), 0f);
	}

	@Override
	protected void scale(WebHarnessEntity entity, PoseStack poseStack, float f) {
		poseStack.scale(0.5f, 0.5f, 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(WebHarnessEntity entity) {
		return new ResourceLocation("arphex:textures/entities/invisible.png");
	}
}
