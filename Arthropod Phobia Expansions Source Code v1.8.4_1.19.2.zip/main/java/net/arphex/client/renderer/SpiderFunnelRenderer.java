
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.SpiderFunnelModel;
import net.arphex.entity.layer.SpiderFunnelLayer;
import net.arphex.entity.SpiderFunnelEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SpiderFunnelRenderer extends GeoEntityRenderer<SpiderFunnelEntity> {
	public SpiderFunnelRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new SpiderFunnelModel());
		this.shadowRadius = 0f;
		this.addLayer(new SpiderFunnelLayer(this));
	}

	@Override
	public RenderType getRenderType(SpiderFunnelEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(4f, 4f, 4f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}

	@Override
	protected float getDeathMaxRotation(SpiderFunnelEntity entityLivingBaseIn) {
		return 0.0F;
	}
}
