
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.SkyStalkerModel;
import net.arphex.entity.layer.SkyStalkerLayer;
import net.arphex.entity.SkyStalkerEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SkyStalkerRenderer extends GeoEntityRenderer<SkyStalkerEntity> {
	public SkyStalkerRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new SkyStalkerModel());
		this.shadowRadius = 0.5f;
		this.addLayer(new SkyStalkerLayer(this));
	}

	@Override
	public RenderType getRenderType(SkyStalkerEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(1.8f, 1.8f, 1.8f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}
}
