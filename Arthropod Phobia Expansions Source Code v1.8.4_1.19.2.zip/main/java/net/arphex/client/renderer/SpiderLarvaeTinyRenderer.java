
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.SpiderLarvaeTinyModel;
import net.arphex.entity.layer.SpiderLarvaeTinyLayer;
import net.arphex.entity.SpiderLarvaeTinyEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class SpiderLarvaeTinyRenderer extends GeoEntityRenderer<SpiderLarvaeTinyEntity> {
	public SpiderLarvaeTinyRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new SpiderLarvaeTinyModel());
		this.shadowRadius = 0f;
		this.addLayer(new SpiderLarvaeTinyLayer(this));
	}

	@Override
	public RenderType getRenderType(SpiderLarvaeTinyEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(0.6f, 0.6f, 0.6f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}
}
