
package net.arphex.client.renderer;

import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.arphex.entity.model.LongLegsModel;
import net.arphex.entity.LongLegsEntity;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

public class LongLegsRenderer extends GeoEntityRenderer<LongLegsEntity> {
	public LongLegsRenderer(EntityRendererProvider.Context renderManager) {
		super(renderManager, new LongLegsModel());
		this.shadowRadius = 0.1f;
	}

	@Override
	public RenderType getRenderType(LongLegsEntity entity, float partialTicks, PoseStack stack, MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn, ResourceLocation textureLocation) {
		stack.scale(1.7f, 1.7f, 1.7f);
		return RenderType.entityTranslucent(getTextureLocation(entity));
	}
}
