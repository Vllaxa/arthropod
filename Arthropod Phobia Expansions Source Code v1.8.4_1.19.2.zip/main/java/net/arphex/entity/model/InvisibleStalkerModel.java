package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.InvisibleStalkerEntity;

public class InvisibleStalkerModel extends AnimatedGeoModel<InvisibleStalkerEntity> {
	@Override
	public ResourceLocation getAnimationResource(InvisibleStalkerEntity entity) {
		return new ResourceLocation("arphex", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(InvisibleStalkerEntity entity) {
		return new ResourceLocation("arphex", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(InvisibleStalkerEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
