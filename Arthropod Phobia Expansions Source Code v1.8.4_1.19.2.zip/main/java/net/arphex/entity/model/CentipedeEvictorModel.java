package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.CentipedeEvictorEntity;

public class CentipedeEvictorModel extends AnimatedGeoModel<CentipedeEvictorEntity> {
	@Override
	public ResourceLocation getAnimationResource(CentipedeEvictorEntity entity) {
		return new ResourceLocation("arphex", "animations/centipedeevictor.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(CentipedeEvictorEntity entity) {
		return new ResourceLocation("arphex", "geo/centipedeevictor.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(CentipedeEvictorEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
