package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderWidowEntity;

public class SpiderWidowModel extends AnimatedGeoModel<SpiderWidowEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderWidowEntity entity) {
		return new ResourceLocation("arphex", "animations/spiderwidow.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderWidowEntity entity) {
		return new ResourceLocation("arphex", "geo/spiderwidow.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderWidowEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
