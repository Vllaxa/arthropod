package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.CentipedeStalkerEntity;

public class CentipedeStalkerModel extends AnimatedGeoModel<CentipedeStalkerEntity> {
	@Override
	public ResourceLocation getAnimationResource(CentipedeStalkerEntity entity) {
		return new ResourceLocation("arphex", "animations/centipedestalker.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(CentipedeStalkerEntity entity) {
		return new ResourceLocation("arphex", "geo/centipedestalker.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(CentipedeStalkerEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
