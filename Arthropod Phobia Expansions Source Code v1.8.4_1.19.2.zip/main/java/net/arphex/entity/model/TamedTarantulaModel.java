package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.TamedTarantulaEntity;

public class TamedTarantulaModel extends AnimatedGeoModel<TamedTarantulaEntity> {
	@Override
	public ResourceLocation getAnimationResource(TamedTarantulaEntity entity) {
		return new ResourceLocation("arphex", "animations/spidertarantula.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(TamedTarantulaEntity entity) {
		return new ResourceLocation("arphex", "geo/spidertarantula.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(TamedTarantulaEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
