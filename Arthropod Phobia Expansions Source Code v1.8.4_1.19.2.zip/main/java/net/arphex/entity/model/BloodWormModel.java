package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.BloodWormEntity;

public class BloodWormModel extends AnimatedGeoModel<BloodWormEntity> {
	@Override
	public ResourceLocation getAnimationResource(BloodWormEntity entity) {
		return new ResourceLocation("arphex", "animations/bloodworm.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(BloodWormEntity entity) {
		return new ResourceLocation("arphex", "geo/bloodworm.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(BloodWormEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
