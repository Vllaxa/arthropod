package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SkyStalkerEntity;

public class SkyStalkerModel extends AnimatedGeoModel<SkyStalkerEntity> {
	@Override
	public ResourceLocation getAnimationResource(SkyStalkerEntity entity) {
		return new ResourceLocation("arphex", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SkyStalkerEntity entity) {
		return new ResourceLocation("arphex", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SkyStalkerEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
