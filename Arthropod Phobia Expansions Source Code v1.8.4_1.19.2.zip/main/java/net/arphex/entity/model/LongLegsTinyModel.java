package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.LongLegsTinyEntity;

public class LongLegsTinyModel extends AnimatedGeoModel<LongLegsTinyEntity> {
	@Override
	public ResourceLocation getAnimationResource(LongLegsTinyEntity entity) {
		return new ResourceLocation("arphex", "animations/longlegs.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(LongLegsTinyEntity entity) {
		return new ResourceLocation("arphex", "geo/longlegs.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(LongLegsTinyEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
