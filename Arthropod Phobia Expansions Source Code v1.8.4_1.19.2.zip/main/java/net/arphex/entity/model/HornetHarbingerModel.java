package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.HornetHarbingerEntity;

public class HornetHarbingerModel extends AnimatedGeoModel<HornetHarbingerEntity> {
	@Override
	public ResourceLocation getAnimationResource(HornetHarbingerEntity entity) {
		return new ResourceLocation("arphex", "animations/hornet.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HornetHarbingerEntity entity) {
		return new ResourceLocation("arphex", "geo/hornet.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HornetHarbingerEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
