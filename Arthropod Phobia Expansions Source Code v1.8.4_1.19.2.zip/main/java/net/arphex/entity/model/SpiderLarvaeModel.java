package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderLarvaeEntity;

public class SpiderLarvaeModel extends AnimatedGeoModel<SpiderLarvaeEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderLarvaeEntity entity) {
		return new ResourceLocation("arphex", "animations/spiderlarvae.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderLarvaeEntity entity) {
		return new ResourceLocation("arphex", "geo/spiderlarvae.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderLarvaeEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
