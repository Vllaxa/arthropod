package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.AntGiantEntity;

public class AntGiantModel extends AnimatedGeoModel<AntGiantEntity> {
	@Override
	public ResourceLocation getAnimationResource(AntGiantEntity entity) {
		return new ResourceLocation("arphex", "animations/antgiant.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(AntGiantEntity entity) {
		return new ResourceLocation("arphex", "geo/antgiant.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(AntGiantEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
