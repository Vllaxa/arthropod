package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.RushScareEntity;

public class RushScareModel extends AnimatedGeoModel<RushScareEntity> {
	@Override
	public ResourceLocation getAnimationResource(RushScareEntity entity) {
		return new ResourceLocation("arphex", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(RushScareEntity entity) {
		return new ResourceLocation("arphex", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(RushScareEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
