package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SilverfishSpectreEntity;

public class SilverfishSpectreModel extends AnimatedGeoModel<SilverfishSpectreEntity> {
	@Override
	public ResourceLocation getAnimationResource(SilverfishSpectreEntity entity) {
		return new ResourceLocation("arphex", "animations/silverfishspectre.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SilverfishSpectreEntity entity) {
		return new ResourceLocation("arphex", "geo/silverfishspectre.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SilverfishSpectreEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
