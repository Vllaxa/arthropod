package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderLurkerEntity;

public class SpiderLurkerModel extends AnimatedGeoModel<SpiderLurkerEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderLurkerEntity entity) {
		return new ResourceLocation("arphex", "animations/spidersea.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderLurkerEntity entity) {
		return new ResourceLocation("arphex", "geo/spidersea.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderLurkerEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
