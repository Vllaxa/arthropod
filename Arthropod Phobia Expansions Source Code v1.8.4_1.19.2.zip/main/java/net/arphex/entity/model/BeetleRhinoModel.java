package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.BeetleRhinoEntity;

public class BeetleRhinoModel extends AnimatedGeoModel<BeetleRhinoEntity> {
	@Override
	public ResourceLocation getAnimationResource(BeetleRhinoEntity entity) {
		return new ResourceLocation("arphex", "animations/rhinobeetle.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(BeetleRhinoEntity entity) {
		return new ResourceLocation("arphex", "geo/rhinobeetle.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(BeetleRhinoEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
