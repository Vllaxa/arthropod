package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderBroodEntity;

public class SpiderBroodModel extends AnimatedGeoModel<SpiderBroodEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderBroodEntity entity) {
		return new ResourceLocation("arphex", "animations/spiderbrood.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderBroodEntity entity) {
		return new ResourceLocation("arphex", "geo/spiderbrood.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderBroodEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
