package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderFlatEntity;

public class SpiderFlatModel extends AnimatedGeoModel<SpiderFlatEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderFlatEntity entity) {
		return new ResourceLocation("arphex", "animations/spiderflat.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderFlatEntity entity) {
		return new ResourceLocation("arphex", "geo/spiderflat.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderFlatEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
