package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.PureStalkingEntity;

public class PureStalkingModel extends AnimatedGeoModel<PureStalkingEntity> {
	@Override
	public ResourceLocation getAnimationResource(PureStalkingEntity entity) {
		return new ResourceLocation("arphex", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(PureStalkingEntity entity) {
		return new ResourceLocation("arphex", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(PureStalkingEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
