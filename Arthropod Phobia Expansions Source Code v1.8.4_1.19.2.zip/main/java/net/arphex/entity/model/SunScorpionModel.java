package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SunScorpionEntity;

public class SunScorpionModel extends AnimatedGeoModel<SunScorpionEntity> {
	@Override
	public ResourceLocation getAnimationResource(SunScorpionEntity entity) {
		return new ResourceLocation("arphex", "animations/sunscorpion.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SunScorpionEntity entity) {
		return new ResourceLocation("arphex", "geo/sunscorpion.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SunScorpionEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
