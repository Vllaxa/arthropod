package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.WaterRoachEntity;

public class WaterRoachModel extends AnimatedGeoModel<WaterRoachEntity> {
	@Override
	public ResourceLocation getAnimationResource(WaterRoachEntity entity) {
		return new ResourceLocation("arphex", "animations/waterroach.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(WaterRoachEntity entity) {
		return new ResourceLocation("arphex", "geo/waterroach.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(WaterRoachEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
