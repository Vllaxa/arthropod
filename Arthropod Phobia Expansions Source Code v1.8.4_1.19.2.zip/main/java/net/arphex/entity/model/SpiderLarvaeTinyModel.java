package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderLarvaeTinyEntity;

public class SpiderLarvaeTinyModel extends AnimatedGeoModel<SpiderLarvaeTinyEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderLarvaeTinyEntity entity) {
		return new ResourceLocation("arphex", "animations/spiderlarvae.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderLarvaeTinyEntity entity) {
		return new ResourceLocation("arphex", "geo/spiderlarvae.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderLarvaeTinyEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
