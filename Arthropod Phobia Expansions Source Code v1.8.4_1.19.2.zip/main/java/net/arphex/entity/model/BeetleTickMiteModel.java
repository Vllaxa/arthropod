package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.BeetleTickMiteEntity;

public class BeetleTickMiteModel extends AnimatedGeoModel<BeetleTickMiteEntity> {
	@Override
	public ResourceLocation getAnimationResource(BeetleTickMiteEntity entity) {
		return new ResourceLocation("arphex", "animations/beetletickmite.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(BeetleTickMiteEntity entity) {
		return new ResourceLocation("arphex", "geo/beetletickmite.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(BeetleTickMiteEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
