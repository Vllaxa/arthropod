package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderFunnelEntity;

public class SpiderFunnelModel extends AnimatedGeoModel<SpiderFunnelEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderFunnelEntity entity) {
		return new ResourceLocation("arphex", "animations/spiderfunnel.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderFunnelEntity entity) {
		return new ResourceLocation("arphex", "geo/spiderfunnel.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderFunnelEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
