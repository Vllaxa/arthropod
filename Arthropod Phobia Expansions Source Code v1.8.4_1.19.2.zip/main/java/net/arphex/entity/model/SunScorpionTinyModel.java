package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SunScorpionTinyEntity;

public class SunScorpionTinyModel extends AnimatedGeoModel<SunScorpionTinyEntity> {
	@Override
	public ResourceLocation getAnimationResource(SunScorpionTinyEntity entity) {
		return new ResourceLocation("arphex", "animations/sunscorpion.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SunScorpionTinyEntity entity) {
		return new ResourceLocation("arphex", "geo/sunscorpion.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SunScorpionTinyEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
