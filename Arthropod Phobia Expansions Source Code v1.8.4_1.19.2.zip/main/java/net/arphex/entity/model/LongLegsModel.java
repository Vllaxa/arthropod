package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.LongLegsEntity;

public class LongLegsModel extends AnimatedGeoModel<LongLegsEntity> {
	@Override
	public ResourceLocation getAnimationResource(LongLegsEntity entity) {
		return new ResourceLocation("arphex", "animations/longlegs.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(LongLegsEntity entity) {
		return new ResourceLocation("arphex", "geo/longlegs.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(LongLegsEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
