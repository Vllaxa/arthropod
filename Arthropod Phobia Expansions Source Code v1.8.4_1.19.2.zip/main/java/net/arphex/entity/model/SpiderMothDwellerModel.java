package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.SpiderMothDwellerEntity;

public class SpiderMothDwellerModel extends AnimatedGeoModel<SpiderMothDwellerEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderMothDwellerEntity entity) {
		return new ResourceLocation("arphex", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderMothDwellerEntity entity) {
		return new ResourceLocation("arphex", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderMothDwellerEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
