package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.TinyCentipedeBreacherEntity;

public class TinyCentipedeBreacherModel extends AnimatedGeoModel<TinyCentipedeBreacherEntity> {
	@Override
	public ResourceLocation getAnimationResource(TinyCentipedeBreacherEntity entity) {
		return new ResourceLocation("arphex", "animations/centipedeevictor.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(TinyCentipedeBreacherEntity entity) {
		return new ResourceLocation("arphex", "geo/centipedeevictor.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(TinyCentipedeBreacherEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
