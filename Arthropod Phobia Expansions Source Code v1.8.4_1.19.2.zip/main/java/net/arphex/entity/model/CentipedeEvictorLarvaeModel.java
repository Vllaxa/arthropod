package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.CentipedeEvictorLarvaeEntity;

public class CentipedeEvictorLarvaeModel extends AnimatedGeoModel<CentipedeEvictorLarvaeEntity> {
	@Override
	public ResourceLocation getAnimationResource(CentipedeEvictorLarvaeEntity entity) {
		return new ResourceLocation("arphex", "animations/centipedeevictor.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(CentipedeEvictorLarvaeEntity entity) {
		return new ResourceLocation("arphex", "geo/centipedeevictor.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(CentipedeEvictorLarvaeEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
