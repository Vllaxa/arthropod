package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.HornetHarbingerGiantEntity;

public class HornetHarbingerGiantModel extends AnimatedGeoModel<HornetHarbingerGiantEntity> {
	@Override
	public ResourceLocation getAnimationResource(HornetHarbingerGiantEntity entity) {
		return new ResourceLocation("arphex", "animations/hornet.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HornetHarbingerGiantEntity entity) {
		return new ResourceLocation("arphex", "geo/hornet.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HornetHarbingerGiantEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
