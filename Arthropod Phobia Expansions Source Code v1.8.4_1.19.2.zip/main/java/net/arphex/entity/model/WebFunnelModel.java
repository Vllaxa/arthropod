package net.arphex.entity.model;

import software.bernie.geckolib3.model.AnimatedGeoModel;

import net.minecraft.resources.ResourceLocation;

import net.arphex.entity.WebFunnelEntity;

public class WebFunnelModel extends AnimatedGeoModel<WebFunnelEntity> {
	@Override
	public ResourceLocation getAnimationResource(WebFunnelEntity entity) {
		return new ResourceLocation("arphex", "animations/funnelweb.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(WebFunnelEntity entity) {
		return new ResourceLocation("arphex", "geo/funnelweb.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(WebFunnelEntity entity) {
		return new ResourceLocation("arphex", "textures/entities/" + entity.getTexture() + ".png");
	}

}
