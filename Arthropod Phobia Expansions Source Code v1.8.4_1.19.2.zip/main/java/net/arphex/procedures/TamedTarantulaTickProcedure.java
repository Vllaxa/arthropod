package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.entity.TamedTarantulaEntity;
import net.arphex.ArphexMod;

public class TamedTarantulaTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world.isEmptyBlock(new BlockPos(x, y - 0.9, z)) && world.isEmptyBlock(new BlockPos(x, y - 1.9, z)) && !entity.isOnGround()) {
			entity.setShiftKeyDown(true);
		} else {
			entity.setShiftKeyDown(false);
		}
		if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula1")) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, false, false));
		}
		if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.REGENERATION) : false)) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, false, false));
		}
		if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula4")) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 1, false, false));
		}
		if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula3")) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 0, false, false));
		}
		if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula2")) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 60, 0, false, false));
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) / 2) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.SPIDER_BLOOD.get()), x, y, z, 5, 0.5, 0.5, 0.5, 0.3);
		}
		if (entity.isVehicle()) {
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				ArphexMod.queueServerWork(15, () -> {
					if (entity instanceof Mob) {
						try {
							((Mob) entity).setTarget(null);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
		}
		if (entity.getPersistentData().getDouble("spiderjump") > 0) {
			entity.getPersistentData().putDouble("spiderjump", (entity.getPersistentData().getDouble("spiderjump") - 1));
		}
		if (entity.isShiftKeyDown()) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, (y + 1), z, 15, 0.1, 0.2, 0.1, 0.1);
		}
	}
}
