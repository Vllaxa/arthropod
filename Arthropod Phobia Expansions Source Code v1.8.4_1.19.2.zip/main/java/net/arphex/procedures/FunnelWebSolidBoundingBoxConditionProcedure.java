package net.arphex.procedures;

public class FunnelWebSolidBoundingBoxConditionProcedure {
	public static boolean execute() {
		return true;
	}
}
