package net.arphex.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.entity.SpiderFunnelEntity;

public class SpiderFunnelOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("climbradius", 1.1);
		if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
			if (entity instanceof SpiderFunnelEntity animatable)
				animatable.setTexture("spiderfunnel2");
		}
	}
}
