package net.arphex.procedures;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.ItemStack;

import net.arphex.init.ArphexModEnchantments;

public class AbyssalPickaxeItemIsCraftedsmeltedProcedure {
	public static void execute(ItemStack itemstack) {
		(itemstack).enchant(ArphexModEnchantments.WITHER_AURA.get(), 3);
		(itemstack).enchant(Enchantments.BLOCK_EFFICIENCY, 3);
		(itemstack).enchant(Enchantments.BLOCK_FORTUNE, 3);
		itemstack.getOrCreateTag().putBoolean("crafted", true);
	}
}
