package net.arphex.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.Difficulty;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.network.ArphexModVariables;
import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModMobEffects;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.TeleportGhostEntity;
import net.arphex.entity.SpiderMothDwellerEntity;
import net.arphex.configuration.ConfigurationSettingsConfiguration;
import net.arphex.ArphexMod;

import java.util.Map;
import java.util.Comparator;

public class SpiderMothOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double fireHeight = 0;
		double mobsize = 0;
		double animcool = 0;
		if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
			ArphexMod.queueServerWork(20, () -> {
				if (!world.getEntitiesOfClass(Pig.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty() && (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
					if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Pig.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
						_entity.setTarget(_ent);
				}
			});
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 35) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.INVISIBILITY);
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));
		}
		if (entity.getPersistentData().getBoolean("growattack") == true) {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("redglow");
		}
		if (ConfigurationSettingsConfiguration.DWELLER_INCLUSION.get() == false) {
			if (!entity.level.isClientSide())
				entity.discard();
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).isEmpty()) {
			if (entity.getPersistentData().getBoolean("spawnedawayfromplayer") == true) {
				if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getDouble("mothsurvivals") < 2) {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, false, false));
				}
				if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getDouble("mothsurvivals") < 3) {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 0, false, false));
				}
			}
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				entity.getPersistentData().putString("chasemode", "yes");
			}
		}
		if (ConfigurationSettingsConfiguration.DWELLER_HEALTH.get() == true && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 60) {
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(60);
		}
		if (entity instanceof SpiderMothDwellerEntity) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ArphexModMobEffects.MOTH_CURSE.get());
		}
		if ((entity.getPersistentData().getString("chasemode")).equals("no")) {
			entity.getPersistentData().putString("chasesoundonce", "one");
		} else {
			if ((entity.getPersistentData().getString("chasesoundonce")).equals("one")) {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothchase")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.5),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothchase")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.5),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
						}
					}
				} else {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothchase2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.5),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothchase2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.5),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
						}
					}
				}
				entity.getPersistentData().putString("chasesoundonce", "no");
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 60, 60, 60), e -> true).isEmpty() && Mth.nextInt(RandomSource.create(), 1, 1000) > 999
				&& !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
			entity.getPersistentData().putString("chasesoundonce", "one");
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 40, 40, 40), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 40, 40, 40), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
					if ((entity.getPersistentData().getString("dwellerwaiting")).equals("spawned")) {
						ArphexMod.queueServerWork(300, () -> {
							entity.getPersistentData().putString("dwellerwaiting", "waiting");
						});
					} else {
						entity.getPersistentData().putString("dwellerwaiting", "waiting");
						if ((entity.getPersistentData().getString("dwellerwaiting")).equals("waiting")) {
							ArphexMod.queueServerWork(300, () -> {
								if ((entity.getPersistentData().getString("dwellerwaiting")).equals("waiting") && !(!world.getEntitiesOfClass(TeleportGhostEntity.class, AABB.ofSize(new Vec3(x, y, z), 15, 15, 15), e -> true).isEmpty())) {
									if (world instanceof ServerLevel _level) {
										Entity entityToSpawn = new TeleportGhostEntity(ArphexModEntities.TELEPORT_GHOST.get(), _level);
										entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
										if (entityToSpawn instanceof Mob _mobToSpawn)
											_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
										world.addFreshEntity(entityToSpawn);
									}
									entity.getPersistentData().putString("dwellerwaiting", "spawned");
								}
							});
						}
					}
				} else {
					entity.getPersistentData().putString("dwellerwaiting", "spawned");
				}
			}
		} else {
			entity.getPersistentData().putString("dwellerwaiting", "far");
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
			}
		}
		if (world.getDifficulty() == Difficulty.PEACEFUL) {
			if (!entity.level.isClientSide())
				entity.discard();
		}
		if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) && !world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).isEmpty()
				&& (entity.getPersistentData().getString("playerlookedatmoth")).equals("looking")) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if ((entity.getPersistentData().getString("soundonce")).equals("one")) {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run playsound arphex:mothscare hostile @p ~ ~ ~ 0.7 0.5");
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run playsound arphex:horror_crash hostile @p ~ ~ ~ 0.7 0.5");
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute as @p at @s anchored eyes run particle minecraft:smoke ~0.1 ~1.3 ~0 0 0 0 0.04 500");
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p darkness 8 1 true");
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p slowness 9 0 true");
					entity.getPersistentData().putString("soundonce", "stop");
					ArphexModVariables.MapVariables.get(world).ShowOverlay = "true";
					ArphexModVariables.MapVariables.get(world).syncData(world);
				}
				ArphexModVariables.MapVariables.get(world).LookScareLock = "true";
				ArphexModVariables.MapVariables.get(world).syncData(world);
				ArphexMod.queueServerWork(4, () -> {
					if ((entity.getPersistentData().getString("playerlookedatmoth")).equals("no")) {
						ArphexModVariables.MapVariables.get(world).ShowOverlay = "false";
						ArphexModVariables.MapVariables.get(world).syncData(world);
					}
					entity.getPersistentData().putString("chasemode", "chasing");
				});
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
				if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty())) {
					if ((entity.getPersistentData().getString("playerlookedatmoth")).equals("no")) {
						if ((entity.getPersistentData().getString("chasemode")).equals("no")) {
							if (entity instanceof Mob _entity)
								_entity.getNavigation().stop();
							if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
								_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 1, true, false));
							entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
						}
					} else {
						entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
						ArphexModVariables.MapVariables.get(world).LookScareLock = "true";
						ArphexModVariables.MapVariables.get(world).syncData(world);
						entity.getPersistentData().putString("chasemode", "chasing");
						if ((ArphexModVariables.MapVariables.get(world).LookScareLock).equals("true")) {
							if ((entity.getPersistentData().getString("soundonce")).equals("one")) {
								if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
									_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1, false, false));
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
											"execute as @p at @s anchored eyes run particle minecraft:smoke ~0.1 ~1.3 ~0 0 0 0 0.04 500");
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
											"execute at @p run playsound arphex:mothscare hostile @p ~ ~ ~ 0.7 0.5");
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
											"execute at @p run playsound arphex:horror_crash hostile @p ~ ~ ~ 0.7 0.5");
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(), "effect give @p darkness 8 1 true");
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(), "effect give @p slowness 9 0 true");
								ArphexModVariables.MapVariables.get(world).ShowOverlay = "true";
								ArphexModVariables.MapVariables.get(world).syncData(world);
								entity.getPersistentData().putString("soundonce", "stop");
							}
							ArphexMod.queueServerWork(4, () -> {
								ArphexModVariables.MapVariables.get(world).ShowOverlay = "false";
								ArphexModVariables.MapVariables.get(world).syncData(world);
								ArphexModVariables.MapVariables.get(world).LookScareLock = "false";
								ArphexModVariables.MapVariables.get(world).syncData(world);
							});
						}
					}
				}
			}
		}
		if (world.getLevelData().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING) == true
				&& ((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.TORCH || (world.getBlockState(new BlockPos(x, y + 1, z))).getBlock() == Blocks.WALL_TORCH)) {
			{
				BlockPos _bp = new BlockPos(x, y, z);
				BlockState _bs = Blocks.AIR.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			{
				BlockPos _bp = new BlockPos(x, y + 1, z);
				BlockState _bs = Blocks.AIR.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			if (world instanceof Level _level && !_level.isClientSide()) {
				ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.TORCH));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).isEmpty() && !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty())) {
			if (Mth.nextInt(RandomSource.create(), 1, 1300) == 200) {
				if (Mth.nextInt(RandomSource.create(), 1, 4) == 2) {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX(), ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY(), ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscream2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.1, 0.4),
									(float) Mth.nextDouble(RandomSource.create(), 0.2, 1.7));
						} else {
							_level.playLocalSound((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscream2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.1, 0.4),
									(float) Mth.nextDouble(RandomSource.create(), 0.2, 1.7), false);
						}
					}
				} else {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX(), ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY(), ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:spidermothcroak")), SoundSource.HOSTILE,
									(float) Mth.nextDouble(RandomSource.create(), 0.1, 0.8), (float) Mth.nextDouble(RandomSource.create(), 0.8, 1.2));
						} else {
							_level.playLocalSound((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:spidermothcroak")), SoundSource.HOSTILE,
									(float) Mth.nextDouble(RandomSource.create(), 0.1, 0.8), (float) Mth.nextDouble(RandomSource.create(), 0.8, 1.2), false);
						}
					}
				}
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty()) {
			if (Mth.nextInt(RandomSource.create(), 1, 300) == 200) {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscream")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.6),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscream")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.6),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
						}
					}
				} else {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscream2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.6),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscream2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.2, 0.6),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
						}
					}
				}
			}
			if (world instanceof Level _lvl157 && _lvl157.isDay()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=survival,distance=..2] darkness 1 0");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=adventure,distance=..2] darkness 1 0");
			} else {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=survival] darkness 5 0");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=adventure] darkness 5 0");
			}
		}
		if (world.getLevelData().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace glass_pane");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace acacia_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace bamboo_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace birch_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cherry_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace crimson_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace dark_oak_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace jungle_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace mangrove_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace oak_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace spruce_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace warped_door");
			}
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace oak_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace azalea_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace acacia_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace dark_oak_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cherry_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace flowering_azalea_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace jungle_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace mangrove_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace spruce_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace birch_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cobweb");
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty())) {
					if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 1200, 0, true, false));
					if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.MOTH_CURSE.get(), 1200, 0, false, false));
				}
			}
		}
		if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 280, 280, 280), e -> true).isEmpty())) {
			if (!entity.level.isClientSide())
				entity.discard();
		}
		if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 80, 80, 80), e -> true).isEmpty())) {
			entity.maxUpStep = 6;
		}
		if (!world.isEmptyBlock(new BlockPos(x, y + 1, z))) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 2, false, false));
		}
		if (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.DAMAGE_BOOST) : false) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"attribute @e[type=arphex:spider_moth_dweller,limit=1] minecraft:generic.attack_knockback base set 500");
		} else {
			if (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.MOVEMENT_SLOWDOWN) : false) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"attribute @e[type=arphex:spider_moth_dweller,limit=1] minecraft:generic.attack_knockback base set 0.5");
			} else {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"attribute @e[type=arphex:spider_moth_dweller,limit=1] minecraft:generic.attack_knockback base set 1");
			}
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow") || (entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute as @e[type=arphex:spider_moth_dweller,limit=1,sort=nearest] run data merge entity @s {Invulnerable:1}");
		} else {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute as @e[type=arphex:spider_moth_dweller,limit=1,sort=nearest] run data merge entity @s {Invulnerable:0}");
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
			ArphexMod.queueServerWork(20, () -> {
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("horrormothfixed");
			});
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow") || entity.getPersistentData().getBoolean("growattack") == true
				|| (entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
			ArphexMod.queueServerWork(60, () -> {
				if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow")) {
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("horrormothfixed");
				}
			});
		} else {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 175) {
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("horrormothfixed");
			} else {
				if (ConfigurationSettingsConfiguration.DWELLER_HEALTH.get() == false) {
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("horrormothlowhealthfixed");
				}
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20, 0, true, false));
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 30) {
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("horrormothlowhealthfixed");
				}
			}
		}
		if (entity.getPersistentData().getBoolean("growattack") == true) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 10, 1.5, 3, 1.5, 0);
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("horrormothfixed")) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.TINY_SPIDER.get()), x, (y + 1), z, (int) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) / 2), 0.8, 1, 0.8, 3);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.TINY_MOTH.get()), x, (y + 1), z, (int) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) / 2), 0.8, 1, 0.8, 3);
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("horrormothlowhealthfixed")) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z, (int) (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1), 0.8, 1, 0.8, 1);
			ArphexMod.queueServerWork(5, () -> {
				if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 10, 1, false, false));
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 5, 0.5, 0.5, 0.5, 0.5);
				}
			});
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow")) {
			entity.getPersistentData().putDouble("enbeetee", (entity.getPersistentData().getDouble("enbeetee") + 0.05));
		} else {
			if (!entity.isShiftKeyDown()) {
				entity.getPersistentData().putDouble("enbeetee", 1.65);
			} else {
				entity.getPersistentData().putDouble("enbeetee", 1.45);
			}
		}
		if (entity.isInWall() || (world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.POWDER_SNOW) {
			{
				Entity _ent = entity;
				_ent.teleportTo(x, (y + 0.9), z);
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport(x, (y + 0.9), z, _ent.getYRot(), _ent.getXRot());
			}
			entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 5, 3, 3, 3, 1);
		}
		if ((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COBWEB) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 10, 4, false, false));
		}
		if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
			if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY() > entity.getY() + 2 || entity.isInWater() || (world.getFluidState(new BlockPos(x - 1, y, z)).createLegacyBlock()).getBlock() instanceof LiquidBlock
					|| (world.getFluidState(new BlockPos(x + 1, y, z)).createLegacyBlock()).getBlock() instanceof LiquidBlock || (world.getFluidState(new BlockPos(x, y, z + 1)).createLegacyBlock()).getBlock() instanceof LiquidBlock
					|| (world.getFluidState(new BlockPos(x, y, z - 1)).createLegacyBlock()).getBlock() instanceof LiquidBlock || (world.getFluidState(new BlockPos(x, y, z)).createLegacyBlock()).getBlock() instanceof LiquidBlock) {
				entity.maxUpStep = 3;
				entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX()), ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY()),
						((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
				if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player && (entity.getPersistentData().getString("chasemode")).equals("no"))) {
					entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
				}
				ArphexMod.queueServerWork(40, () -> {
					if (Mth.nextInt(RandomSource.create(), 1, 10) == 5) {
						if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player && (entity.getPersistentData().getString("chasemode")).equals("no"))) {
							entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
						}
					}
				});
			} else {
				entity.maxUpStep = 2;
				if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).isAlive())) {
					if (entity instanceof Mob) {
						try {
							((Mob) entity).setTarget(null);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
			entity.getPersistentData().putBoolean("justattacked", false);
		} else {
			if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.REGENERATION) : false)) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, false, false));
			}
			if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().getBoolean("creativespectator") == true) {
				if (entity instanceof Mob) {
					try {
						((Mob) entity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (entity.isOnGround()) {
			if (entity.getPersistentData().getDouble("dramaticfall") > 40) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 40, 0.1, 1, 0.1, 0.3);
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.warden.sonic_boom")), SoundSource.NEUTRAL, (float) 0.3, (float) 0.5);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.warden.sonic_boom")), SoundSource.NEUTRAL, (float) 0.3, (float) 0.5, false);
					}
				}
			}
			entity.getPersistentData().putDouble("dramaticfall", 0);
		} else {
			entity.getPersistentData().putDouble("dramaticfall", (entity.getPersistentData().getDouble("dramaticfall") + 1));
		}
		if (entity.getPersistentData().getBoolean("growattack") == true) {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("redglow");
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).isEmpty() && !entity.isShiftKeyDown()
				&& (entity.getDeltaMovement().x() > 0 || entity.getDeltaMovement().y() > 0 || entity.getDeltaMovement().z() > 0)) {
			if (!(entity.getPersistentData().getDouble("wingsound") > 1)) {
				entity.getPersistentData().putDouble("wingsound", (Mth.nextInt(RandomSource.create(), 2, 8)));
				if ((entity.getDeltaMovement().x() + entity.getDeltaMovement().y() + entity.getDeltaMovement().z()) / 3 < 0.6) {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:flyingmoth1")), SoundSource.HOSTILE,
									(float) (1.2 + (Math.abs(entity.getDeltaMovement().x()) + Math.abs(entity.getDeltaMovement().y()) + Math.abs(entity.getDeltaMovement().z())) / 3),
									(float) (0.8 + (Math.abs(entity.getDeltaMovement().x()) + Math.abs(entity.getDeltaMovement().y()) + Math.abs(entity.getDeltaMovement().z())) / 3));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:flyingmoth1")), SoundSource.HOSTILE,
									(float) (1.2 + (Math.abs(entity.getDeltaMovement().x()) + Math.abs(entity.getDeltaMovement().y()) + Math.abs(entity.getDeltaMovement().z())) / 3),
									(float) (0.8 + (Math.abs(entity.getDeltaMovement().x()) + Math.abs(entity.getDeltaMovement().y()) + Math.abs(entity.getDeltaMovement().z())) / 3), false);
						}
					}
				} else {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:flyingmoth2")), SoundSource.HOSTILE, (float) 0.9, (float) Mth.nextDouble(RandomSource.create(), 1, 1.3));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:flyingmoth2")), SoundSource.HOSTILE, (float) 0.9, (float) Mth.nextDouble(RandomSource.create(), 1, 1.3), false);
						}
					}
				}
			} else {
				entity.getPersistentData().putDouble("wingsound", (entity.getPersistentData().getDouble("wingsound") - 1));
			}
		}
	}
}
