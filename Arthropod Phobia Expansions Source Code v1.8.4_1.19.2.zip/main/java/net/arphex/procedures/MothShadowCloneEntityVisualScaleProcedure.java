package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.arphex.network.ArphexModVariables;

public class MothShadowCloneEntityVisualScaleProcedure {
	public static double execute(LevelAccessor world) {
		double clonesize = 0;
		String once = "";
		return ArphexModVariables.MapVariables.get(world).clonesize;
	}
}
