package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.CentipedeEvictorEntity;

public class CentipedeEvictorLarvaeEntityDiesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		if (entity.getPersistentData().getBoolean("stronger") == true && !world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 18, 18, 18), e -> true).isEmpty()) {
			if (!world.getBlockState(new BlockPos(x + 1, y, z)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y, z)).canOcclude() && !world.getBlockState(new BlockPos(x, y, z + 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x, y, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 1, y, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 1, y, z + 2)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 2, y, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y, z + 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 1, y, z)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y, z)).canOcclude() && !world.getBlockState(new BlockPos(x, y, z - 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x, y, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y, z - 2)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 2, y, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y, z - 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 1, y, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y, z + 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 2, y, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 1, y, z - 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 1, y, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y, z - 2)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 2, y, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 1, y + 1, z)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y + 1, z)).canOcclude()
					&& !world.getBlockState(new BlockPos(x, y + 1, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x, y + 1, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 1, y + 1, z + 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 1, y + 1, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y + 1, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y + 1, z + 2)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 2, y + 1, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y + 1, z)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y + 1, z)).canOcclude()
					&& !world.getBlockState(new BlockPos(x, y + 1, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x, y + 1, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y + 1, z - 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 1, y + 1, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y + 1, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y + 1, z - 2)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 2, y + 1, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y + 1, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 1, y + 1, z + 2)).canOcclude()
					&& !world.getBlockState(new BlockPos(x - 2, y + 1, z + 1)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y + 1, z + 2)).canOcclude() && !world.getBlockState(new BlockPos(x - 2, y + 1, z + 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 1, y + 1, z - 1)).canOcclude() && !world.getBlockState(new BlockPos(x + 1, y + 1, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y + 1, z - 1)).canOcclude()
					&& !world.getBlockState(new BlockPos(x + 2, y + 1, z - 2)).canOcclude() && !world.getBlockState(new BlockPos(x + 2, y, z - 1)).canOcclude()) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(x, y, z)));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new CentipedeEvictorEntity(ArphexModEntities.CENTIPEDE_EVICTOR.get(), _level);
					entityToSpawn.moveTo(x, y, z, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 0, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 5, 3, 3, 3, 1);
			}
		}
	}
}
