package net.arphex.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.arphex.entity.HornetHarbingerGiantEntity;

public class HornetTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getDouble("randomsize") > 0.6) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, false, false));
		}
		if (entity.getPersistentData().getDouble("randomsize") > 0.9) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 1, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, false, false));
		}
		if (world.isEmptyBlock(new BlockPos(x, y - 0.1, z))) {
			entity.setShiftKeyDown(false);
			if (world.isEmptyBlock(new BlockPos(x + 0.5, y, z)) && world.isEmptyBlock(new BlockPos(x - 0.5, y, z)) && world.isEmptyBlock(new BlockPos(x, y, z + 0.5)) && world.isEmptyBlock(new BlockPos(x, y, z - 0.5))) {
				entity.setSprinting(false);
			} else {
				if (!(entity.getDeltaMovement().x() < 0.1 || entity.getDeltaMovement().z() < 0.1)) {
					entity.setSprinting(true);
				} else {
					entity.setSprinting(false);
				}
			}
		} else {
			entity.setShiftKeyDown(true);
		}
		if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
			if (!(entity.getPersistentData().getDouble("flywalk") > 1000)) {
				entity.getPersistentData().putDouble("flywalk", (entity.getPersistentData().getDouble("flywalk") + Mth.nextInt(RandomSource.create(), 0, 2)));
			} else {
				entity.getPersistentData().putDouble("flywalk", 0);
			}
		} else {
			entity.setSprinting(false);
			entity.getPersistentData().putDouble("flywalk", 1000);
			if (!(entity.getPersistentData().getDouble("flyboost") > 0)) {
				entity.getPersistentData().putDouble("flyboost", (Mth.nextInt(RandomSource.create(), 5, 40)));
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (entity instanceof HornetHarbingerGiantEntity && Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
						if (world instanceof Level _level) {
							if (!_level.isClientSide()) {
								_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:hornetbuzzlong")), SoundSource.HOSTILE, (float) 0.8,
										(float) Mth.nextDouble(RandomSource.create(), -0.8, 1.2));
							} else {
								_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:hornetbuzzlong")), SoundSource.HOSTILE, (float) 0.8, (float) Mth.nextDouble(RandomSource.create(), -0.8, 1.2), false);
							}
						}
					}
				} else {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:hornetbuzzshort")), SoundSource.HOSTILE, (float) 0.9,
									(float) Mth.nextDouble(RandomSource.create(), -0.8, 1.2));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:hornetbuzzshort")), SoundSource.HOSTILE, (float) 0.9, (float) Mth.nextDouble(RandomSource.create(), -0.8, 1.2), false);
						}
					}
				}
				if (entity.getY() < (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY() + 0.5) {
					entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 2), 0.3, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 2)));
				} else {
					entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX()), ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY()),
							((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
					entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 2), (-0.2), (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 2)));
				}
			} else {
				entity.getPersistentData().putDouble("flyboost", (entity.getPersistentData().getDouble("flyboost") - 1));
			}
		}
		if (entity.getPersistentData().getDouble("flywalk") < 150) {
			entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x() / 8), (-0.4), (entity.getDeltaMovement().z() / 8)));
		}
		if (entity.isInWater()) {
			entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x() / 8), (Mth.nextDouble(RandomSource.create(), 0.3, 0.8)), (entity.getDeltaMovement().z() / 8)));
		}
	}
}
