package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModMobEffects;

public class WebbedOnEffectActiveTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 0) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 10, 0.8, 0.8, 0.8, 0);
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 1, true, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3, 1, true, false));
		}
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 1) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 20, 0.8, 0.8, 0.8, 0);
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 2, true, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3, 2, true, false));
		}
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 2) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 30, 0.8, 0.8, 0.8, 0);
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 3, true, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3, 3, true, false));
		}
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 3) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 50, 0.8, 0.8, 0.8, 0);
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 4, true, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3, 4, true, false));
		}
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) >= 4) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 60, 0.6, 0.6, 0.6, 0);
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 5, true, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 3, 5, true, false));
		}
	}
}
