package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.arphex.network.ArphexModVariables;
import net.arphex.entity.SpiderMothDwellerEntity;
import net.arphex.ArphexMod;

import java.util.Comparator;

public class SpiderMothDwellerOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 48, 48, 48), e -> true).isEmpty()) {
			entity.getPersistentData().putBoolean("spawnedawayfromplayer", false);
		} else {
			entity.getPersistentData().putBoolean("spawnedawayfromplayer", true);
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 300, 300, 300), e -> true).isEmpty()) {
				if (!world.getEntitiesOfClass(SpiderMothDwellerEntity.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).isEmpty()) {
					if (!entity.level.isClientSide())
						entity.discard();
				}
			}
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 400, 400, 400), e -> true).isEmpty()) {
				if ((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 300, 300, 300), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals >= 5) {
					if (!entity.level.isClientSide())
						entity.discard();
				}
			}
		}
		if (world instanceof ServerLevel _level) {
			LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
			entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(x, y, z)));
			entityToSpawn.setVisualOnly(true);
			_level.addFreshEntity(entityToSpawn);
		}
		entity.getPersistentData().putBoolean("growattack", false);
		ArphexModVariables.MapVariables.get(world).LookScareLock = "no";
		ArphexModVariables.MapVariables.get(world).syncData(world);
		ArphexModVariables.MapVariables.get(world).ShowOverlay = "true";
		ArphexModVariables.MapVariables.get(world).syncData(world);
		entity.getPersistentData().putString("playerlookedatmoth", "no");
		entity.getPersistentData().putString("dwellerwaiting", "far");
		entity.getPersistentData().putString("soundonce", "one");
		entity.getPersistentData().putString("chasemode", "no");
		ArphexModVariables.MapVariables.get(world).slightrandom = "first";
		ArphexModVariables.MapVariables.get(world).syncData(world);
		ArphexModVariables.MapVariables.get(world).attackcycle = Mth.nextInt(RandomSource.create(), 1, 9);
		ArphexModVariables.MapVariables.get(world).syncData(world);
		ArphexMod.queueServerWork(20, () -> {
			ArphexModVariables.MapVariables.get(world).LookScareLock = "no";
			ArphexModVariables.MapVariables.get(world).syncData(world);
			ArphexModVariables.MapVariables.get(world).ShowOverlay = "false";
			ArphexModVariables.MapVariables.get(world).syncData(world);
			entity.getPersistentData().putString("playerlookedatmoth", "no");
			entity.getPersistentData().putString("dwellerwaiting", "far");
			entity.getPersistentData().putString("chasemode", "no");
			entity.getPersistentData().putString("soundonce", "one");
		});
		ArphexMod.queueServerWork(2, () -> {
			ArphexModVariables.MapVariables.get(world).ShowOverlay = "false";
			ArphexModVariables.MapVariables.get(world).syncData(world);
		});
	}
}
