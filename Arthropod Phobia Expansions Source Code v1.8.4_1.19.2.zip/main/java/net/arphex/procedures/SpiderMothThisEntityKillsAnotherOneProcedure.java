package net.arphex.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.arphex.network.ArphexModVariables;
import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.SpiderMothLarvaeEntity;
import net.arphex.ArphexMod;

import java.util.Comparator;

public class SpiderMothThisEntityKillsAnotherOneProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("animcooldown", 25);
		if (entity instanceof Mob) {
			try {
				((Mob) entity).setTarget(null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = new SpiderMothLarvaeEntity(ArphexModEntities.SPIDER_MOTH_LARVAE.get(), _level);
			entityToSpawn.moveTo((entity.getX()), (entity.getY()), (entity.getZ()), 0, 0);
			entityToSpawn.setYBodyRot(0);
			entityToSpawn.setYHeadRot(0);
			entityToSpawn.setDeltaMovement(0, 0, 0);
			if (entityToSpawn instanceof Mob _mobToSpawn)
				_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
			world.addFreshEntity(entityToSpawn);
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.ghast.hurt")), SoundSource.HOSTILE, (float) 0.5, -5);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.ghast.hurt")), SoundSource.HOSTILE, (float) 0.5, -5, false);
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				ArphexModVariables.MapVariables.get(world).ShowOverlay = "true";
				ArphexModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscare")), SoundSource.HOSTILE, (float) 0.6, -5);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscare")), SoundSource.HOSTILE, (float) 0.6, -5, false);
			}
		}
		ArphexMod.queueServerWork(5, () -> {
			ArphexModVariables.MapVariables.get(world).ShowOverlay = "false";
			ArphexModVariables.MapVariables.get(world).syncData(world);
		});
		entity.setSprinting(false);
		ArphexMod.queueServerWork(3, () -> {
			entity.setSprinting(false);
		});
		ArphexMod.queueServerWork(6, () -> {
			entity.setSprinting(false);
		});
		ArphexMod.queueServerWork(9, () -> {
			entity.setSprinting(false);
		});
		ArphexMod.queueServerWork(12, () -> {
			entity.setSprinting(false);
		});
		ArphexMod.queueServerWork(15, () -> {
			entity.setSprinting(false);
		});
		ArphexMod.queueServerWork(18, () -> {
			entity.setSprinting(false);
		});
		ArphexMod.queueServerWork(19, () -> {
			entity.setSprinting(true);
		});
		if (!world.isEmptyBlock(new BlockPos(x, y + 1, z)) || !world.isEmptyBlock(new BlockPos(x, y + 2, z))) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.SOLID_SMOKE.get()), x, y, z, 40, 0.4, 0.4, 0.4, 0.2);
		}
	}
}
