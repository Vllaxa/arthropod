package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.configuration.ConfigurationSettingsConfiguration;

public class SpiderMothDwellerNaturalEntitySpawningConditionProcedure {
	public static boolean execute(LevelAccessor world) {
		return ((double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() == 2 && Mth.nextInt(RandomSource.create(), 1, 2) == 2
				|| (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() == 3 && Mth.nextInt(RandomSource.create(), 1, 3) == 2
				|| (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() == 3 && Mth.nextInt(RandomSource.create(), 1, 4) == 2 || (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() <= 1
				|| (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() >= 5)
				&& (world.getLevelData().isThundering() && ConfigurationSettingsConfiguration.DWELLER_REQUIRE_THUNDER.get() == true || ConfigurationSettingsConfiguration.DWELLER_REQUIRE_THUNDER.get() == false)
				&& ConfigurationSettingsConfiguration.SPAWN_DWELLER_NATURALLY.get() == true;
	}
}
