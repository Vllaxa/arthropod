package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;

import net.arphex.network.ArphexModVariables;
import net.arphex.configuration.ConfigurationSettingsConfiguration;
import net.arphex.ArphexMod;

import java.util.Comparator;

public class SpiderMothPlayerCollidesWithThisEntityProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty() && ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 349 && Mth.nextInt(RandomSource.create(), 1, 400) > 397
				|| (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 59 && Mth.nextInt(RandomSource.create(), 1, 300) > 297 && ConfigurationSettingsConfiguration.DWELLER_HEALTH.get() == true)) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false && entity.getPersistentData().getBoolean("spawnedawayfromplayer") == true
					&& !((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)).getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals > 4)) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 1000, 2, 2, 2, 1);
				ArphexMod.queueServerWork(60, () -> {
					if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty() && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 349) {
						if (!entity.level.isClientSide())
							entity.discard();
					}
					if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty() && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 59
							&& ConfigurationSettingsConfiguration.DWELLER_HEALTH.get() == true) {
						if (!entity.level.isClientSide())
							entity.discard();
					}
				});
			}
		}
	}
}
