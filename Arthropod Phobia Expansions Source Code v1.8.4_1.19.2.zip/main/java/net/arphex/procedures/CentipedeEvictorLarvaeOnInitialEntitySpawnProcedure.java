package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.entity.TinyCentipedeBreacherEntity;
import net.arphex.entity.CentipedeEvictorLarvaeEntity;
import net.arphex.entity.CentipedeEvictorEntity;
import net.arphex.ArphexMod;

public class CentipedeEvictorLarvaeOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (Mth.nextInt(RandomSource.create(), 1, 5) == 5) {
			if (!(!world.getEntitiesOfClass(CentipedeEvictorEntity.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty())) {
				if (entity instanceof CentipedeEvictorLarvaeEntity animatable)
					animatable.setTexture("centipedeevictorboss");
				entity.getPersistentData().putBoolean("stronger", true);
			}
		}
		if (entity instanceof TinyCentipedeBreacherEntity) {
			ArphexMod.queueServerWork(1200, () -> {
				if (!entity.level.isClientSide())
					entity.discard();
			});
		}
		entity.getPersistentData().putDouble("climbradius", 1.1);
	}
}
