package net.arphex.procedures;

import net.minecraft.world.entity.Entity;

public class CentipedeEvictorOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("climbradius", 2.1);
	}
}
