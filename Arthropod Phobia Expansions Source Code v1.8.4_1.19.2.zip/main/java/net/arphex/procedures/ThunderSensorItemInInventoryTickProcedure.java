package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.arphex.init.ArphexModMobEffects;

public class ThunderSensorItemInInventoryTickProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world.getLevelData().isThundering() && !(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.THUNDER_SENSE.get()) : false)) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.THUNDER_SENSE.get(), 20, 0, false, false));
		}
	}
}
