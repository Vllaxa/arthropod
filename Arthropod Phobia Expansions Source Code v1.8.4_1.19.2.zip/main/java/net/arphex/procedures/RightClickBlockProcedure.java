package net.arphex.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;

import net.arphex.init.ArphexModItems;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.WaterRoachEntity;
import net.arphex.entity.SpiderFlatEntity;
import net.arphex.entity.MaggotEntity;
import net.arphex.ArphexMod;

import javax.annotation.Nullable;

import java.util.Comparator;

@Mod.EventBusSubscriber
public class RightClickBlockProcedure {
	@SubscribeEvent
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		if (event.getHand() != event.getEntity().getUsedItemHand())
			return;
		execute(event, event.getLevel(), event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.BUCKET_OF_MAGGOTS.get()) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) 0.1, 0);
				entityToSpawn.setYBodyRot((float) 0.1);
				entityToSpawn.setYHeadRot((float) 0.1);
				entityToSpawn.setDeltaMovement(0.05, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) 0.2, 0);
				entityToSpawn.setYBodyRot((float) 0.2);
				entityToSpawn.setYHeadRot((float) 0.2);
				entityToSpawn.setDeltaMovement(0.1, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) (-0.1), 0);
				entityToSpawn.setYBodyRot((float) (-0.1));
				entityToSpawn.setYHeadRot((float) (-0.1));
				entityToSpawn.setDeltaMovement((-0.05), 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) (-0.2), 0);
				entityToSpawn.setYBodyRot((float) (-0.2));
				entityToSpawn.setYHeadRot((float) (-0.2));
				entityToSpawn.setDeltaMovement((-0.1), 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) 0.1);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0.05);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) 0.2);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0.5);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) (-0.1));
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, (-0.05));
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new MaggotEntity(ArphexModEntities.MAGGOT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) (-0.2));
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, (-0.1));
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (entity.getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(Items.BUCKET);
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof Player _player)
						_player.getInventory().setChanged();
				}
			}
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.BUCKET_OF_ROACHES.get()) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) 0.1, 0);
				entityToSpawn.setYBodyRot((float) 0.1);
				entityToSpawn.setYHeadRot((float) 0.1);
				entityToSpawn.setDeltaMovement(0.05, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) 0.2, 0);
				entityToSpawn.setYBodyRot((float) 0.2);
				entityToSpawn.setYHeadRot((float) 0.2);
				entityToSpawn.setDeltaMovement(0.1, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) (-0.1), 0);
				entityToSpawn.setYBodyRot((float) (-0.1));
				entityToSpawn.setYHeadRot((float) (-0.1));
				entityToSpawn.setDeltaMovement((-0.05), 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) (-0.2), 0);
				entityToSpawn.setYBodyRot((float) (-0.2));
				entityToSpawn.setYHeadRot((float) (-0.2));
				entityToSpawn.setDeltaMovement((-0.1), 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) 0.1);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0.05);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) 0.2);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0.1);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) (-0.1));
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, (-0.05));
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterRoachEntity(ArphexModEntities.WATER_ROACH.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, 0, (float) (-0.2));
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, (-0.1));
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (entity.getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(Items.BUCKET);
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof Player _player)
						_player.getInventory().setChanged();
				}
			}
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.SPIDER_FLAT_JAR.get()
				&& !(!world.getEntitiesOfClass(SpiderFlatEntity.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiderFlatEntity(ArphexModEntities.SPIDER_FLAT.get(), _level);
				entityToSpawn.moveTo(x, (y + 1), z, (float) 0.1, 0);
				entityToSpawn.setYBodyRot((float) 0.1);
				entityToSpawn.setYHeadRot((float) 0.1);
				entityToSpawn.setDeltaMovement(0.05, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			ArphexMod.queueServerWork(1, () -> {
				if (!world.getEntitiesOfClass(SpiderFlatEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty()) {
					if (((Entity) world.getEntitiesOfClass(SpiderFlatEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _toTame && entity instanceof Player _owner)
						_toTame.tame(_owner);
					if (!(entity.getDisplayName().getString()).equals("spider flat jar")) {
						((Entity) world.getEntitiesOfClass(SpiderFlatEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null))
								.setCustomName(Component.literal(((((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getDisplayName().getString()).replace("]", "")).replace("[", ""))));
						if (((Entity) world.getEntitiesOfClass(SpiderFlatEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _entity)
							_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getOrCreateTag().getDouble("spiderhealth")));
					}
				}
			});
			ArphexMod.queueServerWork(2, () -> {
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(ArphexModItems.SPIDER_JAR.get());
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof Player _player)
						_player.getInventory().setChanged();
				}
			});
		}
	}
}
