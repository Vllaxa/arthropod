package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderFlatEntity;
import net.arphex.entity.SpiderBroodEntity;

public class SpiderBroodOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SpiderFlatEntity && !(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.REGENERATION) : false)) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false));
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) / 2) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.SPIDER_BLOOD.get()), x, y, z, 25, 1, 1, 1, 0.4);
			}
		}
		if (world.isEmptyBlock(new BlockPos(x, y - 1, z)) && !entity.isOnGround()) {
			if (entity instanceof SpiderBroodEntity) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, (y + 1), z, 20, 0.1, 0.3, 0.1, 0);
			}
			if (entity instanceof SpiderWidowEntity) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 20, 1, 1, 1, 0);
			}
		}
		if (entity instanceof SpiderBroodEntity) {
			if (entity.getPersistentData().getDouble("webtime") > 150) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 5, false, false));
				entity.getPersistentData().putDouble("webtime", 0);
			}
			entity.getPersistentData().putDouble("webtime", (entity.getPersistentData().getDouble("webtime") + 1));
		}
		if (entity instanceof SpiderWidowEntity) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 20) {
				if (entity instanceof SpiderWidowEntity animatable)
					animatable.setTexture("spiderwidowmissinglegs");
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
			}
		}
		if ((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COBWEB) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5, 6, false, false));
		}
		if (entity instanceof SpiderWidowEntity) {
			if (entity.getPersistentData().getDouble("webtime") > 20) {
				entity.getPersistentData().putDouble("webtime", 0);
			}
			entity.getPersistentData().putDouble("webtime", (entity.getPersistentData().getDouble("webtime") + 1));
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				if (entity.getY() > (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY() + 0.8) {
					entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), (-2), Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
				}
			}
		}
		if (entity instanceof SpiderFlatEntity) {
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).isAlive())) {
					if (entity instanceof Mob) {
						try {
							((Mob) entity).setTarget(null);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		if (world.isEmptyBlock(new BlockPos(x, y - 1.1, z)) && world.isEmptyBlock(new BlockPos(x, y - 0.8, z)) && !entity.isOnGround()) {
			entity.setShiftKeyDown(true);
		} else {
			entity.setShiftKeyDown(false);
		}
	}
}
