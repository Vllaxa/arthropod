package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.ArphexMod;

public class SpiderMothLarvaeOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z, 100, 0.8, 0.5, 0.8, 1);
		ArphexMod.queueServerWork(10, () -> {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z, 100, 1, 1, 1, 0.5);
		});
	}
}
