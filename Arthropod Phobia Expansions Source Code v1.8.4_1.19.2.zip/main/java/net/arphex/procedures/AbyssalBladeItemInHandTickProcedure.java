package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModMobEffects;
import net.arphex.init.ArphexModItems;
import net.arphex.init.ArphexModEnchantments;
import net.arphex.ArphexMod;

import java.util.Map;

public class AbyssalBladeItemInHandTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		ArphexMod.queueServerWork(10, () -> {
			if (!(itemstack.getOrCreateTag().getBoolean("crafted") == true || EnchantmentHelper.getItemEnchantmentLevel(ArphexModEnchantments.WITHER_AURA.get(), itemstack) != 0
					|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BANE_OF_ARTHROPODS, itemstack) != 0 || EnchantmentHelper.getItemEnchantmentLevel(Enchantments.MOB_LOOTING, itemstack) != 0)) {
				(itemstack).enchant(ArphexModEnchantments.WITHER_AURA.get(), 3);
				(itemstack).enchant(Enchantments.BANE_OF_ARTHROPODS, 3);
				(itemstack).enchant(Enchantments.MOB_LOOTING, 3);
			}
		});
		if (entity.getPersistentData().getDouble("ringspin") <= 0) {
			entity.getPersistentData().putDouble("ringspin", 360);
		} else {
			entity.getPersistentData().putDouble("ringspin", (entity.getPersistentData().getDouble("ringspin") - 25));
		}
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.WITHER);
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(ArphexModMobEffects.NECROSIS.get());
		if (entity.isOnGround()) {
			entity.getPersistentData().putString("doublejumpmax", "reset");
		}
		if (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.SLOW_FALLING) : false) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						("execute as @a at @s rotated " + (entity.getPersistentData().getDouble("ringspin") + " 3 as @p run particle arphex:abyssal_crystal_particle ^ ^0.3 ^1.5")));
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						("execute as @a at @s rotated " + (entity.getPersistentData().getDouble("ringspin") + " 3 as @p run particle arphex:heavy_red_smoke ^ ^0.3 ^1.5")));
			world.addParticle((SimpleParticleType) (ArphexModParticleTypes.HEAVY_RED_SMOKE.get()), x, (y - 1), z, 0, 0, 0);
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.MANTLE_OF_VITALITY.get()) {
			if (!(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.KNOCKBACK, itemstack) != 0)) {
				(itemstack).enchant(Enchantments.KNOCKBACK, 3);
			}
		} else {
			{
				Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
				if (_enchantments.containsKey(Enchantments.KNOCKBACK)) {
					_enchantments.remove(Enchantments.KNOCKBACK);
					EnchantmentHelper.setEnchantments(_enchantments, itemstack);
				}
			}
		}
	}
}
