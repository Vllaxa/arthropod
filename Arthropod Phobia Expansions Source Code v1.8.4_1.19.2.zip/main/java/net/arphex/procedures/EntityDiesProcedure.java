package net.arphex.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;

import net.arphex.network.ArphexModVariables;
import net.arphex.init.ArphexModParticleTypes;
import net.arphex.entity.SpiderMothDwellerEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntityDiesProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof SpiderMothDwellerEntity && sourceentity instanceof Player) {
			if ((sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals <= 3) {
				if (!world.isClientSide() && world.getServer() != null)
					world.getServer().getPlayerList().broadcastSystemMessage(Component.literal("It will return..."), false);
				{
					double _setval = 4;
					entity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mothsurvivals = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			} else {
				if ((sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals == 4) {
					{
						double _setval = 5;
						sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
							capability.mothsurvivals = _setval;
							capability.syncPlayerVariables(sourceentity);
						});
					}
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_RED_SMOKE.get()), x, y, z, 300, 3, 3, 3, 1);
				}
			}
		}
		if (entity instanceof Player && sourceentity instanceof SpiderMothDwellerEntity) {
			if (!sourceentity.level.isClientSide())
				sourceentity.discard();
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 25, 1, 1, 1, 0.5);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z, 50, 1, 1, 1, 0.5);
		}
	}
}
