package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;

import net.arphex.network.ArphexModVariables;

public class SpiderMothEntityDiesProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		ArphexModVariables.MapVariables.get(world).LookScareLock = "no";
		ArphexModVariables.MapVariables.get(world).syncData(world);
		entity.getPersistentData().putString("chasemode", "no");
	}
}
