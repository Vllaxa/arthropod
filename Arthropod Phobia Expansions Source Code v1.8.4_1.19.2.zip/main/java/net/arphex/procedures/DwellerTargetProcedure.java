package net.arphex.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.CaveSpider;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.network.ArphexModVariables;
import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModMobEffects;
import net.arphex.init.ArphexModItems;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.WebbedArrowEntity;
import net.arphex.entity.WaterRoachEntity;
import net.arphex.entity.TinyCentipedeBreacherEntity;
import net.arphex.entity.TeleportGhostEntity;
import net.arphex.entity.TamedTarantulaEntity;
import net.arphex.entity.SunScorpionTinyEntity;
import net.arphex.entity.SunScorpionEntity;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderMothLarvaeEntity;
import net.arphex.entity.SpiderMothDwellerEntity;
import net.arphex.entity.SpiderLurkerEntity;
import net.arphex.entity.SpiderLarvaeTinyEntity;
import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.entity.SpiderGoliathEntity;
import net.arphex.entity.SpiderFunnelEntity;
import net.arphex.entity.SpiderFlatEntity;
import net.arphex.entity.SpiderBroodEntity;
import net.arphex.entity.SilverfishSpectreEntity;
import net.arphex.entity.MaggotEntity;
import net.arphex.entity.LongLegsTinyEntity;
import net.arphex.entity.LongLegsEntity;
import net.arphex.entity.HornetHarbingerGiantEntity;
import net.arphex.entity.HornetHarbingerEntity;
import net.arphex.entity.CentipedeStalkerEntity;
import net.arphex.entity.CentipedeEvictorLarvaeEntity;
import net.arphex.entity.CentipedeEvictorEntity;
import net.arphex.entity.BloodWormEntity;
import net.arphex.entity.BloodProjectileEntity;
import net.arphex.entity.BeetleTickMiteEntity;
import net.arphex.entity.BeetleRhinoEntity;
import net.arphex.entity.AntGiantEntity;
import net.arphex.ArphexMod;

import javax.annotation.Nullable;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

@Mod.EventBusSubscriber
public class DwellerTargetProcedure {
	@SubscribeEvent
	public static void onEntitySetsAttackTarget(LivingChangeTargetEvent event) {
		execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getOriginalTarget(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (sourceentity instanceof SpiderMothDwellerEntity) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(
						new CommandSourceStack(CommandSource.NULL, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"effect clear @e[type=arphex:spider_moth_dweller,limit=1,distance=..7] slow_falling");
			if ((entity.getPersistentData().getString("chasemode")).equals("chasing")) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), (sourceentity.getDeltaMovement().y()), Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
			}
			if (entity instanceof SpiderMothLarvaeEntity) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			if (entity instanceof Player && entity.getPersistentData().getBoolean("creativespectator") == true || !entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(10 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (entityiterator == entity && entity.isAlive()) {
						if (!(sourceentity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.MOVEMENT_SLOWDOWN) : false)) {
							if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
								_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 30, 0, true, false));
						}
					}
				}
			}
			if (!(entity.getPersistentData().getBoolean("growattack") == true || (sourceentity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow"))) {
				if (sourceentity.getX() + 2.1 > entity.getX() && sourceentity.getX() - 2.1 < entity.getX() && sourceentity.getY() + 1 > entity.getY() && sourceentity.getY() - 1 < entity.getY() && sourceentity.getZ() + 2.1 > entity.getZ()
						&& sourceentity.getZ() - 2.1 < entity.getZ()) {
					sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 7, true, false));
					if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 3, true, false));
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 5, 3, true, false));
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p[distance=..3] minecraft:nausea 4 3");
				}
			}
			if (sourceentity.isInWater()) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.BUBBLE_POP, x, y, z, 30, 2, 2, 2, 0.3);
			}
			if (entity.isInWater() && Mth.nextInt(RandomSource.create(), 1, 200) == 5) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new TeleportGhostEntity(ArphexModEntities.TELEPORT_GHOST.get(), _level);
					entityToSpawn.moveTo((sourceentity.getX()), (sourceentity.getY()), (sourceentity.getZ()), world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
			if ((ArphexModVariables.MapVariables.get(world).ShowOverlay).equals("true")) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), 0.7, Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
				ArphexMod.queueServerWork(15, () -> {
					sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
					sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
				});
			}
			if (sourceentity.getPersistentData().getBoolean("growattack") == true) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("redglow");
			}
		}
		if (sourceentity instanceof SpiderLarvaeEntity) {
			if (sourceentity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.LEVITATION);
			if (sourceentity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.SLOW_FALLING);
		}
		if (sourceentity instanceof LongLegsEntity || sourceentity instanceof LongLegsTinyEntity || sourceentity instanceof SpiderLarvaeEntity || sourceentity instanceof SpiderLarvaeTinyEntity || sourceentity instanceof SunScorpionTinyEntity
				|| sourceentity instanceof SunScorpionEntity || sourceentity instanceof SpiderFlatEntity || sourceentity instanceof BloodWormEntity || sourceentity instanceof CentipedeEvictorLarvaeEntity || sourceentity instanceof AntGiantEntity
				|| sourceentity instanceof WaterRoachEntity || sourceentity instanceof BeetleRhinoEntity || sourceentity instanceof HornetHarbingerEntity || sourceentity instanceof HornetHarbingerGiantEntity
				|| sourceentity instanceof TamedTarantulaEntity || sourceentity instanceof SilverfishSpectreEntity || sourceentity instanceof SpiderFunnelEntity || sourceentity instanceof CentipedeStalkerEntity
				|| sourceentity instanceof SpiderGoliathEntity || sourceentity instanceof MaggotEntity || sourceentity instanceof TinyCentipedeBreacherEntity || sourceentity instanceof SpiderLurkerEntity
				|| sourceentity instanceof CentipedeEvictorEntity || sourceentity instanceof TeleportGhostEntity || sourceentity instanceof BeetleTickMiteEntity) {
			if (!entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if ((sourceentity instanceof LongLegsEntity || sourceentity instanceof LongLegsTinyEntity || sourceentity instanceof SpiderLarvaeEntity || sourceentity instanceof SpiderLarvaeTinyEntity || sourceentity instanceof BeetleTickMiteEntity)
				&& entity.getY() < sourceentity.getY() - 0.9) {
			sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
			sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), (-1), Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
		}
		if (entity instanceof SpiderBroodEntity && (sourceentity instanceof SpiderLarvaeEntity || sourceentity instanceof SpiderLarvaeTinyEntity || sourceentity instanceof CaveSpider || sourceentity instanceof Spider)) {
			if (sourceentity instanceof Mob) {
				try {
					((Mob) sourceentity).setTarget(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (sourceentity instanceof SpiderBroodEntity) {
			if (sourceentity instanceof Mob _entity)
				_entity.getNavigation().moveTo((entity.getX()), (entity.getY()), (entity.getZ()), 1);
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (entityiterator == entity) {
						if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 3, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2, false, false));
					}
				}
			}
			if (!entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (sourceentity instanceof SpiderWidowEntity) {
			if (!entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (sourceentity instanceof SpiderWidowEntity && (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) : false)
				&& !world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3((entity.getX()), (entity.getY()), (entity.getZ())), 7, 7, 7), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3((entity.getX()), (entity.getY()), (entity.getZ())), 7, 7, 7), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf((entity.getX()), (entity.getY()), (entity.getZ()))).findFirst().orElse(null)) == sourceentity) {
				if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 10, false, false));
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				sourceentity.setDeltaMovement(new Vec3((Math.cos((sourceentity.getYRot() - 90) * (Math.PI / 180)) / 2), (-1), (Math.sin((sourceentity.getYRot() - 90) * (Math.PI / 180)) / 2)));
			}
		}
		if (sourceentity instanceof SpiderWidowEntity && (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) : false)) {
			if (sourceentity.getPersistentData().getDouble("webtime") == 5) {
				sourceentity.setSprinting(true);
				{
					Entity _shootFrom = sourceentity;
					Level projectileLevel = _shootFrom.level;
					if (!projectileLevel.isClientSide()) {
						Projectile _entityToSpawn = new Object() {
							public Projectile getArrow(Level level, Entity shooter, float damage, int knockback) {
								AbstractArrow entityToSpawn = new WebbedArrowEntity(ArphexModEntities.WEBBED_ARROW.get(), level);
								entityToSpawn.setOwner(shooter);
								entityToSpawn.setBaseDamage(damage);
								entityToSpawn.setKnockback(knockback);
								entityToSpawn.setSilent(true);
								return entityToSpawn;
							}
						}.getArrow(projectileLevel, sourceentity, 5, 1);
						_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
						_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 4, (float) 0.05);
						projectileLevel.addFreshEntity(_entityToSpawn);
					}
				}
				ArphexMod.queueServerWork(20, () -> {
					sourceentity.setSprinting(false);
				});
			}
		}
		if (sourceentity instanceof SpiderWidowEntity && !(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) : false)) {
			ArphexMod.queueServerWork(10, () -> {
				sourceentity.setSprinting(false);
			});
		}
		if (sourceentity instanceof CentipedeEvictorEntity) {
			if (sourceentity.getX() + 15 > entity.getX() && sourceentity.getX() - 15 < entity.getX() && sourceentity.getY() + 15 > entity.getY() && sourceentity.getY() - 15 < entity.getY() && sourceentity.getZ() + 15 > entity.getZ()
					&& sourceentity.getZ() - 15 < entity.getZ()) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				sourceentity.setSprinting(true);
				sourceentity.getPersistentData().putBoolean("targetnear", true);
			} else {
				sourceentity.setSprinting(false);
				sourceentity.getPersistentData().putBoolean("targetnear", false);
			}
			if (!entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (sourceentity instanceof TinyCentipedeBreacherEntity) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute at @e[type=arphex:tiny_centipede_breacher,limit=1,sort=nearest] run tp @e[type=arphex:tiny_centipede_breacher,limit=1,sort=nearest] ^ ^ ^0.01");
			if (sourceentity.getY() > entity.getY()) {
				sourceentity.setDeltaMovement(new Vec3((sourceentity.getDeltaMovement().x()), (-0.5), (sourceentity.getDeltaMovement().z())));
			} else {
				sourceentity.setDeltaMovement(new Vec3((sourceentity.getDeltaMovement().x()), 0.5, (sourceentity.getDeltaMovement().z())));
			}
			if (!entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (sourceentity instanceof SpiderMothDwellerEntity) {
			if (sourceentity.getX() + 8 > entity.getX() && sourceentity.getX() - 8 < entity.getX() && sourceentity.getY() + 8 > entity.getY() && sourceentity.getY() - 8 < entity.getY() && sourceentity.getZ() + 8 > entity.getZ()
					&& sourceentity.getZ() - 8 < entity.getZ()) {
				sourceentity.setShiftKeyDown(false);
				if (sourceentity instanceof SpiderMothDwellerEntity) {
					((SpiderMothDwellerEntity) sourceentity).setAnimation("empty");
				}
			}
		}
		if (sourceentity.isAlive() && ((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(ArphexModItems.ABYSSAL_DAGGER.get())) : false)
				|| (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(ArphexModItems.ABYSSAL_BLADE.get())) : false)
				|| (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(ArphexModItems.ABYSSAL_PICKAXE.get())) : false))) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.ABYSSAL_DETECTOR.get(), 20, 0, false, false));
		}
		if (sourceentity instanceof SpiderFlatEntity && (sourceentity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false) && (entity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 50, false, false));
			if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 50, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 50, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 50, false, false));
		}
		if (sourceentity instanceof SpiderMothLarvaeEntity) {
			if (entity instanceof SpiderMothDwellerEntity) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			if (!world.getEntitiesOfClass(BloodProjectileEntity.class, AABB.ofSize(new Vec3(x, y, z), 8, 8, 8), e -> true).isEmpty()) {
				if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.SPIDER_SILK_TOUCH.get(), 10, 1, false, false));
			}
			if (sourceentity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.SPIDER_SILK_TOUCH.get()) : false) {
				sourceentity.setShiftKeyDown(true);
			}
			if (sourceentity.getPersistentData().getDouble("rushtime") > 250) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARCOAL.get()), x, y, z, 10, 0.3, 0.3, 0.3, 0.3);
				sourceentity.setShiftKeyDown(true);
				if (sourceentity.getX() + 2 > entity.getX() && sourceentity.getX() - 2 < entity.getX() && sourceentity.getY() + 2 > entity.getY() && sourceentity.getY() - 2 < entity.getY() && sourceentity.getZ() + 2 > entity.getZ()
						&& sourceentity.getZ() - 2 < entity.getZ()) {
					if (!(entity instanceof LivingEntity _livEnt255 && _livEnt255.isBlocking() || (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_BLADE.get()
							|| (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_BLADE.get())) {
						if (entity instanceof LivingEntity _entity)
							_entity.hurt(new DamageSource("moth_larvae").bypassArmor(), 3);
					}
				} else {
					sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
					sourceentity.setDeltaMovement(new Vec3((Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)) / 2), (-0.2), (Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180)) / 2)));
				}
			} else {
				if (!(sourceentity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.SPIDER_SILK_TOUCH.get()) : false)) {
					sourceentity.setShiftKeyDown(false);
				}
				if (sourceentity.getPersistentData().getDouble("rushtime") == 250) {
					sourceentity.setDeltaMovement(new Vec3((Math.cos((sourceentity.getYRot() - 90) * (Math.PI / 180)) / 4), 0.4, (Math.sin((sourceentity.getYRot() - 90) * (Math.PI / 180)) / 4)));
				}
			}
		}
		if ((sourceentity instanceof TamedTarantulaEntity || sourceentity instanceof SpiderFlatEntity) && (sourceentity instanceof TamableAnimal _tamEnt ? _tamEnt.isTame() : false)) {
			if (entity instanceof TamableAnimal _tamIsTamedBy && (sourceentity instanceof TamableAnimal _tamEnt ? (Entity) _tamEnt.getOwner() : null) instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 10, 99, false, false));
			}
		}
	}
}
