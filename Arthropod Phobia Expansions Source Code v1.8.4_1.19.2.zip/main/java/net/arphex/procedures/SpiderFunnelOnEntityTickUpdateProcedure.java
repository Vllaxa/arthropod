package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.arphex.init.ArphexModParticleTypes;

public class SpiderFunnelOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!entity.isOnGround()) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, (y + 1), z, 50, 0.1, 0.1, 0.1, 0.1);
		}
		if (world.isEmptyBlock(new BlockPos(x, y - 1, z))) {
			entity.setShiftKeyDown(true);
		} else {
			entity.setShiftKeyDown(false);
		}
	}
}
