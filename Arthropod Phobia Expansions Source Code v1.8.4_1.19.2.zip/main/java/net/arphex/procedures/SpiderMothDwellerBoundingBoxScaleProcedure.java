package net.arphex.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.arphex.entity.SpiderMothDwellerEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class SpiderMothDwellerBoundingBoxScaleProcedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		return execute(null, world, x, y, z, entity);
	}

	private static double execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return 0;
		double dwellerhitbox = 0;
		if (entity instanceof SpiderMothDwellerEntity) {
			if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 8, 8, 8), e -> true).isEmpty()) || world.getBlockState(new BlockPos(x, y + 1, z)).canOcclude() || world.getBlockState(new BlockPos(x - 1, y, z + 1)).canOcclude()
					|| world.getBlockState(new BlockPos(x + 1, y, z - 1)).canOcclude() || world.getBlockState(new BlockPos(x - 1, y, z - 1)).canOcclude() || world.getBlockState(new BlockPos(x + 1, y, z + 1)).canOcclude()
					|| world.getBlockState(new BlockPos(x + 1, y, z)).canOcclude() || world.getBlockState(new BlockPos(x - 1, y, z)).canOcclude() || world.getBlockState(new BlockPos(x, y, z + 1)).canOcclude()
					|| world.getBlockState(new BlockPos(x, y, z - 1)).canOcclude() || world.getBlockState(new BlockPos(x + 1, y + 1, z)).canOcclude() || world.getBlockState(new BlockPos(x - 1, y + 1, z)).canOcclude()
					|| world.getBlockState(new BlockPos(x, y + 1, z + 1)).canOcclude() || world.getBlockState(new BlockPos(x, y + 1, z - 1)).canOcclude()) {
				dwellerhitbox = 0.99;
			} else {
				dwellerhitbox = 1.5;
			}
		}
		return dwellerhitbox;
	}
}
