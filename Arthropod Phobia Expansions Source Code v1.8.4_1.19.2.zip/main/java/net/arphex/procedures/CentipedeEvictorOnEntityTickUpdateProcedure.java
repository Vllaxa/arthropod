package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.WaterRoachEntity;
import net.arphex.entity.TinyCentipedeBreacherEntity;
import net.arphex.entity.MaggotEntity;
import net.arphex.entity.CentipedeEvictorLarvaeEntity;
import net.arphex.entity.CentipedeEvictorEntity;

import java.util.Comparator;

public class CentipedeEvictorOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof CentipedeEvictorEntity) {
			if (!(entity.getPersistentData().getDouble("timer") > 0)) {
				entity.getPersistentData().putDouble("timer", 1);
			} else {
				if (entity.getPersistentData().getDouble("timer") > 150) {
					entity.getPersistentData().putDouble("timer", 1);
				} else {
					if (entity.getPersistentData().getBoolean("targetnear") == false) {
						entity.getPersistentData().putDouble("timer", (entity.getPersistentData().getDouble("timer") + 1));
					} else {
						entity.getPersistentData().putDouble("timer", 1);
					}
				}
			}
			if (entity.getPersistentData().getDouble("timer") == 150) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new TinyCentipedeBreacherEntity(ArphexModEntities.TINY_CENTIPEDE_BREACHER.get(), _level);
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
		}
		if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
			if (entity instanceof CentipedeEvictorEntity) {
				entity.getPersistentData().putDouble("timer", 1);
			}
			entity.setSprinting(false);
		} else {
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).isAlive())) {
				if (entity instanceof Mob) {
					try {
						((Mob) entity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (entity instanceof CentipedeEvictorEntity) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARCOAL.get()), x, y, z, (int) (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1), 1, 1, 1, 0.5);
		}
		if (world.isEmptyBlock(new BlockPos(x, y - 2, z)) && world.isEmptyBlock(new BlockPos(x, y - 1, z)) && !entity.isOnGround()) {
			entity.setShiftKeyDown(true);
		} else {
			entity.setShiftKeyDown(false);
		}
		if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null && !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty())) {
			if (!world.getEntitiesOfClass(WaterRoachEntity.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty()) {
				if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(WaterRoachEntity.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
			} else {
				if (!world.getEntitiesOfClass(MaggotEntity.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty()) {
					if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(MaggotEntity.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
						_entity.setTarget(_ent);
				} else {
					if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty()) {
						if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
							_entity.setTarget(_ent);
					}
				}
			}
			if (!entity.isOnGround()) {
				if (!world.isEmptyBlock(new BlockPos(x + 1, y, z))) {
					entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + 1), y, z));
				} else {
					if (!world.isEmptyBlock(new BlockPos(x - 1, y, z))) {
						entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x - 1), y, z));
					} else {
						if (!world.isEmptyBlock(new BlockPos(x, y, z + 1))) {
							entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(x, y, (z + 1)));
						} else {
							if (!world.isEmptyBlock(new BlockPos(x, y, z - 1))) {
								entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(x, y, (z - 1)));
							} else {
								entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x - 1), y, (z - 1)));
							}
						}
					}
				}
			}
		}
		if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
			if (!entity.isOnGround() && entity.getY() > (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY()) {
				if (!world.isEmptyBlock(new BlockPos(x + 1, y, z))) {
					entity.setDeltaMovement(new Vec3((Mth.nextDouble(RandomSource.create(), -0.5, 0.5)), (-0.5), (Mth.nextDouble(RandomSource.create(), -0.5, 0.5))));
				} else {
					if (!world.isEmptyBlock(new BlockPos(x - 1, y, z))) {
						entity.setDeltaMovement(new Vec3((Mth.nextDouble(RandomSource.create(), -0.5, 0.5)), (-0.5), (Mth.nextDouble(RandomSource.create(), -0.5, 0.5))));
					} else {
						if (!world.isEmptyBlock(new BlockPos(x, y, z + 1))) {
							entity.setDeltaMovement(new Vec3((Mth.nextDouble(RandomSource.create(), -0.5, 0.5)), (-0.5), (Mth.nextDouble(RandomSource.create(), -0.5, 0.5))));
						} else {
							if (!world.isEmptyBlock(new BlockPos(x, y, z - 1))) {
								entity.setDeltaMovement(new Vec3((Mth.nextDouble(RandomSource.create(), -0.5, 0.5)), (-0.5), (Mth.nextDouble(RandomSource.create(), -0.5, 0.5))));
							} else {
								entity.setDeltaMovement(new Vec3((Mth.nextDouble(RandomSource.create(), -0.5, 0.5)), (-0.5), (Mth.nextDouble(RandomSource.create(), -0.5, 0.5))));
							}
						}
					}
				}
			}
		}
		if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.REGENERATION) : false)) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, false, false));
			if (entity instanceof CentipedeEvictorEntity) {
				entity.maxUpStep = 4;
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1, false, false));
			}
		}
		if (entity.getPersistentData().getBoolean("stronger") == true) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARCOAL.get()), x, y, z, 5, 0.3, 0.3, 0.3, 0.3);
		}
		if (entity.getPersistentData().getBoolean("stronger") == true && !(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.DAMAGE_BOOST) : false)) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, false, false));
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < (entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) / 3) {
			if (entity instanceof CentipedeEvictorEntity animatable)
				animatable.setTexture("centipedeevictorbossmissinglegs");
			if ((entity instanceof CentipedeEvictorLarvaeEntity animatable ? animatable.getTexture() : "null").equals("centipedeevictorboss")) {
				if (entity instanceof CentipedeEvictorLarvaeEntity animatable)
					animatable.setTexture("centipedeevictorbossmissinglegs");
			} else {
				if ((entity instanceof CentipedeEvictorLarvaeEntity animatable ? animatable.getTexture() : "null").equals("centipedeevictor")) {
					if (entity instanceof CentipedeEvictorLarvaeEntity animatable)
						animatable.setTexture("centipedeevictorlegsmissing");
				}
			}
			if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.MOVEMENT_SLOWDOWN) : false)) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
			}
		} else {
			if (entity instanceof CentipedeEvictorEntity animatable)
				animatable.setTexture("centipedeevictorboss");
			if ((entity instanceof CentipedeEvictorLarvaeEntity animatable ? animatable.getTexture() : "null").equals("centipedeevictorbossmissinglegs")) {
				if (entity instanceof CentipedeEvictorLarvaeEntity animatable)
					animatable.setTexture("centipedeevictorboss");
			} else {
				if ((entity instanceof CentipedeEvictorLarvaeEntity animatable ? animatable.getTexture() : "null").equals("centipedeevictor")) {
					if (entity instanceof CentipedeEvictorLarvaeEntity animatable)
						animatable.setTexture("centipedeevictor");
				}
			}
		}
		if (entity instanceof CentipedeEvictorLarvaeEntity) {
			if (entity instanceof Mob _entity && (((Entity) world.getEntitiesOfClass(CentipedeEvictorEntity.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _ent)
				_entity.setTarget(_ent);
		}
		if (world.getLevelData().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING) && entity instanceof CentipedeEvictorEntity) {
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace glass");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace glass_pane");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace acacia_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace bamboo_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace birch_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cherry_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace crimson_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace dark_oak_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace jungle_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace mangrove_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace oak_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace spruce_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace warped_door");
			}
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 30, 30, 30), e -> true).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace oak_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace azalea_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace acacia_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace dark_oak_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cherry_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace flowering_azalea_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace jungle_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace mangrove_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace spruce_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace birch_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cobweb");
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).isEmpty() && !(!world.getEntitiesOfClass(WaterRoachEntity.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).isEmpty())
				&& !(!world.getEntitiesOfClass(MaggotEntity.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).isEmpty())) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof Mob _entity)
					_entity.getNavigation().moveTo((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ()), 1.4);
				if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
			}
		}
	}
}
