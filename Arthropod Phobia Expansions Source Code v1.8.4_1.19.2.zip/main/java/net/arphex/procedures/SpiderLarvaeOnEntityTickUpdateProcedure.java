package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.WebFunnelEntity;
import net.arphex.entity.SpiderLarvaeTinyEntity;
import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.entity.SpiderBroodEntity;

import java.util.Comparator;

public class SpiderLarvaeOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!(!world.getEntitiesOfClass(WebFunnelEntity.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty()) && !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 80, 80, 80), e -> true).isEmpty())
				&& world.getBlockState(new BlockPos(x + 1, y, z)).canOcclude() && world.getBlockState(new BlockPos(x - 1, y, z)).canOcclude() && world.getBlockState(new BlockPos(x, y, z - 1)).canOcclude()
				&& world.getBlockState(new BlockPos(x, y, z + 1)).canOcclude()) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WebFunnelEntity(ArphexModEntities.WEB_FUNNEL.get(), _level);
				entityToSpawn.moveTo((Math.ceil(x) - 0.5), Math.floor(y), (Math.ceil(z) - 0.5), 0, 0);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (world.isEmptyBlock(new BlockPos(x, y - 0.5, z)) && !(entity.isOnGround() && !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty()))) {
			if (world.getBlockState(new BlockPos(x, y + 0.7, z)).canOcclude()) {
				entity.setShiftKeyDown(false);
				entity.setSprinting(true);
			} else {
				entity.setShiftKeyDown(true);
				entity.setSprinting(false);
			}
		} else {
			entity.setShiftKeyDown(false);
			entity.setSprinting(false);
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("spidergrab") == true) {
				entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), y, (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
				entity.setDeltaMovement(new Vec3(0, 0, 0));
			}
		}
		if (entity instanceof Mob _entity && (((Entity) world.getEntitiesOfClass(SpiderBroodEntity.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
			Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
				return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
			}
		}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _ent)
			_entity.setTarget(_ent);
		if (world.isEmptyBlock(new BlockPos(x, y, z)) && (!world.isEmptyBlock(new BlockPos(x, y + 3, z)) || !world.isEmptyBlock(new BlockPos(x, y + 2, z)))) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 5, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 5, 1, false, false));
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 1, 0, 1, 0, 0);
		}
		if (!(world.isEmptyBlock(new BlockPos(x, y, z)) && world.isEmptyBlock(new BlockPos(x + 0.7, y, z)) && world.isEmptyBlock(new BlockPos(x - 0.7, y, z)) && world.isEmptyBlock(new BlockPos(x, y, z + 0.7))
				&& world.isEmptyBlock(new BlockPos(x, y, z - 0.7)))) {
			if (Mth.nextInt(RandomSource.create(), 1, 200) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 15, 0, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 30, 0, false, false));
			}
		}
		if ((world.getBlockState(new BlockPos(x, y, z))).getBlock() == Blocks.COBWEB) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5, 6, false, false));
		}
		if (entity instanceof SpiderLarvaeEntity) {
			if (((entity instanceof SpiderLarvaeEntity animatable ? animatable.getTexture() : "null").equals("spiderwidow") || (entity instanceof SpiderLarvaeEntity animatable ? animatable.getTexture() : "null").equals("spiderlarvae4"))
					&& !(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.DAMAGE_RESISTANCE) : false)) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 1, false, false));
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 1, 1, 1), e -> true).isEmpty()) {
			entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 1, 1, 1), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 1, 1, 1), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 1, 1, 1), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
			if (entity instanceof SpiderLarvaeEntity) {
				if (!(((SpiderLarvaeEntity) entity).animationprocedure).equals("animation.spiderlarvae.grab")) {
					if (entity instanceof SpiderLarvaeEntity) {
						((SpiderLarvaeEntity) entity).setAnimation("animation.spiderlarvae.grab");
					}
				}
			}
			if (entity instanceof SpiderLarvaeTinyEntity) {
				if (!(((SpiderLarvaeTinyEntity) entity).animationprocedure).equals("animation.spiderlarvae.grab")) {
					if (entity instanceof SpiderLarvaeTinyEntity) {
						((SpiderLarvaeTinyEntity) entity).setAnimation("animation.spiderlarvae.grab");
					}
				}
			}
		} else {
			if (entity instanceof SpiderLarvaeEntity) {
				if (entity instanceof SpiderLarvaeEntity) {
					((SpiderLarvaeEntity) entity).setAnimation("empty");
				}
			}
			if (entity instanceof SpiderLarvaeTinyEntity) {
				if (entity instanceof SpiderLarvaeTinyEntity) {
					((SpiderLarvaeTinyEntity) entity).setAnimation("empty");
				}
			}
		}
	}
}
