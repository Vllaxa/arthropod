package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.ArphexMod;

public class SpiderLarvaeEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SpiderLarvaeEntity) {
			if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty())) {
				entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() - 90) * (Math.PI / 180)) * 0.1), 0.5, (Math.sin((entity.getYRot() - 90) * (Math.PI / 180)) * 0.1)));
			} else {
				if (entity.getPersistentData().getBoolean("spidergrab") == false) {
					entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() - 90) * (Math.PI / 180)) * 0.1), 0.5, (Math.sin((entity.getYRot() - 90) * (Math.PI / 180)) * 0.1)));
				}
			}
		}
		if (entity instanceof SpiderLarvaeEntity) {
			((SpiderLarvaeEntity) entity).setAnimation("animation.spiderlarvae.grab");
		}
		ArphexMod.queueServerWork(20, () -> {
			if (entity instanceof SpiderLarvaeEntity) {
				((SpiderLarvaeEntity) entity).setAnimation("empty");
			}
		});
		entity.setSprinting(true);
		ArphexMod.queueServerWork(20, () -> {
			entity.setSprinting(false);
		});
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 3 && (entity instanceof SpiderLarvaeEntity animatable ? animatable.getTexture() : "null").equals("spiderwidow")) {
			if (entity instanceof SpiderLarvaeEntity animatable)
				animatable.setTexture("spiderwidowmissinglegs");
		}
	}
}
