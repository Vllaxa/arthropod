package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.arphex.network.ArphexModVariables;

public class JumpScareDisplayOverlayIngameProcedure {
	public static boolean execute(LevelAccessor world) {
		return (ArphexModVariables.MapVariables.get(world).ShowOverlay).equals("true");
	}
}
