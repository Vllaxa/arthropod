package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import net.arphex.init.ArphexModEntities;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderLarvaeTinyEntity;
import net.arphex.entity.SpiderLarvaeEntity;

import java.util.Comparator;

public class SpiderLarvaeOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty()) {
			if (entity instanceof SpiderLarvaeEntity animatable)
				animatable.setTexture("spiderwidow");
			entity.getPersistentData().putString("spidershade", "widow");
			if (entity instanceof Mob _entity && (((Entity) world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _ent)
				_entity.setTarget(_ent);
		} else {
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 3) {
				entity.getPersistentData().putString("spidershade", "2");
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae2");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 2) {
				entity.getPersistentData().putString("spidershade", "3");
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae3");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 60) == 1) {
				entity.getPersistentData().putString("spidershade", "4");
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae4");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 4) {
				entity.getPersistentData().putString("spidershade", "5");
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae5");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new SpiderLarvaeTinyEntity(ArphexModEntities.SPIDER_LARVAE_TINY.get(), _level);
					entityToSpawn.moveTo(x, y, z, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 0, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new SpiderLarvaeTinyEntity(ArphexModEntities.SPIDER_LARVAE_TINY.get(), _level);
					entityToSpawn.moveTo(x, y, z, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 0, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new SpiderLarvaeTinyEntity(ArphexModEntities.SPIDER_LARVAE_TINY.get(), _level);
					entityToSpawn.moveTo(x, y, z, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 0, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
		}
		entity.getPersistentData().putDouble("climbradius", 0.8);
	}
}
