package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;

import net.arphex.ArphexMod;

public class SpiderLurkerOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (!entity.isInWater()) {
			ArphexMod.queueServerWork(100, () -> {
				if (entity.getPersistentData().getDouble("drowntime") == 10) {
					if (entity instanceof LivingEntity _entity)
						_entity.hurt(new DamageSource("custom").bypassArmor(), 1);
				}
			});
		}
		if (entity.getPersistentData().getDouble("drowntime") < 20) {
			entity.getPersistentData().putDouble("drowntime", (entity.getPersistentData().getDouble("drowntime") + 1));
		} else {
			entity.getPersistentData().putDouble("drowntime", 1);
		}
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.POISON);
		if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.REGENERATION) : false)) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, false, false));
		}
	}
}
