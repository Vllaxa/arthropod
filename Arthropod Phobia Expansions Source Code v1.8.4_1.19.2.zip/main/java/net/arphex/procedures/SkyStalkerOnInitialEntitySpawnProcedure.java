package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.entity.SkyStalkerEntity;
import net.arphex.ArphexMod;

public class SkyStalkerOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(SkyStalkerEntity.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).isEmpty()) {
			if (!entity.level.isClientSide())
				entity.discard();
		}
		ArphexMod.queueServerWork(Mth.nextInt(RandomSource.create(), 4000, 6000), () -> {
			if (!entity.level.isClientSide())
				entity.discard();
		});
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 48, 48, 48), e -> true).isEmpty()) {
			entity.getPersistentData().putBoolean("spawnedaway", false);
		} else {
			entity.getPersistentData().putBoolean("spawnedaway", true);
		}
	}
}
