package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;

public class AbyssalBladeEntitySwingsItemProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getDouble("abysstimer") > 10 && entity.getPersistentData().getDouble("abysstimer") < 18) {
			if (!entity.isShiftKeyDown()) {
				entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 2), (entity.getDeltaMovement().y()), (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 2)));
			}
		}
	}
}
