package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.arphex.init.ArphexModMobEffects;

public class PowerHookHitsEntityProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (!(sourceentity == entity)) {
			entity.setDeltaMovement(
					new Vec3((Math.sin(Math.toRadians(sourceentity.getYRot() + 180)) * 2 * (-1.2)), ((Math.sin(Math.toRadians(0 - sourceentity.getXRot())) + 0.5) * 1.8), (Math.cos(Math.toRadians(sourceentity.getYRot())) * 2 * (-1.2))));
			if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) : false)) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 80, 1, false, false));
			} else {
				if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 0) {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 100, 2, false, false));
				} else {
					if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 1) {
						if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
							_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 120, 3, false, false));
					} else {
						if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) == 2) {
							if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
								_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 140, 3, false, false));
						} else {
							if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.WEBBED.get()) ? _livEnt.getEffect(ArphexModMobEffects.WEBBED.get()).getAmplifier() : 0) >= 3) {
								if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
									_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 200, 4, false, false));
							}
						}
					}
				}
			}
		}
	}
}
