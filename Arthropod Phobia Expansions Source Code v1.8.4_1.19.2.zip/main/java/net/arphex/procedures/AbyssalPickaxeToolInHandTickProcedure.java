package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;

import net.arphex.init.ArphexModMobEffects;
import net.arphex.init.ArphexModEnchantments;

import java.util.Map;

public class AbyssalPickaxeToolInHandTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (!(itemstack.getOrCreateTag().getBoolean("crafted") == true || EnchantmentHelper.getItemEnchantmentLevel(ArphexModEnchantments.WITHER_AURA.get(), itemstack) != 0
				|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY, itemstack) != 0 || EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, itemstack) != 0
				|| EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, itemstack) != 0)) {
			(itemstack).enchant(ArphexModEnchantments.WITHER_AURA.get(), 3);
			(itemstack).enchant(Enchantments.BLOCK_EFFICIENCY, 3);
			(itemstack).enchant(Enchantments.BLOCK_FORTUNE, 3);
		}
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.DARKNESS);
		if (world instanceof ServerLevel _level)
			_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 5, 2, 2, 2, 0.5);
		(itemstack).setDamageValue(0);
		if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY, itemstack) != 0) {
			if (entity.getPersistentData().getDouble("abysstimer") > 10) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.SPIDER_SILK_TOUCH.get(), 190, 0, false, false));
			}
			if (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.SPIDER_SILK_TOUCH.get()) : false) {
				if (!(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, itemstack) != 0)) {
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
						if (_enchantments.containsKey(Enchantments.BLOCK_FORTUNE)) {
							_enchantments.remove(Enchantments.BLOCK_FORTUNE);
							EnchantmentHelper.setEnchantments(_enchantments, itemstack);
						}
					}
					(itemstack).enchant(Enchantments.SILK_TOUCH, 3);
				}
			} else {
				if (!(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, itemstack) != 0)) {
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
						if (_enchantments.containsKey(Enchantments.SILK_TOUCH)) {
							_enchantments.remove(Enchantments.SILK_TOUCH);
							EnchantmentHelper.setEnchantments(_enchantments, itemstack);
						}
					}
					(itemstack).enchant(Enchantments.BLOCK_FORTUNE, 3);
				}
			}
		}
	}
}
