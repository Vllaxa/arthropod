package net.arphex.procedures;

import net.minecraft.world.entity.Entity;

public class HornetHarbingerOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("flyboost", 1);
	}
}
