package net.arphex.procedures;

import net.minecraft.world.entity.Entity;

import net.arphex.entity.TamedTarantulaEntity;

public class TamedTarantulaScaleProcedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		double tarantulasize = 0;
		if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula1")) {
			tarantulasize = 5;
		} else {
			if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula3")) {
				tarantulasize = 4.8;
			} else {
				if ((entity instanceof TamedTarantulaEntity animatable ? animatable.getTexture() : "null").equals("tarantula2")) {
					tarantulasize = 4.5;
				} else {
					tarantulasize = 4.2;
				}
			}
		}
		return tarantulasize;
	}
}
