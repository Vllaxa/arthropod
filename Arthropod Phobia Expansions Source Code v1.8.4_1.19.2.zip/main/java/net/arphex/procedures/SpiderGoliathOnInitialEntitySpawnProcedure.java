package net.arphex.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.entity.SpiderGoliathEntity;

public class SpiderGoliathOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
			if (entity instanceof SpiderGoliathEntity animatable)
				animatable.setTexture("tarantula1");
		} else {
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof SpiderGoliathEntity animatable)
					animatable.setTexture("tarantula2");
			} else {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (entity instanceof SpiderGoliathEntity animatable)
						animatable.setTexture("tarantula3");
				} else {
					if (entity instanceof SpiderGoliathEntity animatable)
						animatable.setTexture("tarantula4");
				}
			}
		}
		entity.getPersistentData().putDouble("climbradius", 1.5);
	}
}
