package net.arphex.procedures;

import net.minecraft.world.entity.Entity;

import net.arphex.entity.SpiderGoliathEntity;

public class SpiderGoliathEntityVisualScaleProcedure {
	public static double execute(Entity entity) {
		if (entity == null)
			return 0;
		double tarantulasize = 0;
		if ((entity instanceof SpiderGoliathEntity animatable ? animatable.getTexture() : "null").equals("tarantula1")) {
			tarantulasize = 6;
		} else {
			if ((entity instanceof SpiderGoliathEntity animatable ? animatable.getTexture() : "null").equals("tarantula3")) {
				tarantulasize = 5.3;
			} else {
				if ((entity instanceof SpiderGoliathEntity animatable ? animatable.getTexture() : "null").equals("tarantula2")) {
					tarantulasize = 4.7;
				} else {
					tarantulasize = 4;
				}
			}
		}
		return tarantulasize;
	}
}
