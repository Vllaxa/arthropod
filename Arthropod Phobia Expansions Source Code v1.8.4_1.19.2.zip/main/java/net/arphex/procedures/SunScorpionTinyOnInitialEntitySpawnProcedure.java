package net.arphex.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.entity.SpiderLarvaeTinyEntity;

public class SunScorpionTinyOnInitialEntitySpawnProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (Mth.nextInt(RandomSource.create(), 1, 3) == 3) {
			if (entity instanceof SpiderLarvaeTinyEntity animatable)
				animatable.setTexture("sunscorpion2");
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 99999, 0, false, false));
		}
		entity.getPersistentData().putDouble("climbradius", 0.9);
	}
}
