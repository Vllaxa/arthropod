package net.arphex.procedures;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.ItemStack;

import net.arphex.init.ArphexModEnchantments;

public class AbyssalBladeItemIsCraftedsmeltedProcedure {
	public static void execute(ItemStack itemstack) {
		(itemstack).enchant(ArphexModEnchantments.WITHER_AURA.get(), 3);
		(itemstack).enchant(Enchantments.BANE_OF_ARTHROPODS, 3);
		(itemstack).enchant(Enchantments.MOB_LOOTING, 3);
		itemstack.getOrCreateTag().putBoolean("crafted", true);
	}
}
