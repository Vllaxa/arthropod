package net.arphex.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.ArphexMod;

public class SpiderWidowEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double attackcycle = 0;
		if (entity.getPersistentData().getDouble("attackcycle") < 20) {
			entity.getPersistentData().putDouble("attackcycle", (entity.getPersistentData().getDouble("attackcycle") + 1));
		} else {
			entity.getPersistentData().putDouble("attackcycle", 1);
		}
		if (entity.getPersistentData().getDouble("attackcycle") == 2) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiderLarvaeEntity(ArphexModEntities.SPIDER_LARVAE.get(), _level);
				entityToSpawn.moveTo(x, y, z, 0, 0);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiderLarvaeEntity(ArphexModEntities.SPIDER_LARVAE.get(), _level);
				entityToSpawn.moveTo(x, y, z, 1, 0);
				entityToSpawn.setYBodyRot(1);
				entityToSpawn.setYHeadRot(1);
				entityToSpawn.setDeltaMovement(0, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 3), 1.3, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 3)));
			ArphexMod.queueServerWork(10, () -> {
				entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
			});
		}
		if (entity.getPersistentData().getDouble("attackcycle") == 12) {
			if (entity instanceof SpiderWidowEntity) {
				((SpiderWidowEntity) entity).setAnimation("animation.spiderwidow.aggressive");
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 100, 1, 1, 1, 0.5);
			ArphexMod.queueServerWork(20, () -> {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 200, 1, 1, 1, 0.7);
			});
			ArphexMod.queueServerWork(40, () -> {
				if (entity instanceof SpiderWidowEntity) {
					((SpiderWidowEntity) entity).setAnimation("empty");
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.WHITE_ASH, x, y, z, 200, 2, 2, 2, 1);
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @e[type=!arphex:spider_widow,distance=..5] arphex:webbed 4 0");
			});
		}
		if (entity.getPersistentData().getDouble("attackcycle") >= 13) {
			ArphexMod.queueServerWork(40, () -> {
				if (entity instanceof SpiderWidowEntity) {
					((SpiderWidowEntity) entity).setAnimation("empty");
				}
			});
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:creepy_arthropod_large")), SoundSource.HOSTILE, 1, (float) Math.random());
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:creepy_arthropod_large")), SoundSource.HOSTILE, 1, (float) Math.random(), false);
			}
		}
	}
}
