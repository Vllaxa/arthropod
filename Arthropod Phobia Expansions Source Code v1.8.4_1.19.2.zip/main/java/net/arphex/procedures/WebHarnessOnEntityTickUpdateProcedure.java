package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModItems;
import net.arphex.ArphexMod;

import java.util.Comparator;

public class WebHarnessOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), (entity.getPersistentData().getDouble("targetX")), (entity.getPersistentData().getDouble("targetY")), (entity.getPersistentData().getDouble("targetZ")),
					10, 0.1, 0.1, 0.1, 0.1);
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, (y + 3), z, 20, 0.1, 0.2, 0.1, 0.1);
		entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getPersistentData().getDouble("targetX")), (entity.getPersistentData().getDouble("targetY")), (entity.getPersistentData().getDouble("targetZ"))));
		if (Math.abs(entity.getDeltaMovement().x()) > 0.1 || Math.abs(entity.getDeltaMovement().z()) > 0.1 || Math.abs(entity.getDeltaMovement().y()) > 0.1) {
			ArphexMod.queueServerWork(60, () -> {
				if (Math.abs(entity.getDeltaMovement().x()) > 0.1 || Math.abs(entity.getDeltaMovement().z()) > 0.1 || Math.abs(entity.getDeltaMovement().y()) > 0.1) {
					ArphexMod.queueServerWork(10, () -> {
						if (Math.abs(entity.getDeltaMovement().x()) > 0.1 || Math.abs(entity.getDeltaMovement().z()) > 0.1 || Math.abs(entity.getDeltaMovement().y()) > 0.1) {
							if (!entity.level.isClientSide())
								entity.discard();
						}
					});
				}
			});
		}
		if (entity.getY() < entity.getPersistentData().getDouble("targetY") - 1) {
			if (entity.getX() > entity.getPersistentData().getDouble("targetX") - 3 && entity.getX() < entity.getPersistentData().getDouble("targetX") + 3 && entity.getY() > entity.getPersistentData().getDouble("targetY") - 3
					&& entity.getY() < entity.getPersistentData().getDouble("targetY") + 3 && entity.getZ() > entity.getPersistentData().getDouble("targetZ") - 3 && entity.getZ() < entity.getPersistentData().getDouble("targetZ") + 3) {
				entity.getPersistentData().putBoolean("solidlock", true);
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 60, 3, false, false));
				if (world.isEmptyBlock(new BlockPos(x, y + 2.6, z))) {
					entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 24), 0.1, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 24)));
				}
				if (!(world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX"), entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ"))).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX") + 1, entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ"))).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX") - 1, entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ"))).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX"), entity.getPersistentData().getDouble("targetY") + 1, entity.getPersistentData().getDouble("targetZ"))).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX"), entity.getPersistentData().getDouble("targetY") - 1, entity.getPersistentData().getDouble("targetZ"))).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX"), entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ") + 1)).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX"), entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ") - 1)).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX") + 1, entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ") - 1)).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX") - 1, entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ") - 1)).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX") + 1, entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ") + 1)).canOcclude()
						|| world.getBlockState(new BlockPos(entity.getPersistentData().getDouble("targetX") - 1, entity.getPersistentData().getDouble("targetY"), entity.getPersistentData().getDouble("targetZ") + 1)).canOcclude())) {
					if (!entity.level.isClientSide())
						entity.discard();
				}
			} else {
				entity.getPersistentData().putBoolean("solidlock", false);
				if (world.isEmptyBlock(new BlockPos(x, y + 2.6, z))) {
					entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 2), (entity.getPersistentData().getDouble("up")), (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 2)));
				}
			}
		} else {
			if (world.isEmptyBlock(new BlockPos(x, y + 2.5, z))) {
				entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) * entity.getPersistentData().getDouble("tetherspeed")), (entity.getDeltaMovement().y()),
						(Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) * entity.getPersistentData().getDouble("tetherspeed"))));
			}
		}
		if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty())) {
			if (!entity.level.isClientSide())
				entity.discard();
		}
		if (entity.isVehicle()) {
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty()) {
				if ((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.TARANTULA_TETHER.get()) {
					if (!(entity.getPersistentData().getBoolean("solidlock") == true)) {
						entity.getPersistentData().putDouble("tetherspeed", 2);
						entity.getPersistentData().putDouble("up", (Mth.nextDouble(RandomSource.create(), 0.5, 0.75)));
					} else {
						entity.getPersistentData().putDouble("tetherspeed", 0.1);
						entity.getPersistentData().putDouble("up", 0.1);
					}
				} else {
					if (!(entity.getPersistentData().getBoolean("solidlock") == true)) {
						entity.getPersistentData().putDouble("tetherspeed", 1);
						entity.getPersistentData().putDouble("up", (Mth.nextDouble(RandomSource.create(), 0.4, 0.65)));
					} else {
						entity.getPersistentData().putDouble("tetherspeed", 0.1);
						entity.getPersistentData().putDouble("up", 0.1);
					}
				}
			}
		} else {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"effect give @p[distance=..5] slow falling 2 0 true");
			ArphexMod.queueServerWork(10, () -> {
				if (!entity.isVehicle()) {
					if (!entity.level.isClientSide())
						entity.discard();
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p[distance=..5] slow falling 2 0 true");
				}
			});
		}
		if (entity.getPersistentData().getDouble("targetX") == 0 || entity.getPersistentData().getDouble("targetX") == 0 || entity.getPersistentData().getDouble("targetZ") == 0) {
			ArphexMod.queueServerWork(2, () -> {
				if (entity.getPersistentData().getDouble("targetX") == 0 || entity.getPersistentData().getDouble("targetX") == 0 || entity.getPersistentData().getDouble("targetZ") == 0) {
					if (!entity.level.isClientSide())
						entity.discard();
				}
			});
		}
	}
}
