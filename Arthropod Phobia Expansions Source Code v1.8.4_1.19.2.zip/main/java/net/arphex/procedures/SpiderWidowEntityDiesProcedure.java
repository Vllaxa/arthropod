package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.arphex.init.ArphexModParticleTypes;
import net.arphex.ArphexMod;

public class SpiderWidowEntityDiesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z, 300, 1, 1, 1, 0.3);
		ArphexMod.queueServerWork(5, () -> {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z, 300, 1, 1, 1, 0.3);
		});
	}
}
