package net.arphex.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.EntityDamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.arphex.network.ArphexModVariables;
import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModMobEffects;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.TeleportGhostEntity;
import net.arphex.entity.SpiderMothLarvaeEntity;
import net.arphex.entity.SpiderMothDwellerEntity;
import net.arphex.ArphexMod;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class SpiderMothEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (ArphexModVariables.MapVariables.get(world).attackcycle == 5 && !world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 150, 150, 150), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 150, 150, 150), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == true) {
				entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 3), 1.3, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 3)));
				ArphexMod.queueServerWork(10, () -> {
					entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
				});
			}
		}
		if (ArphexModVariables.MapVariables.get(world).attackcycle == 2) {
			entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 3), 1.3, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 3)));
			ArphexMod.queueServerWork(10, () -> {
				entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
			});
		}
		if (ArphexModVariables.MapVariables.get(world).attackcycle < Mth.nextInt(RandomSource.create(), 6, 8)) {
			ArphexModVariables.MapVariables.get(world).attackcycle = ArphexModVariables.MapVariables.get(world).attackcycle + 1;
			ArphexModVariables.MapVariables.get(world).syncData(world);
		} else {
			if (!(!world.getEntitiesOfClass(TeleportGhostEntity.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new TeleportGhostEntity(ArphexModEntities.TELEPORT_GHOST.get(), _level);
					entityToSpawn.moveTo(x, y, z, 0, 0);
					entityToSpawn.setYBodyRot(0);
					entityToSpawn.setYHeadRot(0);
					entityToSpawn.setDeltaMovement(0, 1, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
			ArphexModVariables.MapVariables.get(world).attackcycle = 1;
			ArphexModVariables.MapVariables.get(world).syncData(world);
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
				ArphexModVariables.MapVariables.get(world).slightrandom = "first";
				ArphexModVariables.MapVariables.get(world).syncData(world);
			} else {
				ArphexModVariables.MapVariables.get(world).slightrandom = "second";
				ArphexModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if (sourceentity instanceof SpiderMothLarvaeEntity || sourceentity instanceof TeleportGhostEntity || sourceentity instanceof TeleportGhostEntity) {
			if (sourceentity instanceof LivingEntity _entity)
				_entity.removeEffect(ArphexModMobEffects.MOTH_CURSE.get());
		} else {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.MOTH_CURSE.get(), 1200, 0, false, false));
		}
		if (!(new EntityDamageSource("lightning_bolt", sourceentity).getEntity() != new EntityDamageSource("lightning_bolt", sourceentity).getDirectEntity()
				|| new EntityDamageSource("in_wall", sourceentity).getEntity() != new EntityDamageSource("in_wall", sourceentity).getDirectEntity())) {
			if ((ArphexModVariables.MapVariables.get(world).attackcycle == 1 && (ArphexModVariables.MapVariables.get(world).slightrandom).equals("first")
					|| ArphexModVariables.MapVariables.get(world).attackcycle == 3 && (ArphexModVariables.MapVariables.get(world).slightrandom).equals("second")) && entity.getPersistentData().getBoolean("growattack") == false) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, Mth.nextInt(RandomSource.create(), 30, 60), 12, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 120, 6, false, false));
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
							.collect(Collectors.toList());
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof LivingEntity _entity && !_entity.level.isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, Mth.nextInt(RandomSource.create(), 12, 25), 12, false, false));
					}
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 400, 4, 4, 4, 0.2);
				ArphexMod.queueServerWork(75, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @e[type=!arphex:spider_moth_dweller,distance=..6] wither 5 3");
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 30, 3, 0.3, 3, 0.5);
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 20, 3, 0.3, 3, 0.5);
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p[distance=..8] wither 6 6");
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 3, false, false));
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = new TeleportGhostEntity(ArphexModEntities.TELEPORT_GHOST.get(), _level);
						entityToSpawn.moveTo(x, y, z, 0, 0);
						entityToSpawn.setYBodyRot(0);
						entityToSpawn.setYHeadRot(0);
						entityToSpawn.setDeltaMovement(0, 0, 0);
						if (entityToSpawn instanceof Mob _mobToSpawn)
							_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
						world.addFreshEntity(entityToSpawn);
					}
				});
			}
			if (ArphexModVariables.MapVariables.get(world).attackcycle == 8 && (ArphexModVariables.MapVariables.get(world).slightrandom).equals("first") || ArphexModVariables.MapVariables.get(world).attackcycle == 4) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_RED_SMOKE.get()), x, y, z, 30, 3, 3, 3, 0.3);
				if (Mth.nextInt(RandomSource.create(), 1, 7) == 7) {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = new SpiderMothLarvaeEntity(ArphexModEntities.SPIDER_MOTH_LARVAE.get(), _level);
						entityToSpawn.moveTo(x, y, z, 0, 0);
						entityToSpawn.setYBodyRot(0);
						entityToSpawn.setYHeadRot(0);
						entityToSpawn.setDeltaMovement(0, 0, 0);
						if (entityToSpawn instanceof Mob _mobToSpawn)
							_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
						world.addFreshEntity(entityToSpawn);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = new TeleportGhostEntity(ArphexModEntities.TELEPORT_GHOST.get(), _level);
						entityToSpawn.moveTo(x, y, z, 0, 0);
						entityToSpawn.setYBodyRot(0);
						entityToSpawn.setYHeadRot(0);
						entityToSpawn.setDeltaMovement(0, 0, 0);
						if (entityToSpawn instanceof Mob _mobToSpawn)
							_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
						world.addFreshEntity(entityToSpawn);
					}
				}
				ArphexMod.queueServerWork(20, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute as @e[type=arphex:spider_moth_dweller,limit=1,sort=nearest] run data merge entity @s {Invulnerable:1}");
					entity.getPersistentData().putBoolean("growattack", true);
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("redglow");
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 2, false, false));
				});
				ArphexMod.queueServerWork(40, () -> {
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 200, 3, 3, 3, 0);
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20, 5, false, false));
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20, 5, false, false));
				});
				ArphexMod.queueServerWork(60, () -> {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20, 6, false, false));
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 400, 4, 4, 4, 0.2);
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 50, 3, 3, 3, 0.5);
				});
				ArphexMod.queueServerWork(75, () -> {
					entity.getPersistentData().putBoolean("growattack", false);
				});
			}
		}
		ArphexMod.queueServerWork(1, () -> {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("fullshadow");
		});
		ArphexMod.queueServerWork(20, () -> {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("horrormothfixed");
		});
	}
}
