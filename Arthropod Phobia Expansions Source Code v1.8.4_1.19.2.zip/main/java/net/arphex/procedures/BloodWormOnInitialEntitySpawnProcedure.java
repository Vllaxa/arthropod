package net.arphex.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.arphex.entity.WaterRoachEntity;
import net.arphex.entity.SilverfishSpectreEntity;
import net.arphex.entity.BloodWormEntity;
import net.arphex.entity.BeetleTickMiteEntity;
import net.arphex.entity.AntGiantEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class BloodWormOnInitialEntitySpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SilverfishSpectreEntity) {
			entity.getPersistentData().putDouble("randomsize", (Mth.nextDouble(RandomSource.create(), 0.6, 1.7)));
		}
		if (entity instanceof BloodWormEntity || entity instanceof AntGiantEntity) {
			entity.getPersistentData().putDouble("randomsize", (Mth.nextDouble(RandomSource.create(), 0.3, 1.5)));
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof BloodWormEntity animatable)
					animatable.setTexture("bloodworm2");
			}
		}
		if (entity instanceof WaterRoachEntity) {
			entity.getPersistentData().putDouble("randomsize", (Mth.nextDouble(RandomSource.create(), 0.3, 0.9)));
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof WaterRoachEntity animatable)
					animatable.setTexture("waterroach2noclaws");
			} else {
				if (Mth.nextInt(RandomSource.create(), 1, 4) == 2) {
					if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
						if (entity instanceof WaterRoachEntity animatable)
							animatable.setTexture("waterroach2");
					} else {
						if (entity instanceof WaterRoachEntity animatable)
							animatable.setTexture("waterroach");
					}
				}
			}
		}
		if (entity instanceof BeetleTickMiteEntity) {
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (entity instanceof BeetleTickMiteEntity animatable)
						animatable.setTexture("beetletickmiteb");
				} else {
					if (entity instanceof BeetleTickMiteEntity animatable)
						animatable.setTexture("beetletickmitem");
				}
			}
		}
		if (entity instanceof BloodWormEntity) {
			entity.getPersistentData().putDouble("climbradius", 1);
		}
		if (entity instanceof WaterRoachEntity) {
			entity.getPersistentData().putDouble("climbradius", 0.9);
		}
		if (entity instanceof AntGiantEntity) {
			entity.getPersistentData().putDouble("climbradius", 0.5);
		}
		if (entity instanceof SilverfishSpectreEntity) {
			entity.getPersistentData().putDouble("climbradius", 0.7);
		}
		if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false));
	}
}
