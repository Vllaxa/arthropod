package net.arphex.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.arphex.entity.WaterRoachEntity;
import net.arphex.entity.TamedTarantulaEntity;
import net.arphex.entity.SunScorpionTinyEntity;
import net.arphex.entity.SunScorpionEntity;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderLarvaeTinyEntity;
import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.entity.SpiderGoliathEntity;
import net.arphex.entity.SpiderFunnelEntity;
import net.arphex.entity.SpiderFlatEntity;
import net.arphex.entity.SpiderBroodEntity;
import net.arphex.entity.SilverfishSpectreEntity;
import net.arphex.entity.LongLegsTinyEntity;
import net.arphex.entity.LongLegsEntity;
import net.arphex.entity.CentipedeStalkerEntity;
import net.arphex.entity.CentipedeEvictorLarvaeEntity;
import net.arphex.entity.CentipedeEvictorEntity;
import net.arphex.entity.BloodWormEntity;
import net.arphex.entity.AntGiantEntity;
import net.arphex.ArphexMod;

import javax.annotation.Nullable;

import java.util.Comparator;

@Mod.EventBusSubscriber
public class ClimbingProcedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SpiderLarvaeEntity || entity instanceof SpiderLarvaeTinyEntity || entity instanceof SpiderBroodEntity || entity instanceof SpiderFlatEntity || entity instanceof SpiderWidowEntity || entity instanceof AntGiantEntity
				|| entity instanceof BloodWormEntity || entity instanceof CentipedeEvictorEntity || entity instanceof CentipedeEvictorLarvaeEntity || entity instanceof CentipedeStalkerEntity || entity instanceof LongLegsEntity
				|| entity instanceof LongLegsTinyEntity || entity instanceof SpiderFunnelEntity || entity instanceof SunScorpionEntity || entity instanceof SunScorpionTinyEntity || entity instanceof WaterRoachEntity
				|| entity instanceof SpiderGoliathEntity || entity instanceof SilverfishSpectreEntity || entity instanceof TamedTarantulaEntity) {
			if (!entity.isInWater() && (world.getBlockState(new BlockPos(x, y + 0.5, z)).getDestroySpeed(world, new BlockPos(x, y + 0.5, z)) >= 0.3
					|| world.getBlockState(new BlockPos(x + entity.getPersistentData().getDouble("climbradius") - 0.05, y + 0.5, z)).getDestroySpeed(world,
							new BlockPos(x + entity.getPersistentData().getDouble("climbradius") - 0.05, y + 0.5, z)) >= 0.3
					|| world.getBlockState(new BlockPos(x - (entity.getPersistentData().getDouble("climbradius") - 0.05), y + 0.5, z)).getDestroySpeed(world,
							new BlockPos(x - (entity.getPersistentData().getDouble("climbradius") - 0.05), y + 0.5, z)) >= 0.3
					|| world.getBlockState(new BlockPos(x, y + 0.5, z - (entity.getPersistentData().getDouble("climbradius") - 0.05))).getDestroySpeed(world,
							new BlockPos(x, y + 0.5, z - (entity.getPersistentData().getDouble("climbradius") - 0.05))) >= 0.3
					|| world.getBlockState(new BlockPos(x, y + 0.5, z + entity.getPersistentData().getDouble("climbradius") - 0.05)).getDestroySpeed(world,
							new BlockPos(x, y + 0.5, z + entity.getPersistentData().getDouble("climbradius") - 0.05)) >= 0.3)) {
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
					ArphexMod.queueServerWork(8, () -> {
						entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) * 0.0299), 0.15, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) * 0.0299)));
					});
				} else {
					if (entity.getY() < (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY()) {
						ArphexMod.queueServerWork(8, () -> {
							entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) * 0.0299), 0.15, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) * 0.0299)));
						});
					}
				}
			}
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
				if (!entity.isInWater() && !world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 30, 30, 30), e -> true).isEmpty()
						&& entity.getY() < ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()) {
					if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
						entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX()), ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY()),
								((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
					}
				}
			}
			if (entity.getPersistentData().getDouble("climbradius") <= 0.2) {
				ArphexMod.queueServerWork(10, () -> {
					if (entity.getPersistentData().getDouble("climbradius") <= 0.2) {
						entity.getPersistentData().putDouble("climbradius", 1);
					}
				});
			}
			if (!(entity instanceof TamedTarantulaEntity)) {
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null && world.isEmptyBlock(new BlockPos(x, y - 1, z)) && !entity.isOnGround() && entity.getDeltaMovement().y() > 0.1) {
					ArphexMod.queueServerWork(5, () -> {
						if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null && world.isEmptyBlock(new BlockPos(x, y - 1, z)) && !entity.isOnGround() && entity.getDeltaMovement().y() > 0.1) {
							if (world.getBlockState(new BlockPos(x + 1, y, z)).getDestroySpeed(world, new BlockPos(x + 1, y, z)) >= 0.3) {
								if (entity instanceof Mob _entity)
									_entity.getNavigation().stop();
								entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x + 1), y, z));
							} else {
								if (world.getBlockState(new BlockPos(x - 1, y, z)).getDestroySpeed(world, new BlockPos(x - 1, y, z)) >= 0.3) {
									if (entity instanceof Mob _entity)
										_entity.getNavigation().stop();
									entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((x - 1), y, z));
								} else {
									if (world.getBlockState(new BlockPos(x, y, z - 1)).getDestroySpeed(world, new BlockPos(x, y, z - 1)) >= 0.3) {
										if (entity instanceof Mob _entity)
											_entity.getNavigation().stop();
										entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(x, y, (z - 1)));
									} else {
										if (world.getBlockState(new BlockPos(x, y, z + 1)).getDestroySpeed(world, new BlockPos(x, y, z + 1)) >= 0.3) {
											if (entity instanceof Mob _entity)
												_entity.getNavigation().stop();
											entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(x, y, (z + 1)));
										}
									}
								}
							}
						}
					});
				}
			}
		}
	}
}
