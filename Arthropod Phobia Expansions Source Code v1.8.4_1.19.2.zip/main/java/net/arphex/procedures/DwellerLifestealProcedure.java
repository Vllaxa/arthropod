package net.arphex.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Pufferfish;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.Advancement;

import net.arphex.network.ArphexModVariables;
import net.arphex.init.ArphexModParticleTypes;
import net.arphex.init.ArphexModMobEffects;
import net.arphex.init.ArphexModItems;
import net.arphex.init.ArphexModEntities;
import net.arphex.entity.TinyCentipedeBreacherEntity;
import net.arphex.entity.TeleportGhostEntity;
import net.arphex.entity.TamedTarantulaEntity;
import net.arphex.entity.SunScorpionEntity;
import net.arphex.entity.SpiderWidowEntity;
import net.arphex.entity.SpiderMothLarvaeEntity;
import net.arphex.entity.SpiderMothDwellerEntity;
import net.arphex.entity.SpiderLurkerEntity;
import net.arphex.entity.SpiderLarvaeEntity;
import net.arphex.entity.SpiderFunnelEntity;
import net.arphex.entity.SpiderFlatEntity;
import net.arphex.entity.SpiderBroodEntity;
import net.arphex.entity.SkyStalkerEntity;
import net.arphex.entity.HornetHarbingerGiantEntity;
import net.arphex.entity.HornetHarbingerEntity;
import net.arphex.entity.DwellerSleepSpawnerEntity;
import net.arphex.entity.CentipedeStalkerEntity;
import net.arphex.entity.CentipedeEvictorEntity;
import net.arphex.ArphexMod;

import javax.annotation.Nullable;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Iterator;
import java.util.Comparator;

@Mod.EventBusSubscriber
public class DwellerLifestealProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity(), event.getAmount());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount) {
		execute(null, world, x, y, z, entity, sourceentity, amount);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount) {
		if (entity == null || sourceentity == null)
			return;
		if (sourceentity instanceof Player && entity instanceof SpiderMothDwellerEntity && (sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals < 3
				&& entity.getPersistentData().getBoolean("spawnedawayfromplayer") == true && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 310) {
			if (!(sourceentity instanceof ServerPlayer _plr4 && _plr4.level instanceof ServerLevel && _plr4.getAdvancements().getOrStartProgress(_plr4.server.getAdvancements().getAdvancement(new ResourceLocation("arphex:moth_ward"))).isDone())) {
				if (sourceentity instanceof ServerPlayer _player) {
					Advancement _adv = _player.server.getAdvancements().getAdvancement(new ResourceLocation("arphex:moth_ward"));
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						Iterator _iterator = _ap.getRemainingCriteria().iterator();
						while (_iterator.hasNext())
							_player.getAdvancements().award(_adv, (String) _iterator.next());
					}
				}
			}
			if (!entity.level.isClientSide())
				entity.discard();
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 15, 1, 0.4, 1, 0.3);
			{
				double _setval = (sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals + 1;
				sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mothsurvivals = _setval;
					capability.syncPlayerVariables(sourceentity);
				});
			}
			if ((sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals == 1) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(entity.getX(), entity.getY(), entity.getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			if ((sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals == 2) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(entity.getX(), entity.getY(), entity.getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
				ArphexMod.queueServerWork(20, () -> {
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(entity.getX(), entity.getY(), entity.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
				});
			}
			if ((sourceentity.getCapability(ArphexModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ArphexModVariables.PlayerVariables())).mothsurvivals == 3) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(entity.getX(), entity.getY(), entity.getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
				ArphexMod.queueServerWork(20, () -> {
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(entity.getX(), entity.getY(), entity.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 15, 1, 0.4, 1, 0.3);
				});
				ArphexMod.queueServerWork(50, () -> {
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(new BlockPos(entity.getX(), entity.getY(), entity.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 15, 1, 0.4, 1, 0.3);
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, new BlockPos(entity.getX(), entity.getY(), entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscare")), SoundSource.HOSTILE, 1, 1);
						} else {
							_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("arphex:mothscare")), SoundSource.HOSTILE, 1, 1, false);
						}
					}
				});
			}
		}
		if (entity instanceof SpiderMothDwellerEntity && amount > 25 && amount < 250 && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 25) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("mothdamage").bypassArmor(), 25);
		}
		if (entity instanceof SpiderWidowEntity && amount > 50 && amount < 250 && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 50) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("spiderdamage").bypassArmor(), 50);
		}
		if (sourceentity instanceof Player && entity instanceof SpiderMothDwellerEntity && (entity.getPersistentData().getString("playerlookedatmoth")).equals("no")) {
			entity.getPersistentData().putString("playerlookedatmoth", "looking");
		}
		if (sourceentity instanceof SpiderMothDwellerEntity && !(entity instanceof LivingEntity _livEnt52 && _livEnt52.isBlocking())
				&& !(entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(ArphexModItems.BANE_OF_THE_DARKNESS.get())) : false)) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 0, false, true));
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.PORTAL, x, y, z, 50, 0.7, 0.7, 0.7, 6);
		}
		if (sourceentity instanceof TeleportGhostEntity && !world.getEntitiesOfClass(SpiderMothDwellerEntity.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute at @e[type=arphex:spider_moth_dweller,limit=1,distance=..60] run particle arphex:ghost_teleport ~ ~ ~ 1 1 1 0.4 20");
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"tp @e[type=arphex:spider_moth_dweller,limit=1,distance=..60] ~ ~ ~");
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.GHOST_TELEPORT.get()), x, y, z, 20, 1, 1, 1, 0.6);
			if (!sourceentity.level.isClientSide())
				sourceentity.discard();
		}
		if (sourceentity instanceof SpiderLarvaeEntity && entity instanceof Player && Mth.nextInt(RandomSource.create(), 1, 3) == 3) {
			entity.getPersistentData().putBoolean("spidergrab", true);
		}
		if (sourceentity instanceof CentipedeStalkerEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 1, false, true));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, true));
		}
		if (sourceentity instanceof SunScorpionEntity && entity instanceof Player) {
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1, false, true));
			}
			if (Mth.nextInt(RandomSource.create(), 1, 4) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1, false, true));
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 1, false, false));
				ArphexMod.queueServerWork(3, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(6, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(9, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(12, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(15, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(18, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(21, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(24, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(27, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(30, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(33, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(36, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				ArphexMod.queueServerWork(39, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=arphex:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
			}
		}
		if (sourceentity instanceof Player && entity instanceof DwellerSleepSpawnerEntity) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiderMothDwellerEntity(ArphexModEntities.SPIDER_MOTH_DWELLER.get(), _level);
				entityToSpawn.moveTo(x, y, z, 0, 0);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
			if (!entity.level.isClientSide())
				entity.discard();
		}
		if (sourceentity instanceof SpiderLarvaeEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
			if (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.MOVEMENT_SLOWDOWN) : false) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 25, 1, 1, 1, 0);
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 5, 1, 1, 1, 0);
			ArphexMod.queueServerWork(10, () -> {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.THIN_WEB.get()), x, y, z, 5, 1, 1, 1, 0.2);
			});
		}
		if (sourceentity instanceof SpiderBroodEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 60, 0, false, false));
			ArphexMod.queueServerWork(20, () -> {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"kill @e[type=arphex:projectile_spider_brood]");
			});
		}
		if (sourceentity instanceof Player && entity instanceof SkyStalkerEntity) {
			if (!entity.level.isClientSide())
				entity.discard();
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiderMothDwellerEntity(ArphexModEntities.SPIDER_MOTH_DWELLER.get(), _level);
				entityToSpawn.moveTo((entity.getX()), (entity.getY()), (entity.getZ()), 0, 0);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (sourceentity instanceof SpiderWidowEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 40, 1, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0, false, false));
		}
		if (sourceentity instanceof CentipedeEvictorEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 0, false, false));
			if (!(entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.WITHER) : false)) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 0, false, false));
			}
		}
		if (sourceentity instanceof TinyCentipedeBreacherEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 15, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 2, false, false));
		}
		if (entity instanceof SpiderMothDwellerEntity) {
			if (entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(MobEffects.INVISIBILITY) : false) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.HEAVY_RED_SMOKE.get()), x, y, z, 40, 0.4, 0.4, 0.4, 0.2);
			}
			if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 150, 150, 150), e -> true).isEmpty()
					&& ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 150, 150, 150), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false || sourceentity instanceof SpiderMothLarvaeEntity || sourceentity instanceof SpiderMothDwellerEntity)) {
				if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null) {
					if (entity instanceof Mob _entity && sourceentity instanceof LivingEntity _ent)
						_entity.setTarget(_ent);
				}
			}
		}
		if (sourceentity instanceof Pufferfish && entity instanceof SpiderLurkerEntity) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
		}
		if (sourceentity instanceof SpiderMothDwellerEntity) {
			sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
			if (!world.isEmptyBlock(new BlockPos(x, y + 1, z)) || !world.isEmptyBlock(new BlockPos(x, y + 2, z))) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.SOLID_SMOKE.get()), (sourceentity.getX()), (sourceentity.getY()), (sourceentity.getZ()), 2, 0.4, 0.4, 0.4, 0.2);
			}
		}
		if (sourceentity instanceof Player && ((entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(ArphexModItems.ABYSSAL_BLADE.get())) : false)
				|| (entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(ArphexModItems.ABYSSAL_PICKAXE.get())) : false))) {
			if (!entity.level.isClientSide())
				entity.discard();
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiderMothDwellerEntity(ArphexModEntities.SPIDER_MOTH_DWELLER.get(), _level);
				entityToSpawn.moveTo((entity.getX()), (entity.getY()), (entity.getZ()), 0, 0);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (sourceentity instanceof SpiderFunnelEntity && Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
			if (!(entity instanceof LivingEntity _livEnt169 && _livEnt169.isBlocking())) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.NECROSIS.get(), 300, 1, false, true));
			}
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.WEBBED.get(), 50, 1, false, false));
		}
		sourceentity.getPersistentData().putDouble("rotationtoplayer", ((sourceentity.getYRot() - Math.atan2(sourceentity.getX() - entity.getX(), sourceentity.getX() - entity.getX()) * 57.5) - 180));
		if ((entity instanceof LivingEntity _entUseItem178 ? _entUseItem178.getUseItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_BLADE.get()) {
			if (Math.atan2(sourceentity.getX() - entity.getX(), sourceentity.getZ() - entity.getZ()) * 57.5 - 0 + entity.getYRot() < 20 == Math.atan2(sourceentity.getX() - entity.getX(), sourceentity.getZ() - entity.getZ()) * 57.5 - 0
					+ entity.getYRot() > -20) {
				if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.GLOWING, 10, 1, false, false));
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.shield.block")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("item.shield.block")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
				if (event != null && event.isCancelable()) {
					event.setCanceled(true);
				}
			} else {
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.NECROSIS.get()) : false) && !(entity instanceof LivingEntity _livEnt193 && _livEnt193.isBlocking())) {
					entity.hurt(DamageSource.WITHER,
							(float) (amount * (((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.NECROSIS.get()) ? _livEnt.getEffect(ArphexModMobEffects.NECROSIS.get()).getAmplifier() : 0) + 3) / 2.5)));
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z,
								(int) (((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.NECROSIS.get()) ? _livEnt.getEffect(ArphexModMobEffects.NECROSIS.get()).getAmplifier() : 0) + 10) * 5), 0.5, 0.5, 0.5, 0.2);
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 10, 0, false, false));
				}
			}
		} else {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.hasEffect(ArphexModMobEffects.NECROSIS.get()) : false) && !(entity instanceof LivingEntity _livEnt201 && _livEnt201.isBlocking())) {
				entity.hurt(DamageSource.WITHER,
						(float) (amount * (((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.NECROSIS.get()) ? _livEnt.getEffect(ArphexModMobEffects.NECROSIS.get()).getAmplifier() : 0) + 3) / 2.5)));
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ArphexModParticleTypes.CHARRED_BLOOD.get()), x, y, z,
							(int) (((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ArphexModMobEffects.NECROSIS.get()) ? _livEnt.getEffect(ArphexModMobEffects.NECROSIS.get()).getAmplifier() : 0) + 10) * 5), 0.5, 0.5, 0.5, 0.2);
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 10, 0, false, false));
			}
		}
		if (sourceentity instanceof Player && !(entity instanceof TamableAnimal _tamIsTamedBy && sourceentity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false)) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(50 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if ((entityiterator instanceof TamableAnimal _tamIsTamedBy && sourceentity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false) && entityiterator instanceof SpiderFlatEntity) {
						if (entityiterator instanceof Mob _entity && entity instanceof LivingEntity _ent)
							_entity.setTarget(_ent);
					}
				}
			}
		}
		if (entity instanceof Player) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(50 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if ((entityiterator instanceof TamableAnimal _tamIsTamedBy && entity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false) && entityiterator instanceof SpiderFlatEntity) {
						if (entityiterator instanceof Mob _entity && sourceentity instanceof LivingEntity _ent)
							_entity.setTarget(_ent);
					}
				}
			}
		}
		if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.DAGGER_OF_DISSOLUTION.get()
				|| (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_BLADE.get()
						&& (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_DAGGER.get()) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.NECROSIS.get(), 160, 1, false, true));
		}
		if ((sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_DAGGER.get()) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.NECROSIS.get(), 160, 2, false, true));
		}
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_DAGGER.get()
				|| (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem() == ArphexModItems.ABYSSAL_DAGGER.get()) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 30, 1, false, false));
			if (sourceentity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 5, false, false));
		}
		if (sourceentity instanceof Player && !(entity instanceof TamableAnimal _tamIsTamedBy && sourceentity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false)) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(30 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (entityiterator instanceof TamedTarantulaEntity) {
						if (((Entity) world.getEntitiesOfClass(TamedTarantulaEntity.class, AABB.ofSize(new Vec3(x, y, z), 30, 30, 30), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _tamIsTamedBy && sourceentity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false) {
							if (((Entity) world.getEntitiesOfClass(TamedTarantulaEntity.class, AABB.ofSize(new Vec3(x, y, z), 30, 30, 30), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _entity && entity instanceof LivingEntity _ent)
								_entity.setTarget(_ent);
						}
					}
				}
			}
		}
		if (entity instanceof Player) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(30 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (entityiterator instanceof TamedTarantulaEntity) {
						if (((Entity) world.getEntitiesOfClass(TamedTarantulaEntity.class, AABB.ofSize(new Vec3(x, y, z), 30, 30, 30), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof TamableAnimal _tamIsTamedBy && entity instanceof LivingEntity _livEnt ? _tamIsTamedBy.isOwnedBy(_livEnt) : false) {
							if (((Entity) world.getEntitiesOfClass(TamedTarantulaEntity.class, AABB.ofSize(new Vec3(x, y, z), 30, 30, 30), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _entity && sourceentity instanceof LivingEntity _ent)
								_entity.setTarget(_ent);
						}
					}
				}
			}
		}
		if (sourceentity instanceof HornetHarbingerEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.NECROSIS.get(), 200, 0, false, true));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 300, 0, false, false));
		}
		if (sourceentity instanceof HornetHarbingerGiantEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ArphexModMobEffects.NECROSIS.get(), 200, 1, false, true));
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 500, 0, false, false));
		}
	}
}
