package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;

import net.arphex.init.ArphexModEntities;
import net.arphex.entity.SpiderMothDwellerEntity;

public class JumpScareProceedProcedure {
	public static Entity execute(LevelAccessor world) {
		return world instanceof Level _level ? new SpiderMothDwellerEntity(ArphexModEntities.SPIDER_MOTH_DWELLER.get(), _level) : null;
	}
}
