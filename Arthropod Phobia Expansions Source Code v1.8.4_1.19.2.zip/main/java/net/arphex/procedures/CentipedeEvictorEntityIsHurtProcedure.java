package net.arphex.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import net.arphex.init.ArphexModEntities;
import net.arphex.entity.CentipedeEvictorLarvaeEntity;
import net.arphex.entity.CentipedeEvictorEntity;
import net.arphex.ArphexMod;

public class CentipedeEvictorEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!(entity.getPersistentData().getDouble("evictorcycle") > 0)) {
			entity.getPersistentData().putDouble("evictorcycle", 1);
		} else {
			if (entity.getPersistentData().getDouble("evictorcycle") > 20) {
				entity.getPersistentData().putDouble("evictorcycle", 1);
			} else {
				entity.getPersistentData().putDouble("evictorcycle", (entity.getPersistentData().getDouble("evictorcycle") + 1));
			}
		}
		if (entity instanceof CentipedeEvictorEntity && entity.getPersistentData().getDouble("evictorcycle") == 5) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new CentipedeEvictorLarvaeEntity(ArphexModEntities.CENTIPEDE_EVICTOR_LARVAE.get(), _level);
				entityToSpawn.moveTo(x, y, z, 0, 0);
				entityToSpawn.setYBodyRot(0);
				entityToSpawn.setYHeadRot(0);
				entityToSpawn.setDeltaMovement(0, 0, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		ArphexMod.queueServerWork(10, () -> {
			if (Mth.nextInt(RandomSource.create(), 1, 3) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1, false, false));
			} else {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
				}
			}
		});
	}
}
