
package net.arphex.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class NecrosisMobEffect extends MobEffect {
	public NecrosisMobEffect() {
		super(MobEffectCategory.HARMFUL, -15069425);
	}

	@Override
	public String getDescriptionId() {
		return "effect.arphex.necrosis";
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
