
package net.arphex.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class MothCurseMobEffect extends MobEffect {
	public MothCurseMobEffect() {
		super(MobEffectCategory.HARMFUL, -13434880);
	}

	@Override
	public String getDescriptionId() {
		return "effect.arphex.moth_curse";
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
