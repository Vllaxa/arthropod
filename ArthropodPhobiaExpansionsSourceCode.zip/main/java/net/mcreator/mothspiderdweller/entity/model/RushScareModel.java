package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.RushScareEntity;

public class RushScareModel extends GeoModel<RushScareEntity> {
	@Override
	public ResourceLocation getAnimationResource(RushScareEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(RushScareEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(RushScareEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
