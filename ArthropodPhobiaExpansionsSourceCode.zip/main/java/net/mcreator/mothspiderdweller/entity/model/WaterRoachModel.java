package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.WaterRoachEntity;

public class WaterRoachModel extends GeoModel<WaterRoachEntity> {
	@Override
	public ResourceLocation getAnimationResource(WaterRoachEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/waterroach.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(WaterRoachEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/waterroach.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(WaterRoachEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
