package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SpiderMothLarvaeEntity;

public class SpiderMothLarvaeModel extends GeoModel<SpiderMothLarvaeEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderMothLarvaeEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderMothLarvaeEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderMothLarvaeEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
