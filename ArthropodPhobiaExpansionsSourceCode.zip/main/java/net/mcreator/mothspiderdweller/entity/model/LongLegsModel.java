package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.LongLegsEntity;

public class LongLegsModel extends GeoModel<LongLegsEntity> {
	@Override
	public ResourceLocation getAnimationResource(LongLegsEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/longlegs.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(LongLegsEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/longlegs.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(LongLegsEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
