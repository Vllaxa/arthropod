package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;

public class SpiderWidowModel extends GeoModel<SpiderWidowEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderWidowEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spiderwidow.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderWidowEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spiderwidow.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderWidowEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
