package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.BloodWormEntity;

public class BloodWormModel extends GeoModel<BloodWormEntity> {
	@Override
	public ResourceLocation getAnimationResource(BloodWormEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/bloodworm.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(BloodWormEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/bloodworm.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(BloodWormEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
