package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SpiderBroodEntity;

public class SpiderBroodModel extends GeoModel<SpiderBroodEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderBroodEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spiderbrood.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderBroodEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spiderbrood.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderBroodEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
