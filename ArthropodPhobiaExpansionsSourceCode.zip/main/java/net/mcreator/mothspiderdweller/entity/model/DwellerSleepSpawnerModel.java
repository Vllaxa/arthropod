package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.DwellerSleepSpawnerEntity;

public class DwellerSleepSpawnerModel extends GeoModel<DwellerSleepSpawnerEntity> {
	@Override
	public ResourceLocation getAnimationResource(DwellerSleepSpawnerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(DwellerSleepSpawnerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(DwellerSleepSpawnerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
