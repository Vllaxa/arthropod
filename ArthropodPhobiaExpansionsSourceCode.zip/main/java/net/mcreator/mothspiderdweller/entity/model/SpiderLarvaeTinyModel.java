package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SpiderLarvaeTinyEntity;

public class SpiderLarvaeTinyModel extends GeoModel<SpiderLarvaeTinyEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderLarvaeTinyEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spiderlarvae.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderLarvaeTinyEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spiderlarvae.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderLarvaeTinyEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
