package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.MaggotEntity;

public class MaggotModel extends GeoModel<MaggotEntity> {
	@Override
	public ResourceLocation getAnimationResource(MaggotEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/maggot.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(MaggotEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/maggot.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(MaggotEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
