package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.AntGiantEntity;

public class AntGiantModel extends GeoModel<AntGiantEntity> {
	@Override
	public ResourceLocation getAnimationResource(AntGiantEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/antgiant.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(AntGiantEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/antgiant.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(AntGiantEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
