package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;

public class SpiderMothDwellerModel extends GeoModel<SpiderMothDwellerEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderMothDwellerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spidermothdweller.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderMothDwellerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spidermothdweller.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderMothDwellerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
