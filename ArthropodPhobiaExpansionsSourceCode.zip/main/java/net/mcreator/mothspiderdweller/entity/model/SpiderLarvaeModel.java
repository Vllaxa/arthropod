package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;

public class SpiderLarvaeModel extends GeoModel<SpiderLarvaeEntity> {
	@Override
	public ResourceLocation getAnimationResource(SpiderLarvaeEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/spiderlarvae.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SpiderLarvaeEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/spiderlarvae.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SpiderLarvaeEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
