package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.SunScorpionTinyEntity;

public class SunScorpionTinyModel extends GeoModel<SunScorpionTinyEntity> {
	@Override
	public ResourceLocation getAnimationResource(SunScorpionTinyEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/sunscorpion.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SunScorpionTinyEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/sunscorpion.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SunScorpionTinyEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
