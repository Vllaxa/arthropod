package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.CentipedeStalkerEntity;

public class CentipedeStalkerModel extends GeoModel<CentipedeStalkerEntity> {
	@Override
	public ResourceLocation getAnimationResource(CentipedeStalkerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/centipedestalker.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(CentipedeStalkerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/centipedestalker.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(CentipedeStalkerEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
