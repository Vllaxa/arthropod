package net.mcreator.mothspiderdweller.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.entity.BeetleTickMiteEntity;

public class BeetleTickMiteModel extends GeoModel<BeetleTickMiteEntity> {
	@Override
	public ResourceLocation getAnimationResource(BeetleTickMiteEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "animations/beetletickmite.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(BeetleTickMiteEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "geo/beetletickmite.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(BeetleTickMiteEntity entity) {
		return new ResourceLocation("moth_spider_dweller", "textures/entities/" + entity.getTexture() + ".png");
	}

}
