package net.mcreator.mothspiderdweller.procedures;

public class BeetleTickMiteOnEntityTickProcedure {
	public static void execute() {
	}
}
