package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

import java.util.Comparator;

public class SpiderMothThisEntityKillsAnotherOneProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof Mob) {
			try {
				((Mob) entity).setTarget(null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_MOTH_LARVAE.get().spawn(_level, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setDeltaMovement(0, 0, 0);
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.ghast.hurt")), SoundSource.HOSTILE, (float) 0.5, -5);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.ghast.hurt")), SoundSource.HOSTILE, (float) 0.5, -5, false);
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 250, 250, 250), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "true";
				MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothscare")), SoundSource.HOSTILE, 1, 0);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothscare")), SoundSource.HOSTILE, 1, 0, false);
			}
		}
		MothSpiderDwellerMod.queueServerWork(5, () -> {
			MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "false";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		});
		if ((((SpiderMothDwellerEntity) sourceentity).animationprocedure).equals("animation.spider_moth_dweller.fullgrab")) {
			MothSpiderDwellerMod.queueServerWork(3, () -> {
				if ((((SpiderMothDwellerEntity) sourceentity).animationprocedure).equals("animation.spider_moth_dweller.fullgrab")) {
					if (sourceentity instanceof SpiderMothDwellerEntity) {
						((SpiderMothDwellerEntity) sourceentity).setAnimation("empty");
					}
				}
			});
		}
	}
}
