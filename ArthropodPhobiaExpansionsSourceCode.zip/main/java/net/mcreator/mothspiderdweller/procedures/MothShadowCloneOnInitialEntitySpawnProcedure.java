package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.entity.MothShadowCloneEntity;

public class MothShadowCloneOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (Mth.nextInt(RandomSource.create(), 1, 10) == 5) {
			MothSpiderDwellerModVariables.MapVariables.get(world).clonesize = Mth.nextDouble(RandomSource.create(), 1.45, 30);
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		} else {
			MothSpiderDwellerModVariables.MapVariables.get(world).clonesize = Mth.nextDouble(RandomSource.create(), 1.45, 5);
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		}
		if (Mth.nextInt(RandomSource.create(), 1, 10) == 5) {
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof MothShadowCloneEntity animatable)
					animatable.setTexture("horrormothlowhealthfixed");
			} else {
				if (entity instanceof MothShadowCloneEntity animatable)
					animatable.setTexture("horrormothfixed");
			}
		}
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 100, Mth.nextInt(RandomSource.create(), -6, 4), true, false));
		if (!(!world.getEntitiesOfClass(SpiderMothDwellerEntity.class, AABB.ofSize(new Vec3(x, y, z), 400, 400, 400), e -> true).isEmpty())) {
			if (!entity.level().isClientSide())
				entity.discard();
		}
	}
}
