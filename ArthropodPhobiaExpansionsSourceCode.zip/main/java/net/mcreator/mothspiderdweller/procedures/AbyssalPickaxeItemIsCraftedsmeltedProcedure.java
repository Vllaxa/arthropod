package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.ItemStack;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEnchantments;

public class AbyssalPickaxeItemIsCraftedsmeltedProcedure {
	public static void execute(ItemStack itemstack) {
		itemstack.enchant(MothSpiderDwellerModEnchantments.WITHER_AURA.get(), 3);
		itemstack.enchant(Enchantments.BLOCK_EFFICIENCY, 3);
		itemstack.enchant(Enchantments.BLOCK_FORTUNE, 3);
	}
}
