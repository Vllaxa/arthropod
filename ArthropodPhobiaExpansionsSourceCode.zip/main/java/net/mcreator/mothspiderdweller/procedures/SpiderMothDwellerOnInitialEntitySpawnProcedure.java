package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class SpiderMothDwellerOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 48, 48, 48), e -> true).isEmpty()) {
			entity.getPersistentData().putBoolean("spawnedawayfromplayer", false);
		} else {
			entity.getPersistentData().putBoolean("spawnedawayfromplayer", true);
		}
		if (world instanceof ServerLevel _level) {
			LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
			entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(x, y, z)));
			entityToSpawn.setVisualOnly(true);
			_level.addFreshEntity(entityToSpawn);
		}
		entity.getPersistentData().putBoolean("growattack", false);
		MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).GrowAttack = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "true";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "far";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).soundonce = "one";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).chasemode = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).slightrandom = "first";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle = Mth.nextInt(RandomSource.create(), 1, 9);
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerMod.queueServerWork(20, () -> {
			MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock = "no";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "false";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth = "no";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "far";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			MothSpiderDwellerModVariables.MapVariables.get(world).soundonce = "one";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			MothSpiderDwellerModVariables.MapVariables.get(world).chasemode = "no";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		});
		MothSpiderDwellerMod.queueServerWork(2, () -> {
			MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "false";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		});
	}
}
