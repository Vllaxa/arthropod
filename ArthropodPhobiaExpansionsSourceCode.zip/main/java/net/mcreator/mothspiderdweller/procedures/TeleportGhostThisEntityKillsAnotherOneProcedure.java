package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.entity.Entity;

public class TeleportGhostThisEntityKillsAnotherOneProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!entity.level().isClientSide())
			entity.discard();
	}
}
