package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModMobEffects;

import java.util.Map;

public class AbyssalPickaxeToolInHandTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _entity)
			_entity.removeEffect(MobEffects.DARKNESS);
		if (world instanceof ServerLevel _level)
			_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 5, 2, 2, 2, 0.5);
		itemstack.setDamageValue(0);
		if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_EFFICIENCY, itemstack) != 0) {
			if (MothSpiderDwellerModVariables.MapVariables.get(world).abysstimer > 10) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.SPIDER_SILK_TOUCH.get(), 190, 1, false, false));
			}
			if (entity instanceof LivingEntity _livEnt7 && _livEnt7.hasEffect(MothSpiderDwellerModMobEffects.SPIDER_SILK_TOUCH.get())) {
				if (!(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.SILK_TOUCH, itemstack) != 0)) {
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
						if (_enchantments.containsKey(Enchantments.BLOCK_FORTUNE)) {
							_enchantments.remove(Enchantments.BLOCK_FORTUNE);
							EnchantmentHelper.setEnchantments(_enchantments, itemstack);
						}
					}
					itemstack.enchant(Enchantments.SILK_TOUCH, 3);
				}
			} else {
				if (!(EnchantmentHelper.getItemEnchantmentLevel(Enchantments.BLOCK_FORTUNE, itemstack) != 0)) {
					{
						Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
						if (_enchantments.containsKey(Enchantments.SILK_TOUCH)) {
							_enchantments.remove(Enchantments.SILK_TOUCH);
							EnchantmentHelper.setEnchantments(_enchantments, itemstack);
						}
					}
					itemstack.enchant(Enchantments.BLOCK_FORTUNE, 3);
				}
			}
		}
	}
}
