package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;

public class MothShadowCloneEntityVisualScaleProcedure {
	public static double execute(LevelAccessor world) {
		double clonesize = 0;
		String once = "";
		return MothSpiderDwellerModVariables.MapVariables.get(world).clonesize;
	}
}
