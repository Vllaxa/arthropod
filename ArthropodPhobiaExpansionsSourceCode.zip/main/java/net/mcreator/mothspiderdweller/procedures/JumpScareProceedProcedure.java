package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;

public class JumpScareProceedProcedure {
	public static Entity execute(LevelAccessor world) {
		return world instanceof Level _level ? new SpiderMothDwellerEntity(MothSpiderDwellerModEntities.SPIDER_MOTH_DWELLER.get(), _level) : null;
	}
}
