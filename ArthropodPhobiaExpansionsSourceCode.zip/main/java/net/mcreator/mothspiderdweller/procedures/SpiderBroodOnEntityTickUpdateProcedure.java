package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModParticleTypes;
import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderFlatEntity;
import net.mcreator.mothspiderdweller.entity.SpiderBroodEntity;

import java.util.Comparator;

public class SpiderBroodOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty() && entity instanceof SpiderFlatEntity) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("spidergrab") == true) {
				entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
			}
		}
		if (world.isEmptyBlock(BlockPos.containing(x, y - 1, z))) {
			if (entity instanceof SpiderBroodEntity) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, (y + 1), z, 20, 0.1, 0.3, 0.1, 0);
			}
			if (entity instanceof SpiderWidowEntity) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, y, z, 20, 1, 1, 1, 0);
			}
		}
		if (entity instanceof SpiderBroodEntity) {
			if (entity.getPersistentData().getDouble("webtime") > 150) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 5, false, false));
				entity.getPersistentData().putDouble("webtime", 0);
			}
			entity.getPersistentData().putDouble("webtime", (entity.getPersistentData().getDouble("webtime") + 1));
		}
		if (entity instanceof SpiderWidowEntity) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 20) {
				if (entity instanceof SpiderWidowEntity animatable)
					animatable.setTexture("spiderwidowmissinglegs");
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.COBWEB) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5, 6, false, false));
		}
		if (entity instanceof SpiderWidowEntity) {
			if (entity.getPersistentData().getDouble("webtime") > 20) {
				entity.getPersistentData().putDouble("webtime", 0);
			}
			entity.getPersistentData().putDouble("webtime", (entity.getPersistentData().getDouble("webtime") + 1));
			if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
				if (entity.getY() > (entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY() + 0.8) {
					entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), (-2), Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
				}
			}
		}
	}
}
