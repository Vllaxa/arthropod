package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModParticleTypes;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeTinyEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderBroodEntity;

import java.util.Comparator;

public class SpiderLarvaeOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MobEffects.REGENERATION) ? _livEnt.getEffect(MobEffects.REGENERATION).getAmplifier() : 0) == 1
				&& !world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("spidergrab") == true) {
				entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), y, (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
				if (entity instanceof SpiderLarvaeEntity) {
					((SpiderLarvaeEntity) entity).setAnimation("animation.spiderlarvae.grab");
				}
				if (entity instanceof SpiderLarvaeTinyEntity) {
					((SpiderLarvaeTinyEntity) entity).setAnimation("animation.spiderlarvae.grab");
				}
			} else {
				if (entity instanceof SpiderLarvaeEntity) {
					((SpiderLarvaeEntity) entity).setAnimation("empty");
				}
				if (entity instanceof SpiderLarvaeTinyEntity) {
					((SpiderLarvaeTinyEntity) entity).setAnimation("empty");
				}
			}
		} else {
			if (entity instanceof SpiderLarvaeEntity) {
				((SpiderLarvaeEntity) entity).setAnimation("empty");
			}
			if (entity instanceof SpiderLarvaeTinyEntity) {
				((SpiderLarvaeTinyEntity) entity).setAnimation("empty");
			}
		}
		if (world.isEmptyBlock(BlockPos.containing(x, y, z)) && (!world.isEmptyBlock(BlockPos.containing(x, y + 3, z)) || !world.isEmptyBlock(BlockPos.containing(x, y + 2, z)))
				&& !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty())) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 5, 0, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 5, 1, false, false));
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, y, z, 1, 0, 1, 0, 0);
		}
		if (world.getBlockState(BlockPos.containing(x, y, z)).getDestroySpeed(world, BlockPos.containing(x, y, z)) >= 0.3 || world.getBlockState(BlockPos.containing(x + 0.7, y, z)).getDestroySpeed(world, BlockPos.containing(x + 0.7, y, z)) >= 0.3
				|| world.getBlockState(BlockPos.containing(x - 0.7, y, z)).getDestroySpeed(world, BlockPos.containing(x - 0.7, y, z)) >= 0.3
				|| world.getBlockState(BlockPos.containing(x, y, z + 0.7)).getDestroySpeed(world, BlockPos.containing(x, y, z + 0.7)) >= 0.3
				|| world.getBlockState(BlockPos.containing(x, y, z - 0.7)).getDestroySpeed(world, BlockPos.containing(x, y, z - 0.7)) >= 0.3) {
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
				if (!entity.isInWater() && !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).isEmpty()
						&& entity.getY() > ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY())) {
					entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) * 0.1), 0.1, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) * 0.1)));
				}
			}
		}
		if (!(world.isEmptyBlock(BlockPos.containing(x, y, z)) && world.isEmptyBlock(BlockPos.containing(x + 0.7, y, z)) && world.isEmptyBlock(BlockPos.containing(x - 0.7, y, z)) && world.isEmptyBlock(BlockPos.containing(x, y, z + 0.7))
				&& world.isEmptyBlock(BlockPos.containing(x, y, z - 0.7)))) {
			if (Mth.nextInt(RandomSource.create(), 1, 200) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 30, 0, false, false));
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.COBWEB) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 5, 6, false, false));
		}
		if (entity instanceof Mob _entity && (((Entity) world.getEntitiesOfClass(SpiderBroodEntity.class, AABB.ofSize(new Vec3(x, y, z), 10, 10, 10), e -> true).stream().sorted(new Object() {
			Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
				return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
			}
		}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _ent)
			_entity.setTarget(_ent);
		if ((entity instanceof SpiderLarvaeEntity animatable ? animatable.getTexture() : "null").equals("spiderwidow")) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 1, false, false));
		}
	}
}
