package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class AnimationTransferProcedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SpiderMothDwellerEntity) {
			if (entity.getPersistentData().getBoolean("growattack") == true) {
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("redglow");
			}
			if ((!world.isEmptyBlock(BlockPos.containing(entity.getX(), entity.getY() + 1, entity.getZ())) || !world.isEmptyBlock(BlockPos.containing(entity.getX(), entity.getY() + 2, entity.getZ()))) && entity.onGround()) {
				entity.setShiftKeyDown(true);
				entity.setSprinting(false);
				if (entity.getDeltaMovement().x() > 0 || entity.getDeltaMovement().y() > 0 || entity.getDeltaMovement().z() > 0) {
					if (!(entity.getPersistentData().getBoolean("growattack") == true)) {
						if (entity instanceof SpiderMothDwellerEntity) {
							((SpiderMothDwellerEntity) entity).setAnimation("animation.spider_moth_dweller.crawling");
						}
					}
				} else {
					if ((((SpiderMothDwellerEntity) entity).animationprocedure).equals("animation.spider_moth_dweller.crawling")) {
						if (entity instanceof SpiderMothDwellerEntity) {
							((SpiderMothDwellerEntity) entity).setAnimation("empty");
						}
					}
				}
			} else {
				entity.setShiftKeyDown(false);
				if (world.isEmptyBlock(BlockPos.containing(x, y - 1, z)) && world.isEmptyBlock(BlockPos.containing(x, y - 2, z)) && world.isEmptyBlock(BlockPos.containing(x, y - 3, z)) && world.isEmptyBlock(BlockPos.containing(x, y - 4, z))) {
					entity.setSprinting(true);
				} else {
					entity.setSprinting(false);
				}
			}
		}
	}
}
