package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;

import java.util.Comparator;

public class SpiderLarvaeOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty()) {
			if (entity instanceof SpiderLarvaeEntity animatable)
				animatable.setTexture("spiderwidow");
			if (entity instanceof Mob _entity && (((Entity) world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _ent)
				_entity.setTarget(_ent);
		} else {
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 3) {
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae2");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 2) {
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae3");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 1) {
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae4");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 4) {
				if (entity instanceof SpiderLarvaeEntity animatable)
					animatable.setTexture("spiderlarvae5");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setDeltaMovement(0, 0, 0);
					}
				}
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setDeltaMovement(0, 0, 0);
					}
				}
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setDeltaMovement(0, 0, 0);
					}
				}
			}
		}
	}
}
