package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModParticleTypes;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModMobEffects;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.TeleportGhostEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

import java.util.List;
import java.util.Comparator;

public class SpiderMothEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle == 2 || MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle == 5 && (MothSpiderDwellerModVariables.MapVariables.get(world).creativespectator).equals("yes")) {
			entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() + 90) * (Math.PI / 180)) / 3), 1.3, (Math.sin((entity.getYRot() + 90) * (Math.PI / 180)) / 3)));
			MothSpiderDwellerMod.queueServerWork(10, () -> {
				entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
			});
		}
		if (MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle < Mth.nextInt(RandomSource.create(), 6, 8)) {
			MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle = MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle + 1;
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		} else {
			if (!(!world.getEntitiesOfClass(TeleportGhostEntity.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = MothSpiderDwellerModEntities.TELEPORT_GHOST.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setDeltaMovement(0, 1, 0);
					}
				}
			}
			MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle = 1;
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 1) {
				MothSpiderDwellerModVariables.MapVariables.get(world).slightrandom = "first";
				MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			} else {
				MothSpiderDwellerModVariables.MapVariables.get(world).slightrandom = "second";
				MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if (sourceentity instanceof SpiderMothLarvaeEntity || sourceentity instanceof TeleportGhostEntity || sourceentity instanceof TeleportGhostEntity) {
			if (sourceentity instanceof LivingEntity _entity)
				_entity.removeEffect(MothSpiderDwellerModMobEffects.MOTH_CURSE.get());
		} else {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.MOTH_CURSE.get(), 1200, 0, false, true));
		}
		if (!(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.LIGHTNING_BOLT), sourceentity).isIndirect()
				|| new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.IN_WALL), sourceentity).isIndirect())) {
			if ((MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle == 1 && (MothSpiderDwellerModVariables.MapVariables.get(world).slightrandom).equals("first")
					|| MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle == 3 && (MothSpiderDwellerModVariables.MapVariables.get(world).slightrandom).equals("second")) && entity.getPersistentData().getBoolean("growattack") == false) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, Mth.nextInt(RandomSource.create(), 30, 60), 12, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 120, 6, false, false));
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.LEVITATION, Mth.nextInt(RandomSource.create(), 12, 25), 12, false, false));
					}
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 400, 4, 4, 4, 0.2);
				MothSpiderDwellerMod.queueServerWork(75, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @e[type=!moth_spider_dweller:spider_moth_dweller,distance=..6] wither 5 3");
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 30, 3, 0.3, 3, 0.5);
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 20, 3, 0.3, 3, 0.5);
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p[distance=..8] wither 6 6");
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 40, 3, false, false));
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = MothSpiderDwellerModEntities.TELEPORT_GHOST.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
						if (entityToSpawn != null) {
							entityToSpawn.setDeltaMovement(0, 0, 0);
						}
					}
				});
			}
			if (MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle == 8 && (MothSpiderDwellerModVariables.MapVariables.get(world).slightrandom).equals("first")
					|| MothSpiderDwellerModVariables.MapVariables.get(world).attackcycle == 4) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 30, 3, 3, 3, 0);
				if (Mth.nextInt(RandomSource.create(), 1, 7) == 7) {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_MOTH_LARVAE.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
						if (entityToSpawn != null) {
							entityToSpawn.setDeltaMovement(0, 0, 0);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						Entity entityToSpawn = MothSpiderDwellerModEntities.TELEPORT_GHOST.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
						if (entityToSpawn != null) {
							entityToSpawn.setDeltaMovement(0, 0, 0);
						}
					}
				}
				MothSpiderDwellerMod.queueServerWork(20, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute as @e[type=moth_spider_dweller:spider_moth_dweller,limit=1,sort=nearest] run data merge entity @s {Invulnerable:1}");
					entity.getPersistentData().putBoolean("growattack", true);
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("redglow");
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 1, false, false));
				});
				MothSpiderDwellerMod.queueServerWork(40, () -> {
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 200, 3, 3, 3, 0);
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20, 5, false, false));
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20, 4, false, false));
				});
				MothSpiderDwellerMod.queueServerWork(60, () -> {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20, 5, false, false));
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.CRIMSON_SPORE, x, y, z, 400, 4, 4, 4, 0.2);
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 50, 3, 3, 3, 0.5);
				});
				MothSpiderDwellerMod.queueServerWork(75, () -> {
					entity.getPersistentData().putBoolean("growattack", false);
				});
			}
		}
		MothSpiderDwellerMod.queueServerWork(1, () -> {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("fullshadow");
		});
		MothSpiderDwellerMod.queueServerWork(20, () -> {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("horrormothfixed");
		});
	}
}
