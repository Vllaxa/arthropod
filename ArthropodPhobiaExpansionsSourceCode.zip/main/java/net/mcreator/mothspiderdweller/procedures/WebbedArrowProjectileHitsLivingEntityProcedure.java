package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModMobEffects;

public class WebbedArrowProjectileHitsLivingEntityProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get()))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.WEBBED.get(), 60, 0, false, false));
		} else {
			if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get()) ? _livEnt.getEffect(MothSpiderDwellerModMobEffects.WEBBED.get()).getAmplifier() : 0) == 0) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.WEBBED.get(), 80, 1, false, false));
			} else {
				if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get()) ? _livEnt.getEffect(MothSpiderDwellerModMobEffects.WEBBED.get()).getAmplifier() : 0) == 1) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.WEBBED.get(), 100, 2, false, false));
				} else {
					if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get()) ? _livEnt.getEffect(MothSpiderDwellerModMobEffects.WEBBED.get()).getAmplifier() : 0) == 2) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.WEBBED.get(), 120, 3, false, false));
					} else {
						if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get()) ? _livEnt.getEffect(MothSpiderDwellerModMobEffects.WEBBED.get()).getAmplifier() : 0) >= 3) {
							if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.WEBBED.get(), 140, 4, false, false));
						}
					}
				}
			}
		}
	}
}
