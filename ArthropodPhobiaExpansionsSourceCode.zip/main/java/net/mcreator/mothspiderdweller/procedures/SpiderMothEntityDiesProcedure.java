package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;

public class SpiderMothEntityDiesProcedure {
	public static void execute(LevelAccessor world) {
		MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		MothSpiderDwellerModVariables.MapVariables.get(world).chasemode = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
	}
}
