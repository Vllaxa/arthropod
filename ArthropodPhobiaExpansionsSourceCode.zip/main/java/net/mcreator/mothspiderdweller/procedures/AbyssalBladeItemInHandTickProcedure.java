package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;

public class AbyssalBladeItemInHandTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel _level)
			_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
					"effect clear @p minecraft:wither");
		if (entity.onGround()) {
			MothSpiderDwellerModVariables.MapVariables.get(world).doublejumpmax = "reset";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		}
		if (MothSpiderDwellerModVariables.MapVariables.get(world).abysstimer > 0) {
			MothSpiderDwellerModVariables.MapVariables.get(world).abysstimer = MothSpiderDwellerModVariables.MapVariables.get(world).abysstimer - 1;
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		}
	}
}
