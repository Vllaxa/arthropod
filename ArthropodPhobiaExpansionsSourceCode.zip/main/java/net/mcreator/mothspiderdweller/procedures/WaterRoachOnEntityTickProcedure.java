package net.mcreator.mothspiderdweller.procedures;

public class WaterRoachOnEntityTickProcedure {
	public static void execute() {
	}
}
