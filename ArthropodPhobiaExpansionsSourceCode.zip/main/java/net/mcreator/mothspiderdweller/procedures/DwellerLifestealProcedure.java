package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingAttackEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModParticleTypes;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModMobEffects;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModItems;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.TeleportGhostEntity;
import net.mcreator.mothspiderdweller.entity.SunScorpionEntity;
import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderBroodEntity;
import net.mcreator.mothspiderdweller.entity.SkyStalkerEntity;
import net.mcreator.mothspiderdweller.entity.DwellerSleepSpawnerEntity;
import net.mcreator.mothspiderdweller.entity.CentipedeStalkerEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class DwellerLifestealProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingAttackEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity(), event.getAmount());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount) {
		execute(null, world, x, y, z, entity, sourceentity, amount);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount) {
		if (entity == null || sourceentity == null)
			return;
		if (entity instanceof SpiderMothDwellerEntity && (sourceentity.getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new MothSpiderDwellerModVariables.PlayerVariables())).mothsurvivals < 3
				&& entity.getPersistentData().getBoolean("spawnedawayfromplayer") == true && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 330) {
			if (!entity.level().isClientSide())
				entity.discard();
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 15, 1, 0.4, 1, 0.3);
			{
				double _setval = (sourceentity.getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new MothSpiderDwellerModVariables.PlayerVariables())).mothsurvivals + 1;
				sourceentity.getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mothsurvivals = _setval;
					capability.syncPlayerVariables(sourceentity);
				});
			}
			if ((sourceentity.getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new MothSpiderDwellerModVariables.PlayerVariables())).mothsurvivals == 1) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			if ((sourceentity.getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new MothSpiderDwellerModVariables.PlayerVariables())).mothsurvivals == 2) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
				MothSpiderDwellerMod.queueServerWork(20, () -> {
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
				});
			}
			if ((sourceentity.getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new MothSpiderDwellerModVariables.PlayerVariables())).mothsurvivals == 3) {
				if (world instanceof ServerLevel _level) {
					LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
					entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ())));
					entityToSpawn.setVisualOnly(true);
					_level.addFreshEntity(entityToSpawn);
				}
				MothSpiderDwellerMod.queueServerWork(20, () -> {
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 15, 1, 0.4, 1, 0.3);
				});
				MothSpiderDwellerMod.queueServerWork(50, () -> {
					if (world instanceof ServerLevel _level) {
						LightningBolt entityToSpawn = EntityType.LIGHTNING_BOLT.create(_level);
						entityToSpawn.moveTo(Vec3.atBottomCenterOf(BlockPos.containing(entity.getX(), entity.getY(), entity.getZ())));
						entityToSpawn.setVisualOnly(true);
						_level.addFreshEntity(entityToSpawn);
					}
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 15, 1, 0.4, 1, 0.3);
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothscare")), SoundSource.NEUTRAL, 1, 1);
						} else {
							_level.playLocalSound((entity.getX()), (entity.getY()), (entity.getZ()), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothscare")), SoundSource.NEUTRAL, 1, 1, false);
						}
					}
				});
			}
		}
		if (entity instanceof SpiderMothDwellerEntity && amount > 25 && amount < 250) {
			if (event != null && event.isCancelable()) {
				event.setCanceled(true);
			}
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource(_entity.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC)) {
					@Override
					public Component getLocalizedDeathMessage(LivingEntity _msgEntity) {
						String _translatekey = "death.attack." + "mothdamage";
						if (this.getEntity() == null && this.getDirectEntity() == null) {
							return _msgEntity.getKillCredit() != null
									? Component.translatable(_translatekey + ".player", _msgEntity.getDisplayName(), _msgEntity.getKillCredit().getDisplayName())
									: Component.translatable(_translatekey, _msgEntity.getDisplayName());
						} else {
							Component _component = this.getEntity() == null ? this.getDirectEntity().getDisplayName() : this.getEntity().getDisplayName();
							ItemStack _itemstack = ItemStack.EMPTY;
							if (this.getEntity() instanceof LivingEntity _livingentity)
								_itemstack = _livingentity.getMainHandItem();
							return !_itemstack.isEmpty() && _itemstack.hasCustomHoverName()
									? Component.translatable(_translatekey + ".item", _msgEntity.getDisplayName(), _component, _itemstack.getDisplayName())
									: Component.translatable(_translatekey, _msgEntity.getDisplayName(), _component);
						}
					}
				}, 25);
		}
		if (sourceentity instanceof Player && entity instanceof SpiderMothDwellerEntity && (MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth).equals("no")) {
			MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth = "looking";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		}
		if (sourceentity instanceof SpiderMothDwellerEntity && !(entity instanceof LivingEntity _livEnt43 && _livEnt43.isBlocking())
				&& !(entity instanceof Player _playerHasItem ? _playerHasItem.getInventory().contains(new ItemStack(MothSpiderDwellerModItems.BANE_OF_THE_DARKNESS.get())) : false)) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.HEAL, 1, 0, false, true));
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.PORTAL, x, y, z, 50, 0.7, 0.7, 0.7, 6);
		}
		if (sourceentity instanceof TeleportGhostEntity && !world.getEntitiesOfClass(SpiderMothDwellerEntity.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute at @e[type=moth_spider_dweller:spider_moth_dweller,limit=1,distance=..60] run particle firework ~ ~ ~ 1 1 1 0.4 100");
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"tp @e[type=moth_spider_dweller:spider_moth_dweller,limit=1,distance=..60] ~ ~ ~");
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.FIREWORK, x, y, z, 100, 1, 1, 1, 0.4);
			if (!sourceentity.level().isClientSide())
				sourceentity.discard();
		}
		if (entity instanceof SpiderMothDwellerEntity) {
			if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 150, 150, 150), e -> true).isEmpty() && (MothSpiderDwellerModVariables.MapVariables.get(world).creativespectator).equals("no")
					|| sourceentity instanceof SpiderMothLarvaeEntity || sourceentity instanceof SpiderMothDwellerEntity)) {
				if (entity instanceof Mob _entity && sourceentity instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
			}
		}
		if (sourceentity instanceof SpiderLarvaeEntity && entity instanceof Player && Mth.nextInt(RandomSource.create(), 1, 3) == 3) {
			entity.getPersistentData().putBoolean("spidergrab", true);
		}
		if (sourceentity instanceof CentipedeStalkerEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 40, 1, false, true));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1, false, true));
		}
		if (sourceentity instanceof SunScorpionEntity && entity instanceof Player) {
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1, false, true));
			}
			if (Mth.nextInt(RandomSource.create(), 1, 4) == 2) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1, false, true));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 1, false, false));
				MothSpiderDwellerMod.queueServerWork(3, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(6, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(9, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(12, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(15, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(18, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(21, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(24, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(27, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(30, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(33, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(36, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
				MothSpiderDwellerMod.queueServerWork(39, () -> {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute at @p run tp @e[type=moth_spider_dweller:sun_scorpion,limit=1,sort=nearest,distance=..6] @p");
				});
			}
		}
		if (sourceentity instanceof Player && entity instanceof DwellerSleepSpawnerEntity) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_MOTH_DWELLER.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0, 0);
				}
			}
			if (!entity.level().isClientSide())
				entity.discard();
		}
		if (sourceentity instanceof SpiderLarvaeEntity) {
			if (entity instanceof LivingEntity _livEnt104 && _livEnt104.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false));
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, y, z, 25, 1, 1, 1, 0);
			} else {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0, false, false));
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, y, z, 5, 1, 1, 1, 0);
			MothSpiderDwellerMod.queueServerWork(10, () -> {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, y, z, 5, 1, 1, 1, 0.2);
			});
		}
		if (sourceentity instanceof SpiderBroodEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, false, false));
			MothSpiderDwellerMod.queueServerWork(20, () -> {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"kill @e[type=moth_spider_dweller:projectile_spider_brood]");
			});
		}
		if (entity instanceof SpiderBroodEntity) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement((Mth.nextDouble(RandomSource.create(), -0.3, 0.3)), 0, 0);
				}
			}
		}
		if (sourceentity instanceof Player && entity instanceof SkyStalkerEntity) {
			if (!entity.level().isClientSide())
				entity.discard();
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_MOTH_DWELLER.get().spawn(_level, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0, 0);
				}
			}
		}
		if (sourceentity instanceof SpiderWidowEntity) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.WEBBED.get(), 40, 1, false, false));
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0, false, false));
		}
	}
}
