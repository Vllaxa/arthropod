package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.mothspiderdweller.entity.SkyStalkerEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class SkyStalkerOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!world.getEntitiesOfClass(SkyStalkerEntity.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).isEmpty()) {
			if (!entity.level().isClientSide())
				entity.discard();
		}
		MothSpiderDwellerMod.queueServerWork(Mth.nextInt(RandomSource.create(), 4000, 6000), () -> {
			if (!entity.level().isClientSide())
				entity.discard();
		});
	}
}
