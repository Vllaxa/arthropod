package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class SpiderLarvaeEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof SpiderLarvaeEntity) {
			if ((MothSpiderDwellerModVariables.MapVariables.get(world).spidergrab).equals("no")) {
				entity.setDeltaMovement(new Vec3((Math.cos((entity.getYRot() - 90) * (Math.PI / 180)) * 0.1), 0.5, (Math.sin((entity.getYRot() - 90) * (Math.PI / 180)) * 0.1)));
			}
		}
		if (entity instanceof SpiderLarvaeEntity) {
			((SpiderLarvaeEntity) entity).setAnimation("animation.spiderlarvae.grab");
		}
		MothSpiderDwellerMod.queueServerWork(20, () -> {
			if (entity instanceof SpiderLarvaeEntity) {
				((SpiderLarvaeEntity) entity).setAnimation("empty");
			}
		});
		entity.setSprinting(true);
		MothSpiderDwellerMod.queueServerWork(20, () -> {
			entity.setSprinting(false);
		});
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 3 && (entity instanceof SpiderLarvaeEntity animatable ? animatable.getTexture() : "null").equals("spiderwidow")) {
			if (entity instanceof SpiderLarvaeEntity animatable)
				animatable.setTexture("spiderwidowmissinglegs");
		}
	}
}
