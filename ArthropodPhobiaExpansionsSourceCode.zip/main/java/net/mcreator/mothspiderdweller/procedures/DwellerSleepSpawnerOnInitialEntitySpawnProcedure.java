package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.mothspiderdweller.entity.DwellerSleepSpawnerEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class DwellerSleepSpawnerOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		MothSpiderDwellerMod.queueServerWork(20, () -> {
			if (!world.getEntitiesOfClass(DwellerSleepSpawnerEntity.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()
					&& !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 15, 15, 15), e -> true).isEmpty())) {
				if (!entity.level().isClientSide())
					entity.discard();
			}
		});
	}
}
