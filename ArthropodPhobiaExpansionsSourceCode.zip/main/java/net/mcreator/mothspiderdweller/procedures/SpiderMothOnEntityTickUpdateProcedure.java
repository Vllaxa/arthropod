package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.Difficulty;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModParticleTypes;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModMobEffects;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.TeleportGhostEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.configuration.ConfigurationSettingsConfiguration;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

import java.util.Map;
import java.util.Comparator;

public class SpiderMothOnEntityTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double fireHeight = 0;
		double mobsize = 0;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 30) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.INVISIBILITY);
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1));
		}
		if (entity.getPersistentData().getBoolean("growattack") == true) {
			if (entity instanceof SpiderMothDwellerEntity animatable)
				animatable.setTexture("redglow");
		}
		if (ConfigurationSettingsConfiguration.DWELLER_INCLUSION.get() == false) {
			if (!entity.level().isClientSide())
				entity.discard();
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).isEmpty()) {
			if (entity.getPersistentData().getBoolean("spawnedawayfromplayer") == true) {
				if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getDouble("mothsurvivals") < 3) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 60, 1, false, false));
				}
			}
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 50, 50, 50), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				MothSpiderDwellerModVariables.MapVariables.get(world).chasemode = "yes";
				MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if (ConfigurationSettingsConfiguration.DWELLER_HEALTH.get() == true && (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 60) {
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(60);
		}
		if (entity instanceof SpiderMothDwellerEntity) {
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(MothSpiderDwellerModMobEffects.MOTH_CURSE.get());
		}
		if ((MothSpiderDwellerModVariables.MapVariables.get(world).chasemode).equals("no")) {
			MothSpiderDwellerModVariables.MapVariables.get(world).chasesoundonce = "one";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		} else {
			if ((MothSpiderDwellerModVariables.MapVariables.get(world).chasesoundonce).equals("one")) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.3, 0.7),
								(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.3, 0.7),
								(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
					}
				}
				MothSpiderDwellerModVariables.MapVariables.get(world).chasesoundonce = "no";
				MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 60, 60, 60), e -> true).isEmpty() && Mth.nextInt(RandomSource.create(), 1, 1000) > 999
				&& !(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
			MothSpiderDwellerModVariables.MapVariables.get(world).chasesoundonce = "one";
			MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 40, 40, 40), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 40, 40, 40), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 40, 40, 40), e -> true).isEmpty()) {
					if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 4, 4, 4), e -> true).isEmpty())) {
						if ((MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting).equals("spawned")) {
							MothSpiderDwellerMod.queueServerWork(300, () -> {
								MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "waiting";
								MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
							});
						} else {
							MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "waiting";
							MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
							if ((MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting).equals("waiting")) {
								MothSpiderDwellerMod.queueServerWork(300, () -> {
									if ((MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting).equals("waiting")
											&& !(!world.getEntitiesOfClass(TeleportGhostEntity.class, AABB.ofSize(new Vec3(x, y, z), 15, 15, 15), e -> true).isEmpty())) {
										if (world instanceof ServerLevel _level) {
											Entity entityToSpawn = MothSpiderDwellerModEntities.TELEPORT_GHOST.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
											if (entityToSpawn != null) {
												entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
											}
										}
										MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "spawned";
										MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
									}
								});
							}
						}
					} else {
						MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "spawned";
						MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
					}
				} else {
					MothSpiderDwellerModVariables.MapVariables.get(world).dwellerwaiting = "far";
					MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
			}
		}
		if (world.getDifficulty() == Difficulty.PEACEFUL) {
			if (!entity.level().isClientSide())
				entity.discard();
		}
		if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) && !world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).isEmpty()
				&& (MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth).equals("looking")) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 500, 500, 500), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if ((MothSpiderDwellerModVariables.MapVariables.get(world).soundonce).equals("one")) {
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"playsound moth_spider_dweller:mothscare hostile @p ~ ~ ~ 20 0.5");
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"execute as @p at @s anchored eyes run particle minecraft:smoke ~0.1 ~1.3 ~0 0 0 0 0.04 500");
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p darkness 8 1 true");
					MothSpiderDwellerModVariables.MapVariables.get(world).soundonce = "stop";
					MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
					MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "true";
					MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
				}
				MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock = "true";
				MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
				MothSpiderDwellerMod.queueServerWork(4, () -> {
					if ((MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth).equals("no")) {
						MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "false";
						MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
					}
					MothSpiderDwellerModVariables.MapVariables.get(world).chasemode = "chasing";
					MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
				});
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (entity instanceof Mob _entity && ((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _ent)
					_entity.setTarget(_ent);
				if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty())) {
					if ((MothSpiderDwellerModVariables.MapVariables.get(world).playerlookedatmoth).equals("no")) {
						if ((MothSpiderDwellerModVariables.MapVariables.get(world).chasemode).equals("no")) {
							if (entity instanceof Mob _entity)
								_entity.getNavigation().stop();
							if (entity instanceof SpiderMothDwellerEntity) {
								((SpiderMothDwellerEntity) entity).setAnimation("animation.spider_moth_dweller.staring");
							}
							entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
								Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
									return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
								}
							}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
						}
					} else {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 6, false, false));
						entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getX()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getY()), (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
							Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
								return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
							}
						}.compareDistOf(x, y, z)).findFirst().orElse(null)).getZ())));
						MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock = "true";
						MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
						MothSpiderDwellerModVariables.MapVariables.get(world).chasemode = "chasing";
						MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
						if ((MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock).equals("true")) {
							if ((MothSpiderDwellerModVariables.MapVariables.get(world).soundonce).equals("one")) {
								if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
									_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 6, false, false));
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
											"execute as @p at @s anchored eyes run particle minecraft:smoke ~0.1 ~1.3 ~0 0 0 0 0.04 500");
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
											"playsound moth_spider_dweller:mothscare hostile @p ~ ~ ~ 20 0.5");
								if (world instanceof ServerLevel _level)
									_level.getServer().getCommands().performPrefixedCommand(
											new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(), "effect give @p darkness 8 1 true");
								MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "true";
								MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
								MothSpiderDwellerModVariables.MapVariables.get(world).soundonce = "stop";
								MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
							}
							MothSpiderDwellerMod.queueServerWork(4, () -> {
								MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay = "false";
								MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
								MothSpiderDwellerModVariables.MapVariables.get(world).LookScareLock = "false";
								MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
							});
						}
					}
				}
			}
		}
		if (world.getLevelData().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING) == true
				&& ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.TORCH || (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Blocks.WALL_TORCH)) {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = Blocks.AIR.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			{
				BlockPos _bp = BlockPos.containing(x, y + 1, z);
				BlockState _bs = Blocks.AIR.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.TORCH));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 150, 150, 150), e -> true).isEmpty()) {
			if (Mth.nextInt(RandomSource.create(), 1, 1300) == 200) {
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.3, 0.7),
								(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.3, 0.7),
								(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
					}
				}
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty()) {
			if (Mth.nextInt(RandomSource.create(), 1, 300) == 200) {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase")), SoundSource.HOSTILE,
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 0.6), (float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.3, 0.6),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
						}
					}
				} else {
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase2")), SoundSource.HOSTILE,
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 0.7), (float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7));
						} else {
							_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("moth_spider_dweller:mothchase2")), SoundSource.HOSTILE, (float) Mth.nextDouble(RandomSource.create(), 0.3, 0.7),
									(float) Mth.nextDouble(RandomSource.create(), 0.3, 1.7), false);
						}
					}
				}
			}
			if (world instanceof Level _lvl99 && _lvl99.isDay()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=survival,distance=..2] darkness 1 0");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=adventure,distance=..2] darkness 1 0");
			} else {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=survival] darkness 5 0");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"effect give @p[gamemode=adventure] darkness 5 0");
			}
		}
		if (world.getLevelData().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 12, 12, 12), e -> true).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace glass");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace glass_pane");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace acacia_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace bamboo_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace birch_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cherry_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace crimson_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace dark_oak_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace jungle_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace mangrove_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace oak_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace spruce_door");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace warped_door");
			}
			if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty()) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace oak_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace azalea_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace acacia_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace dark_oak_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cherry_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace flowering_azalea_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace jungle_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace mangrove_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace spruce_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace birch_leaves");
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"fill ~-3 ~-3 ~-3 ~3 ~3 ~3 air replace cobweb");
			}
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)).getPersistentData().getBoolean("creativespectator") == false) {
				if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 100, 100, 100), e -> true).isEmpty())) {
					if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DIG_SLOWDOWN, 1200, 0, true, false));
					if (((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 200, 200, 200), e -> true).stream().sorted(new Object() {
						Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
							return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
						}
					}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MothSpiderDwellerModMobEffects.MOTH_CURSE.get(), 1200, 0, false, true));
				}
			}
		}
		if (!(!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 280, 280, 280), e -> true).isEmpty())) {
			if (!entity.level().isClientSide())
				entity.discard();
		}
		if (!world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 7, 7, 7), e -> true).isEmpty()) {
			entity.setMaxUpStep(4);
		}
		if (!world.isEmptyBlock(BlockPos.containing(x, y + 1, z))) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 2, false, false));
		}
		if (entity instanceof LivingEntity _livEnt145 && _livEnt145.hasEffect(MobEffects.DAMAGE_BOOST)) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"attribute @e[type=moth_spider_dweller:spider_moth_dweller,limit=1] minecraft:generic.attack_knockback base set 500");
		} else {
			if (entity instanceof LivingEntity _livEnt147 && _livEnt147.hasEffect(MobEffects.MOVEMENT_SLOWDOWN)) {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"attribute @e[type=moth_spider_dweller:spider_moth_dweller,limit=1] minecraft:generic.attack_knockback base set 0.5");
			} else {
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
							"attribute @e[type=moth_spider_dweller:spider_moth_dweller,limit=1] minecraft:generic.attack_knockback base set 1");
			}
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow") || (entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute as @e[type=moth_spider_dweller:spider_moth_dweller,limit=1,sort=nearest] run data merge entity @s {Invulnerable:1}");
		} else {
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"execute as @e[type=moth_spider_dweller:spider_moth_dweller,limit=1,sort=nearest] run data merge entity @s {Invulnerable:0}");
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
			MothSpiderDwellerMod.queueServerWork(20, () -> {
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("horrormothfixed");
			});
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow") || entity.getPersistentData().getBoolean("growattack") == true
				|| (entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
			MothSpiderDwellerMod.queueServerWork(60, () -> {
				if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow")) {
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("horrormothfixed");
				}
			});
		} else {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 175) {
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("horrormothfixed");
			} else {
				if (ConfigurationSettingsConfiguration.DWELLER_HEALTH.get() == false) {
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("horrormothlowhealthfixed");
				}
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20, 0, true, false));
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) < 30) {
					if (entity instanceof SpiderMothDwellerEntity animatable)
						animatable.setTexture("horrormothlowhealthfixed");
				}
			}
		}
		if (entity.getPersistentData().getBoolean("growattack") == true) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 10, 1.5, 3, 1.5, 0);
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("horrormothfixed")) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.CHARCOAL.get()), x, (y + 1), z, (int) (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1), 0.8, 1, 0.8, 3);
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("horrormothlowhealthfixed")) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.CHARRED_BLOOD.get()), x, y, z, (int) (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1), 0.8, 1, 0.8, 1);
			MothSpiderDwellerMod.queueServerWork(5, () -> {
				if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("fullshadow")) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 10, 1, false, false));
					if (world instanceof ServerLevel _level)
						_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 5, 0.5, 0.5, 0.5, 0.5);
				}
			});
		}
		if ((entity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow")) {
			entity.getPersistentData().putDouble("enbeetee", (entity.getPersistentData().getDouble("enbeetee") + 0.05));
		} else {
			entity.getPersistentData().putDouble("enbeetee", 1.45);
		}
		if (entity.isInWall() || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.POWDER_SNOW) {
			{
				Entity _ent = entity;
				_ent.teleportTo(x, (y + 0.9), z);
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport(x, (y + 0.9), z, _ent.getYRot(), _ent.getXRot());
			}
			entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 5, 3, 3, 3, 1);
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.COBWEB) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 10, 4, false, false));
		}
		if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
			if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY() > entity.getY() + 2 || entity.isInWater() || (world.getFluidState(BlockPos.containing(x - 1, y, z)).createLegacyBlock()).getBlock() instanceof LiquidBlock
					|| (world.getFluidState(BlockPos.containing(x + 1, y, z)).createLegacyBlock()).getBlock() instanceof LiquidBlock || (world.getFluidState(BlockPos.containing(x, y, z + 1)).createLegacyBlock()).getBlock() instanceof LiquidBlock
					|| (world.getFluidState(BlockPos.containing(x, y, z - 1)).createLegacyBlock()).getBlock() instanceof LiquidBlock || (world.getFluidState(BlockPos.containing(x, y, z)).createLegacyBlock()).getBlock() instanceof LiquidBlock) {
				entity.setMaxUpStep(3);
				entity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3(((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getX()), ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getY()),
						((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getZ())));
				if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player && (MothSpiderDwellerModVariables.MapVariables.get(world).chasemode).equals("no"))) {
					entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
				}
				MothSpiderDwellerMod.queueServerWork(40, () -> {
					if (Mth.nextInt(RandomSource.create(), 1, 10) == 5) {
						if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof Player && (MothSpiderDwellerModVariables.MapVariables.get(world).chasemode).equals("no"))) {
							entity.setDeltaMovement(new Vec3(Math.cos((entity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((entity.getYRot() + 90) * (Math.PI / 180))));
						}
					}
				});
			} else {
				entity.setMaxUpStep(2);
				if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).isAlive())) {
					if (entity instanceof Mob) {
						try {
							((Mob) entity).setTarget(null);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
		if (!((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) == null)) {
			if ((entity instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null).getPersistentData().getBoolean("creativespectator") == true) {
				if (entity instanceof Mob) {
					try {
						((Mob) entity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		if (entity.onGround()) {
			if (entity.getPersistentData().getDouble("dramaticfall") > 40) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get()), x, y, z, 40, 0.1, 1, 0.1, 0.3);
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.warden.sonic_boom")), SoundSource.NEUTRAL, (float) 0.3, (float) 0.5);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.warden.sonic_boom")), SoundSource.NEUTRAL, (float) 0.3, (float) 0.5, false);
					}
				}
			}
			entity.getPersistentData().putDouble("dramaticfall", 0);
		} else {
			entity.getPersistentData().putDouble("dramaticfall", (entity.getPersistentData().getDouble("dramaticfall") + 1));
		}
	}
}
