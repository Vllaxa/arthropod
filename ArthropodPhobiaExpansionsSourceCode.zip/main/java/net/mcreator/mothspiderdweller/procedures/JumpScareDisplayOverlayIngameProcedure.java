package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;

public class JumpScareDisplayOverlayIngameProcedure {
	public static boolean execute(LevelAccessor world) {
		return (MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay).equals("true");
	}
}
