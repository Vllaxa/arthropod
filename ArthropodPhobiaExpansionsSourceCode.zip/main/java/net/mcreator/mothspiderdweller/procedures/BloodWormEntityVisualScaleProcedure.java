package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingEvent;

import net.minecraft.world.entity.Entity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class BloodWormEntityVisualScaleProcedure {
	@SubscribeEvent
	public static void onEntityTick(LivingEvent.LivingTickEvent event) {
		execute(event, event.getEntity());
	}

	public static double execute(Entity entity) {
		return execute(null, entity);
	}

	private static double execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return 0;
		double randomsize = 0;
		if (entity.getPersistentData().getDouble("randomsize") < 0.3) {
			randomsize = 1;
		} else {
			randomsize = entity.getPersistentData().getDouble("randomsize");
		}
		return randomsize;
	}
}
