package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModParticleTypes;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class SpiderBroodEntityIsHurtProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setYRot((float) 0.1);
				entityToSpawn.setYBodyRot((float) 0.1);
				entityToSpawn.setYHeadRot((float) 0.1);
				entityToSpawn.setDeltaMovement(0.3, 0, 0);
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setYRot((float) 0.1);
				entityToSpawn.setYBodyRot((float) 0.1);
				entityToSpawn.setYHeadRot((float) 0.1);
				entityToSpawn.setDeltaMovement((-0.3), 0, 0);
			}
		}
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (MothSpiderDwellerModParticleTypes.THIN_WEB.get()), x, y, z, 30, 1, 1, 1, 0.5);
		entity.setSprinting(true);
		MothSpiderDwellerMod.queueServerWork(20, () -> {
			entity.setSprinting(false);
		});
	}
}
