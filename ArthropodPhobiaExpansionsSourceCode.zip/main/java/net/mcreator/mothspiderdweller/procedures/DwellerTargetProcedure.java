package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Spider;
import net.minecraft.world.entity.monster.CaveSpider;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModMobEffects;
import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.entity.WebbedArrowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeTinyEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderBroodEntity;
import net.mcreator.mothspiderdweller.entity.LongLegsTinyEntity;
import net.mcreator.mothspiderdweller.entity.LongLegsEntity;
import net.mcreator.mothspiderdweller.entity.BeetleTickMiteEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Comparator;

@Mod.EventBusSubscriber
public class DwellerTargetProcedure {
	@SubscribeEvent
	public static void onEntitySetsAttackTarget(LivingChangeTargetEvent event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getOriginalTarget(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (sourceentity instanceof SpiderMothDwellerEntity) {
			if (entity instanceof Player && entity.getPersistentData().getBoolean("creativespectator") == true || !entity.isAlive()) {
				if (sourceentity instanceof Mob) {
					try {
						((Mob) sourceentity).setTarget(null);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(10 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (entityiterator == entity && entity.isAlive()) {
						if (!(sourceentity instanceof LivingEntity _livEnt7 && _livEnt7.hasEffect(MobEffects.MOVEMENT_SLOWDOWN))) {
							if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 30, 0, true, false));
						}
					}
				}
			}
			if (!(entity.getPersistentData().getBoolean("growattack") == true || (sourceentity instanceof SpiderMothDwellerEntity animatable ? animatable.getTexture() : "null").equals("redglow"))) {
				if (sourceentity.getX() + 2.3 > entity.getX() && sourceentity.getX() - 2.3 < entity.getX() && sourceentity.getY() + 1 > entity.getY() && sourceentity.getY() - 1 < entity.getY() && sourceentity.getZ() + 2.3 > entity.getZ()
						&& sourceentity.getZ() - 2.3 < entity.getZ()) {
					sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
					if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3, 0, true, false));
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 7, true, false));
					if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 3, 4, true, false));
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 5, 3, true, false));
					if (world instanceof ServerLevel _level)
						_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
								"effect give @p[distance=..3] minecraft:nausea 4 3");
				}
			}
			if (sourceentity.isInWater()) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.BUBBLE_POP, x, y, z, 30, 2, 2, 2, 0.3);
			}
			if ((MothSpiderDwellerModVariables.MapVariables.get(world).ShowOverlay).equals("true")) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), 0.7, Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
				MothSpiderDwellerMod.queueServerWork(15, () -> {
					sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
					sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), 0.1, Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
				});
			}
			if (sourceentity.getPersistentData().getBoolean("growattack") == true) {
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				if (entity instanceof SpiderMothDwellerEntity animatable)
					animatable.setTexture("redglow");
			}
		}
		if (sourceentity instanceof SpiderLarvaeEntity) {
			if (sourceentity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.LEVITATION);
			if (sourceentity instanceof LivingEntity _entity)
				_entity.removeEffect(MobEffects.SLOW_FALLING);
		}
		if ((sourceentity instanceof LongLegsEntity || sourceentity instanceof LongLegsTinyEntity || sourceentity instanceof SpiderLarvaeEntity || sourceentity instanceof SpiderLarvaeTinyEntity || sourceentity instanceof BeetleTickMiteEntity)
				&& entity.getY() < sourceentity.getY() - 0.9) {
			sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
			sourceentity.setDeltaMovement(new Vec3(Math.cos((sourceentity.getYRot() + 90) * (Math.PI / 180)), (-1), Math.sin((sourceentity.getYRot() + 90) * (Math.PI / 180))));
		}
		if (entity instanceof SpiderBroodEntity && (sourceentity instanceof SpiderLarvaeEntity || sourceentity instanceof SpiderLarvaeTinyEntity || sourceentity instanceof CaveSpider || sourceentity instanceof Spider)) {
			if (sourceentity instanceof Mob) {
				try {
					((Mob) sourceentity).setTarget(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (sourceentity instanceof SpiderBroodEntity) {
			if (sourceentity instanceof Mob _entity)
				_entity.getNavigation().moveTo((entity.getX()), (entity.getY()), (entity.getZ()), 1);
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (entityiterator == entity) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.WITHER, 20, 3, false, false));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2, false, false));
					}
				}
			}
		}
		if (sourceentity instanceof SpiderWidowEntity && entity instanceof LivingEntity _livEnt89 && _livEnt89.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get())
				&& !world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3((entity.getX()), (entity.getY()), (entity.getZ())), 7, 7, 7), e -> true).isEmpty()) {
			if (((Entity) world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3((entity.getX()), (entity.getY()), (entity.getZ())), 7, 7, 7), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf((entity.getX()), (entity.getY()), (entity.getZ()))).findFirst().orElse(null)) == sourceentity) {
				if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 10, 10, false, false));
				sourceentity.lookAt(EntityAnchorArgument.Anchor.EYES, new Vec3((entity.getX()), (entity.getY()), (entity.getZ())));
				sourceentity.setDeltaMovement(new Vec3((Math.cos((sourceentity.getYRot() - 90) * (Math.PI / 180)) / 2), (-1), (Math.sin((sourceentity.getYRot() - 90) * (Math.PI / 180)) / 2)));
			}
		}
		if (sourceentity instanceof SpiderWidowEntity && entity instanceof LivingEntity _livEnt108 && _livEnt108.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get())) {
			if (sourceentity.getPersistentData().getDouble("webtime") == 5) {
				sourceentity.setSprinting(true);
				{
					Entity _shootFrom = sourceentity;
					Level projectileLevel = _shootFrom.level();
					if (!projectileLevel.isClientSide()) {
						Projectile _entityToSpawn = new Object() {
							public Projectile getArrow(Level level, Entity shooter, float damage, int knockback) {
								AbstractArrow entityToSpawn = new WebbedArrowEntity(MothSpiderDwellerModEntities.WEBBED_ARROW.get(), level);
								entityToSpawn.setOwner(shooter);
								entityToSpawn.setBaseDamage(damage);
								entityToSpawn.setKnockback(knockback);
								entityToSpawn.setSilent(true);
								return entityToSpawn;
							}
						}.getArrow(projectileLevel, sourceentity, 5, 1);
						_entityToSpawn.setPos(_shootFrom.getX(), _shootFrom.getEyeY() - 0.1, _shootFrom.getZ());
						_entityToSpawn.shoot(_shootFrom.getLookAngle().x, _shootFrom.getLookAngle().y, _shootFrom.getLookAngle().z, 4, (float) 0.05);
						projectileLevel.addFreshEntity(_entityToSpawn);
					}
				}
				MothSpiderDwellerMod.queueServerWork(20, () -> {
					sourceentity.setSprinting(false);
				});
			}
		}
		if (sourceentity instanceof SpiderWidowEntity && !(entity instanceof LivingEntity _livEnt116 && _livEnt116.hasEffect(MothSpiderDwellerModMobEffects.WEBBED.get()))) {
			MothSpiderDwellerMod.queueServerWork(10, () -> {
				sourceentity.setSprinting(false);
			});
		}
	}
}
