package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeTinyEntity;

import java.util.Comparator;

public class SpiderLarvaeTinyOnInitialEntitySpawnProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		MothSpiderDwellerModVariables.MapVariables.get(world).spidergrab = "no";
		MothSpiderDwellerModVariables.MapVariables.get(world).syncData(world);
		if (!world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).isEmpty()) {
			if (entity instanceof Mob _entity && (((Entity) world.getEntitiesOfClass(SpiderWidowEntity.class, AABB.ofSize(new Vec3(x, y, z), 20, 20, 20), e -> true).stream().sorted(new Object() {
				Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
					return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
				}
			}.compareDistOf(x, y, z)).findFirst().orElse(null)) instanceof Mob _mobEnt ? (Entity) _mobEnt.getTarget() : null) instanceof LivingEntity _ent)
				_entity.setTarget(_ent);
			if (entity instanceof SpiderLarvaeTinyEntity animatable)
				animatable.setTexture("spiderwidow");
		} else {
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 3) {
				if (entity instanceof SpiderLarvaeTinyEntity animatable)
					animatable.setTexture("spiderlarvae2");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 2) {
				if (entity instanceof SpiderLarvaeTinyEntity animatable)
					animatable.setTexture("spiderlarvae3");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 1) {
				if (entity instanceof SpiderLarvaeTinyEntity animatable)
					animatable.setTexture("spiderlarvae4");
			}
			if (Mth.nextInt(RandomSource.create(), 1, 6) == 4) {
				if (entity instanceof SpiderLarvaeTinyEntity animatable)
					animatable.setTexture("spiderlarvae5");
			}
		}
	}
}
