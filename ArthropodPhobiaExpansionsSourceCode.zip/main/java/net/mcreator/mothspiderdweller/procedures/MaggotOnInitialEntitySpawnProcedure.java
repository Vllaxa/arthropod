package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.mothspiderdweller.entity.MaggotEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class MaggotOnInitialEntitySpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (Mth.nextInt(RandomSource.create(), 1, 10) == 5) {
			if (entity instanceof MaggotEntity animatable)
				animatable.setTexture("maggotlayersbrown");
		}
		if (entity instanceof MaggotEntity) {
			entity.getPersistentData().putDouble("randomsize", (Mth.nextDouble(RandomSource.create(), 0.3, 1.1)));
		}
	}
}
