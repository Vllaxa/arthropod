package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.mothspiderdweller.init.MothSpiderDwellerModEntities;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class SpiderBroodEntityDiesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setDeltaMovement(0.3, 0, 0);
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setDeltaMovement((-0.3), 0, 0);
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setDeltaMovement(0, 0, 0.3);
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setDeltaMovement(0, 0, (-0.3));
			}
		}
		if (world instanceof ServerLevel _level) {
			Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
			if (entityToSpawn != null) {
				entityToSpawn.setDeltaMovement(0, 0, 0);
			}
		}
		MothSpiderDwellerMod.queueServerWork(5, () -> {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0.1, 0, 0);
				}
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement((-0.1), 0, 0);
				}
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0, 0.1);
				}
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0, (-0.1));
				}
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				if (entityToSpawn != null) {
					entityToSpawn.setDeltaMovement(0, 0.1, 0);
				}
			}
		});
	}
}
