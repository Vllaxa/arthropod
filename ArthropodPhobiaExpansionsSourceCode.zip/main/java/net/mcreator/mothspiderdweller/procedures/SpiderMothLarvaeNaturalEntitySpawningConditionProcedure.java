package net.mcreator.mothspiderdweller.procedures;

import net.mcreator.mothspiderdweller.configuration.ConfigurationSettingsConfiguration;

public class SpiderMothLarvaeNaturalEntitySpawningConditionProcedure {
	public static boolean execute() {
		return ConfigurationSettingsConfiguration.SPAWN_LARVAE_NATURALLY.get() == true;
	}
}
