package net.mcreator.mothspiderdweller.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.mothspiderdweller.network.MothSpiderDwellerModVariables;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.configuration.ConfigurationSettingsConfiguration;

import java.util.Comparator;

public class SpiderMothDwellerNaturalEntitySpawningConditionProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		return ((double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() == 2 && Mth.nextInt(RandomSource.create(), 1, 2) == 2
				|| (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() == 3 && Mth.nextInt(RandomSource.create(), 1, 3) == 2
				|| (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() == 3 && Mth.nextInt(RandomSource.create(), 1, 4) == 2 || (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() <= 1
				|| (double) ConfigurationSettingsConfiguration.DWELLER_FREQUENCY.get() >= 5)
				&& (world.getLevelData().isThundering() && ConfigurationSettingsConfiguration.DWELLER_REQUIRE_THUNDER.get() == true || ConfigurationSettingsConfiguration.DWELLER_REQUIRE_THUNDER.get() == false)
				&& !(!world.getEntitiesOfClass(SpiderMothDwellerEntity.class, AABB.ofSize(new Vec3(x, y, z), 10000, 10000, 10000), e -> true).isEmpty()) && ConfigurationSettingsConfiguration.SPAWN_DWELLER_NATURALLY.get() == true
				&& !((((Entity) world.getEntitiesOfClass(Player.class, AABB.ofSize(new Vec3(x, y, z), 300, 300, 300), e -> true).stream().sorted(new Object() {
					Comparator<Entity> compareDistOf(double _x, double _y, double _z) {
						return Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_x, _y, _z));
					}
				}.compareDistOf(x, y, z)).findFirst().orElse(null)).getCapability(MothSpiderDwellerModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new MothSpiderDwellerModVariables.PlayerVariables())).mothsurvivals == 5);
	}
}
