package net.mcreator.mothspiderdweller.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;

import net.mcreator.mothspiderdweller.entity.WaterRoachEntity;
import net.mcreator.mothspiderdweller.entity.BloodWormEntity;
import net.mcreator.mothspiderdweller.entity.BeetleTickMiteEntity;
import net.mcreator.mothspiderdweller.entity.AntGiantEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class BloodWormOnInitialEntitySpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof BloodWormEntity || entity instanceof AntGiantEntity) {
			entity.getPersistentData().putDouble("randomsize", (Mth.nextDouble(RandomSource.create(), 0.3, 1.5)));
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof BloodWormEntity animatable)
					animatable.setTexture("bloodworm2");
			}
		}
		if (entity instanceof WaterRoachEntity) {
			entity.getPersistentData().putDouble("randomsize", (Mth.nextDouble(RandomSource.create(), 0.3, 0.9)));
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (entity instanceof WaterRoachEntity animatable)
					animatable.setTexture("waterroach2noclaws");
			} else {
				if (Mth.nextInt(RandomSource.create(), 1, 4) == 2) {
					if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
						if (entity instanceof WaterRoachEntity animatable)
							animatable.setTexture("waterroach2");
					} else {
						if (entity instanceof WaterRoachEntity animatable)
							animatable.setTexture("waterroach");
					}
				}
			}
		}
		if (entity instanceof BeetleTickMiteEntity) {
			if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
				if (Mth.nextInt(RandomSource.create(), 1, 2) == 2) {
					if (entity instanceof BeetleTickMiteEntity animatable)
						animatable.setTexture("beetletickmiteb");
				} else {
					if (entity instanceof BeetleTickMiteEntity animatable)
						animatable.setTexture("beetletickmitem");
				}
			}
		}
	}
}
