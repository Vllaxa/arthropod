
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class MothSpiderDwellerModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MothSpiderDwellerMod.MODID);
	public static final RegistryObject<SoundEvent> MOTHSCARE = REGISTRY.register("mothscare", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("moth_spider_dweller", "mothscare")));
	public static final RegistryObject<SoundEvent> MOTHCHASE = REGISTRY.register("mothchase", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("moth_spider_dweller", "mothchase")));
	public static final RegistryObject<SoundEvent> MOTHCHASE2 = REGISTRY.register("mothchase2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("moth_spider_dweller", "mothchase2")));
}
