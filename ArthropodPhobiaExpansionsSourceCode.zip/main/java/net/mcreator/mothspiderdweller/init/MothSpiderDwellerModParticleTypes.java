
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class MothSpiderDwellerModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, MothSpiderDwellerMod.MODID);
	public static final RegistryObject<SimpleParticleType> HEAVY_SMOKE = REGISTRY.register("heavy_smoke", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> THIN_WEB = REGISTRY.register("thin_web", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> CHARCOAL = REGISTRY.register("charcoal", () -> new SimpleParticleType(true));
	public static final RegistryObject<SimpleParticleType> CHARRED_BLOOD = REGISTRY.register("charred_blood", () -> new SimpleParticleType(true));
}
