
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.mothspiderdweller.entity.WebbedArrowEntity;
import net.mcreator.mothspiderdweller.entity.WaterRoachEntity;
import net.mcreator.mothspiderdweller.entity.TeleportGhostEntity;
import net.mcreator.mothspiderdweller.entity.SunScorpionTinyEntity;
import net.mcreator.mothspiderdweller.entity.SunScorpionEntity;
import net.mcreator.mothspiderdweller.entity.SpiderWidowEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderMothDwellerEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeTinyEntity;
import net.mcreator.mothspiderdweller.entity.SpiderLarvaeEntity;
import net.mcreator.mothspiderdweller.entity.SpiderFlatEntity;
import net.mcreator.mothspiderdweller.entity.SpiderBroodEntityProjectile;
import net.mcreator.mothspiderdweller.entity.SpiderBroodEntity;
import net.mcreator.mothspiderdweller.entity.SkyStalkerEntity;
import net.mcreator.mothspiderdweller.entity.RushScareEntity;
import net.mcreator.mothspiderdweller.entity.PureStalkingEntity;
import net.mcreator.mothspiderdweller.entity.MothShadowCloneEntity;
import net.mcreator.mothspiderdweller.entity.MaggotEntity;
import net.mcreator.mothspiderdweller.entity.LongLegsTinyEntity;
import net.mcreator.mothspiderdweller.entity.LongLegsEntity;
import net.mcreator.mothspiderdweller.entity.DwellerSleepSpawnerEntity;
import net.mcreator.mothspiderdweller.entity.CentipedeStalkerEntity;
import net.mcreator.mothspiderdweller.entity.BloodWormEntity;
import net.mcreator.mothspiderdweller.entity.BloodProjectileEntity;
import net.mcreator.mothspiderdweller.entity.BeetleTickMiteEntity;
import net.mcreator.mothspiderdweller.entity.AntGiantEntity;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MothSpiderDwellerModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MothSpiderDwellerMod.MODID);
	public static final RegistryObject<EntityType<BloodProjectileEntity>> BLOOD_PROJECTILE = register("projectile_blood_projectile", EntityType.Builder.<BloodProjectileEntity>of(BloodProjectileEntity::new, MobCategory.MISC)
			.setCustomClientFactory(BloodProjectileEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SpiderMothDwellerEntity>> SPIDER_MOTH_DWELLER = register("spider_moth_dweller", EntityType.Builder.<SpiderMothDwellerEntity>of(SpiderMothDwellerEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(130).setUpdateInterval(3).setCustomClientFactory(SpiderMothDwellerEntity::new).fireImmune().sized(0.99f, 0.99f));
	public static final RegistryObject<EntityType<SpiderMothLarvaeEntity>> SPIDER_MOTH_LARVAE = register("spider_moth_larvae", EntityType.Builder.<SpiderMothLarvaeEntity>of(SpiderMothLarvaeEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderMothLarvaeEntity::new).fireImmune().sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<TeleportGhostEntity>> TELEPORT_GHOST = register("teleport_ghost", EntityType.Builder.<TeleportGhostEntity>of(TeleportGhostEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TeleportGhostEntity::new).fireImmune().sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<MothShadowCloneEntity>> MOTH_SHADOW_CLONE = register("moth_shadow_clone", EntityType.Builder.<MothShadowCloneEntity>of(MothShadowCloneEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(MothShadowCloneEntity::new).fireImmune().sized(5f, 5f));
	public static final RegistryObject<EntityType<SpiderLarvaeEntity>> SPIDER_LARVAE = register("spider_larvae",
			EntityType.Builder.<SpiderLarvaeEntity>of(SpiderLarvaeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderLarvaeEntity::new)

					.sized(0.7f, 0.7f));
	public static final RegistryObject<EntityType<SpiderLarvaeTinyEntity>> SPIDER_LARVAE_TINY = register("spider_larvae_tiny",
			EntityType.Builder.<SpiderLarvaeTinyEntity>of(SpiderLarvaeTinyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderLarvaeTinyEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<SunScorpionEntity>> SUN_SCORPION = register("sun_scorpion", EntityType.Builder.<SunScorpionEntity>of(SunScorpionEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SunScorpionEntity::new).fireImmune().sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<SunScorpionTinyEntity>> SUN_SCORPION_TINY = register("sun_scorpion_tiny", EntityType.Builder.<SunScorpionTinyEntity>of(SunScorpionTinyEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SunScorpionTinyEntity::new).fireImmune().sized(0.7f, 0.7f));
	public static final RegistryObject<EntityType<LongLegsEntity>> LONG_LEGS = register("long_legs",
			EntityType.Builder.<LongLegsEntity>of(LongLegsEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LongLegsEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<LongLegsTinyEntity>> LONG_LEGS_TINY = register("long_legs_tiny",
			EntityType.Builder.<LongLegsTinyEntity>of(LongLegsTinyEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LongLegsTinyEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<DwellerSleepSpawnerEntity>> DWELLER_SLEEP_SPAWNER = register("dweller_sleep_spawner", EntityType.Builder.<DwellerSleepSpawnerEntity>of(DwellerSleepSpawnerEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DwellerSleepSpawnerEntity::new).fireImmune().sized(1f, 3f));
	public static final RegistryObject<EntityType<CentipedeStalkerEntity>> CENTIPEDE_STALKER = register("centipede_stalker",
			EntityType.Builder.<CentipedeStalkerEntity>of(CentipedeStalkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3).setCustomClientFactory(CentipedeStalkerEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<MaggotEntity>> MAGGOT = register("maggot",
			EntityType.Builder.<MaggotEntity>of(MaggotEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(6).setUpdateInterval(3).setCustomClientFactory(MaggotEntity::new)

					.sized(0.6f, 0.6f));
	public static final RegistryObject<EntityType<BloodWormEntity>> BLOOD_WORM = register("blood_worm",
			EntityType.Builder.<BloodWormEntity>of(BloodWormEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(60).setUpdateInterval(3).setCustomClientFactory(BloodWormEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<WaterRoachEntity>> WATER_ROACH = register("water_roach", EntityType.Builder.<WaterRoachEntity>of(WaterRoachEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(WaterRoachEntity::new).fireImmune().sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<BeetleTickMiteEntity>> BEETLE_TICK_MITE = register("beetle_tick_mite",
			EntityType.Builder.<BeetleTickMiteEntity>of(BeetleTickMiteEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BeetleTickMiteEntity::new)

					.sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<PureStalkingEntity>> PURE_STALKING = register("pure_stalking", EntityType.Builder.<PureStalkingEntity>of(PureStalkingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(PureStalkingEntity::new).fireImmune().sized(1f, 1f));
	public static final RegistryObject<EntityType<RushScareEntity>> RUSH_SCARE = register("rush_scare", EntityType.Builder.<RushScareEntity>of(RushScareEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(100)
			.setUpdateInterval(3).setCustomClientFactory(RushScareEntity::new).fireImmune().sized(1.9f, 1.9f));
	public static final RegistryObject<EntityType<SpiderBroodEntity>> SPIDER_BROOD = register("spider_brood",
			EntityType.Builder.<SpiderBroodEntity>of(SpiderBroodEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiderBroodEntity::new)

					.sized(0.9f, 0.9f));
	public static final RegistryObject<EntityType<SpiderBroodEntityProjectile>> SPIDER_BROOD_PROJECTILE = register("projectile_spider_brood", EntityType.Builder.<SpiderBroodEntityProjectile>of(SpiderBroodEntityProjectile::new, MobCategory.MISC)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).setCustomClientFactory(SpiderBroodEntityProjectile::new).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<SkyStalkerEntity>> SKY_STALKER = register("sky_stalker", EntityType.Builder.<SkyStalkerEntity>of(SkyStalkerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(50)
			.setUpdateInterval(3).setCustomClientFactory(SkyStalkerEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<SpiderWidowEntity>> SPIDER_WIDOW = register("spider_widow",
			EntityType.Builder.<SpiderWidowEntity>of(SpiderWidowEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3).setCustomClientFactory(SpiderWidowEntity::new)

					.sized(1.3f, 1.3f));
	public static final RegistryObject<EntityType<SpiderFlatEntity>> SPIDER_FLAT = register("spider_flat",
			EntityType.Builder.<SpiderFlatEntity>of(SpiderFlatEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3).setCustomClientFactory(SpiderFlatEntity::new)

					.sized(1f, 1f));
	public static final RegistryObject<EntityType<WebbedArrowEntity>> WEBBED_ARROW = register("projectile_webbed_arrow",
			EntityType.Builder.<WebbedArrowEntity>of(WebbedArrowEntity::new, MobCategory.MISC).setCustomClientFactory(WebbedArrowEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final RegistryObject<EntityType<AntGiantEntity>> ANT_GIANT = register("ant_giant",
			EntityType.Builder.<AntGiantEntity>of(AntGiantEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(20).setUpdateInterval(3).setCustomClientFactory(AntGiantEntity::new)

					.sized(0.4f, 0.4f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			SpiderMothDwellerEntity.init();
			SpiderMothLarvaeEntity.init();
			TeleportGhostEntity.init();
			MothShadowCloneEntity.init();
			SpiderLarvaeEntity.init();
			SpiderLarvaeTinyEntity.init();
			SunScorpionEntity.init();
			SunScorpionTinyEntity.init();
			LongLegsEntity.init();
			LongLegsTinyEntity.init();
			DwellerSleepSpawnerEntity.init();
			CentipedeStalkerEntity.init();
			MaggotEntity.init();
			BloodWormEntity.init();
			WaterRoachEntity.init();
			BeetleTickMiteEntity.init();
			PureStalkingEntity.init();
			RushScareEntity.init();
			SpiderBroodEntity.init();
			SkyStalkerEntity.init();
			SpiderWidowEntity.init();
			SpiderFlatEntity.init();
			AntGiantEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(SPIDER_MOTH_DWELLER.get(), SpiderMothDwellerEntity.createAttributes().build());
		event.put(SPIDER_MOTH_LARVAE.get(), SpiderMothLarvaeEntity.createAttributes().build());
		event.put(TELEPORT_GHOST.get(), TeleportGhostEntity.createAttributes().build());
		event.put(MOTH_SHADOW_CLONE.get(), MothShadowCloneEntity.createAttributes().build());
		event.put(SPIDER_LARVAE.get(), SpiderLarvaeEntity.createAttributes().build());
		event.put(SPIDER_LARVAE_TINY.get(), SpiderLarvaeTinyEntity.createAttributes().build());
		event.put(SUN_SCORPION.get(), SunScorpionEntity.createAttributes().build());
		event.put(SUN_SCORPION_TINY.get(), SunScorpionTinyEntity.createAttributes().build());
		event.put(LONG_LEGS.get(), LongLegsEntity.createAttributes().build());
		event.put(LONG_LEGS_TINY.get(), LongLegsTinyEntity.createAttributes().build());
		event.put(DWELLER_SLEEP_SPAWNER.get(), DwellerSleepSpawnerEntity.createAttributes().build());
		event.put(CENTIPEDE_STALKER.get(), CentipedeStalkerEntity.createAttributes().build());
		event.put(MAGGOT.get(), MaggotEntity.createAttributes().build());
		event.put(BLOOD_WORM.get(), BloodWormEntity.createAttributes().build());
		event.put(WATER_ROACH.get(), WaterRoachEntity.createAttributes().build());
		event.put(BEETLE_TICK_MITE.get(), BeetleTickMiteEntity.createAttributes().build());
		event.put(PURE_STALKING.get(), PureStalkingEntity.createAttributes().build());
		event.put(RUSH_SCARE.get(), RushScareEntity.createAttributes().build());
		event.put(SPIDER_BROOD.get(), SpiderBroodEntity.createAttributes().build());
		event.put(SKY_STALKER.get(), SkyStalkerEntity.createAttributes().build());
		event.put(SPIDER_WIDOW.get(), SpiderWidowEntity.createAttributes().build());
		event.put(SPIDER_FLAT.get(), SpiderFlatEntity.createAttributes().build());
		event.put(ANT_GIANT.get(), AntGiantEntity.createAttributes().build());
	}
}
