
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.mothspiderdweller.potion.WebbedMobEffect;
import net.mcreator.mothspiderdweller.potion.SpiderSilkTouchMobEffect;
import net.mcreator.mothspiderdweller.potion.MothCurseMobEffect;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class MothSpiderDwellerModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, MothSpiderDwellerMod.MODID);
	public static final RegistryObject<MobEffect> MOTH_CURSE = REGISTRY.register("moth_curse", () -> new MothCurseMobEffect());
	public static final RegistryObject<MobEffect> SPIDER_SILK_TOUCH = REGISTRY.register("spider_silk_touch", () -> new SpiderSilkTouchMobEffect());
	public static final RegistryObject<MobEffect> WEBBED = REGISTRY.register("webbed", () -> new WebbedMobEffect());
}
