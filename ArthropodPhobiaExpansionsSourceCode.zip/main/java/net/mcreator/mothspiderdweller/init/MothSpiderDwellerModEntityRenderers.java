
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.mothspiderdweller.client.renderer.WaterRoachRenderer;
import net.mcreator.mothspiderdweller.client.renderer.TeleportGhostRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SunScorpionTinyRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SunScorpionRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderWidowRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderMothLarvaeRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderMothDwellerRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderLarvaeTinyRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderLarvaeRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderFlatRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SpiderBroodRenderer;
import net.mcreator.mothspiderdweller.client.renderer.SkyStalkerRenderer;
import net.mcreator.mothspiderdweller.client.renderer.RushScareRenderer;
import net.mcreator.mothspiderdweller.client.renderer.PureStalkingRenderer;
import net.mcreator.mothspiderdweller.client.renderer.MothShadowCloneRenderer;
import net.mcreator.mothspiderdweller.client.renderer.MaggotRenderer;
import net.mcreator.mothspiderdweller.client.renderer.LongLegsTinyRenderer;
import net.mcreator.mothspiderdweller.client.renderer.LongLegsRenderer;
import net.mcreator.mothspiderdweller.client.renderer.DwellerSleepSpawnerRenderer;
import net.mcreator.mothspiderdweller.client.renderer.CentipedeStalkerRenderer;
import net.mcreator.mothspiderdweller.client.renderer.BloodWormRenderer;
import net.mcreator.mothspiderdweller.client.renderer.BeetleTickMiteRenderer;
import net.mcreator.mothspiderdweller.client.renderer.AntGiantRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MothSpiderDwellerModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(MothSpiderDwellerModEntities.BLOOD_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_MOTH_DWELLER.get(), SpiderMothDwellerRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_MOTH_LARVAE.get(), SpiderMothLarvaeRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.TELEPORT_GHOST.get(), TeleportGhostRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.MOTH_SHADOW_CLONE.get(), MothShadowCloneRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_LARVAE.get(), SpiderLarvaeRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_LARVAE_TINY.get(), SpiderLarvaeTinyRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SUN_SCORPION.get(), SunScorpionRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SUN_SCORPION_TINY.get(), SunScorpionTinyRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.LONG_LEGS.get(), LongLegsRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.LONG_LEGS_TINY.get(), LongLegsTinyRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.DWELLER_SLEEP_SPAWNER.get(), DwellerSleepSpawnerRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.CENTIPEDE_STALKER.get(), CentipedeStalkerRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.MAGGOT.get(), MaggotRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.BLOOD_WORM.get(), BloodWormRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.WATER_ROACH.get(), WaterRoachRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.BEETLE_TICK_MITE.get(), BeetleTickMiteRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.PURE_STALKING.get(), PureStalkingRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.RUSH_SCARE.get(), RushScareRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_BROOD.get(), SpiderBroodRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_BROOD_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SKY_STALKER.get(), SkyStalkerRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_WIDOW.get(), SpiderWidowRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.SPIDER_FLAT.get(), SpiderFlatRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.WEBBED_ARROW.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(MothSpiderDwellerModEntities.ANT_GIANT.get(), AntGiantRenderer::new);
	}
}
