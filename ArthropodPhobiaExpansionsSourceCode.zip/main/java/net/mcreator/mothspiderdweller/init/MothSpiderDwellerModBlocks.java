
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.mothspiderdweller.block.MangledSpiderFleshBlock;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class MothSpiderDwellerModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, MothSpiderDwellerMod.MODID);
	public static final RegistryObject<Block> MANGLED_SPIDER_FLESH = REGISTRY.register("mangled_spider_flesh", () -> new MangledSpiderFleshBlock());
}
