
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mothspiderdweller.item.MaggotGrubItem;
import net.mcreator.mothspiderdweller.item.BaneOfTheDarknessItem;
import net.mcreator.mothspiderdweller.item.AbyssalPickaxeItem;
import net.mcreator.mothspiderdweller.item.AbyssalCrystalItem;
import net.mcreator.mothspiderdweller.item.AbyssalBladeItem;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

public class MothSpiderDwellerModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, MothSpiderDwellerMod.MODID);
	public static final RegistryObject<Item> ABYSSAL_BLADE = REGISTRY.register("abyssal_blade", () -> new AbyssalBladeItem());
	public static final RegistryObject<Item> ABYSSAL_CRYSTAL = REGISTRY.register("abyssal_crystal", () -> new AbyssalCrystalItem());
	public static final RegistryObject<Item> SPIDER_MOTH_DWELLER_SPAWN_EGG = REGISTRY.register("spider_moth_dweller_spawn_egg",
			() -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SPIDER_MOTH_DWELLER, -13434880, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> SPIDER_MOTH_LARVAE_SPAWN_EGG = REGISTRY.register("spider_moth_larvae_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SPIDER_MOTH_LARVAE, -10092493, -13434829, new Item.Properties()));
	public static final RegistryObject<Item> MANGLED_SPIDER_FLESH = block(MothSpiderDwellerModBlocks.MANGLED_SPIDER_FLESH);
	public static final RegistryObject<Item> BANE_OF_THE_DARKNESS = REGISTRY.register("bane_of_the_darkness", () -> new BaneOfTheDarknessItem());
	public static final RegistryObject<Item> TELEPORT_GHOST_SPAWN_EGG = REGISTRY.register("teleport_ghost_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.TELEPORT_GHOST, -10066330, -1, new Item.Properties()));
	public static final RegistryObject<Item> SPIDER_LARVAE_SPAWN_EGG = REGISTRY.register("spider_larvae_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SPIDER_LARVAE, -13434880, -10092493, new Item.Properties()));
	public static final RegistryObject<Item> ABYSSAL_PICKAXE = REGISTRY.register("abyssal_pickaxe", () -> new AbyssalPickaxeItem());
	public static final RegistryObject<Item> SUN_SCORPION_SPAWN_EGG = REGISTRY.register("sun_scorpion_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SUN_SCORPION, -26215, -13159, new Item.Properties()));
	public static final RegistryObject<Item> LONG_LEGS_SPAWN_EGG = REGISTRY.register("long_legs_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.LONG_LEGS, -26317, -13159, new Item.Properties()));
	public static final RegistryObject<Item> CENTIPEDE_STALKER_SPAWN_EGG = REGISTRY.register("centipede_stalker_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.CENTIPEDE_STALKER, -26368, -10079488, new Item.Properties()));
	public static final RegistryObject<Item> MAGGOT_GRUB = REGISTRY.register("maggot_grub", () -> new MaggotGrubItem());
	public static final RegistryObject<Item> MAGGOT_SPAWN_EGG = REGISTRY.register("maggot_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.MAGGOT, -13108, -52, new Item.Properties()));
	public static final RegistryObject<Item> BLOOD_WORM_SPAWN_EGG = REGISTRY.register("blood_worm_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.BLOOD_WORM, -26215, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> WATER_ROACH_SPAWN_EGG = REGISTRY.register("water_roach_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.WATER_ROACH, -3381760, -13434880, new Item.Properties()));
	public static final RegistryObject<Item> BEETLE_TICK_MITE_SPAWN_EGG = REGISTRY.register("beetle_tick_mite_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.BEETLE_TICK_MITE, -10079488, -10066432, new Item.Properties()));
	public static final RegistryObject<Item> SPIDER_BROOD_SPAWN_EGG = REGISTRY.register("spider_brood_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SPIDER_BROOD, -13434880, -6653046, new Item.Properties()));
	public static final RegistryObject<Item> SPIDER_WIDOW_SPAWN_EGG = REGISTRY.register("spider_widow_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SPIDER_WIDOW, -16777216, -3407872, new Item.Properties()));
	public static final RegistryObject<Item> SPIDER_FLAT_SPAWN_EGG = REGISTRY.register("spider_flat_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.SPIDER_FLAT, -13434880, -8233401, new Item.Properties()));
	public static final RegistryObject<Item> ANT_GIANT_SPAWN_EGG = REGISTRY.register("ant_giant_spawn_egg", () -> new ForgeSpawnEggItem(MothSpiderDwellerModEntities.ANT_GIANT, -11658983, -14871532, new Item.Properties()));

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
