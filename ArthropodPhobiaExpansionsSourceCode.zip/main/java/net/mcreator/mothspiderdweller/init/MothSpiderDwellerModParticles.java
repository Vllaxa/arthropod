
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.mothspiderdweller.client.particle.ThinWebParticle;
import net.mcreator.mothspiderdweller.client.particle.HeavySmokeParticle;
import net.mcreator.mothspiderdweller.client.particle.CharredBloodParticle;
import net.mcreator.mothspiderdweller.client.particle.CharcoalParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MothSpiderDwellerModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(MothSpiderDwellerModParticleTypes.HEAVY_SMOKE.get(), HeavySmokeParticle::provider);
		event.registerSpriteSet(MothSpiderDwellerModParticleTypes.THIN_WEB.get(), ThinWebParticle::provider);
		event.registerSpriteSet(MothSpiderDwellerModParticleTypes.CHARCOAL.get(), CharcoalParticle::provider);
		event.registerSpriteSet(MothSpiderDwellerModParticleTypes.CHARRED_BLOOD.get(), CharredBloodParticle::provider);
	}
}
