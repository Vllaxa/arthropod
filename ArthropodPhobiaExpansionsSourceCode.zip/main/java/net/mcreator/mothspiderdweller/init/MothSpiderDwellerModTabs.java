
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MothSpiderDwellerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MothSpiderDwellerMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(MothSpiderDwellerModItems.ABYSSAL_BLADE.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(MothSpiderDwellerModItems.SPIDER_MOTH_DWELLER_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.SPIDER_MOTH_LARVAE_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.TELEPORT_GHOST_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.SPIDER_LARVAE_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.SUN_SCORPION_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.LONG_LEGS_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.CENTIPEDE_STALKER_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.MAGGOT_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.BLOOD_WORM_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.WATER_ROACH_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.BEETLE_TICK_MITE_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.SPIDER_BROOD_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.SPIDER_WIDOW_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.SPIDER_FLAT_SPAWN_EGG.get());
			tabData.accept(MothSpiderDwellerModItems.ANT_GIANT_SPAWN_EGG.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MothSpiderDwellerModItems.ABYSSAL_CRYSTAL.get());
			tabData.accept(MothSpiderDwellerModItems.BANE_OF_THE_DARKNESS.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(MothSpiderDwellerModBlocks.MANGLED_SPIDER_FLESH.get().asItem());
		}

		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MothSpiderDwellerModItems.ABYSSAL_PICKAXE.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(MothSpiderDwellerModItems.MAGGOT_GRUB.get());
		}
	}
}
