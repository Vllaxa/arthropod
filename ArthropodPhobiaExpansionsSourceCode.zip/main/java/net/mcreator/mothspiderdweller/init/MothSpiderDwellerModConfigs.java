package net.mcreator.mothspiderdweller.init;

import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.mcreator.mothspiderdweller.configuration.ConfigurationSettingsConfiguration;
import net.mcreator.mothspiderdweller.MothSpiderDwellerMod;

@Mod.EventBusSubscriber(modid = MothSpiderDwellerMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class MothSpiderDwellerModConfigs {
	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ConfigurationSettingsConfiguration.SPEC, "SpiderMothDweller Configuration.toml");
		});
	}
}
