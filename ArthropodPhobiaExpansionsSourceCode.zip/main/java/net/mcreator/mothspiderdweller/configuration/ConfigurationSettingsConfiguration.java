package net.mcreator.mothspiderdweller.configuration;

import net.minecraftforge.common.ForgeConfigSpec;

public class ConfigurationSettingsConfiguration {
	public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
	public static final ForgeConfigSpec SPEC;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DWELLER_REQUIRE_THUNDER;
	public static final ForgeConfigSpec.ConfigValue<Boolean> SPAWN_LARVAE_NATURALLY;
	public static final ForgeConfigSpec.ConfigValue<Boolean> SPAWN_DWELLER_NATURALLY;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DWELLER_INCLUSION;
	public static final ForgeConfigSpec.ConfigValue<Double> DWELLER_FREQUENCY;
	public static final ForgeConfigSpec.ConfigValue<Boolean> DWELLER_HEALTH;
	static {
		BUILDER.push("Spawning");
		DWELLER_REQUIRE_THUNDER = BUILDER.comment("This controls whether the main dweller will require thunderstorm weather to spawn").define("Spawn Rate", true);
		SPAWN_LARVAE_NATURALLY = BUILDER.comment("Do you want the larvae to spawn naturally without needing the dweller to spawn them?").define("Larvae Spawning", true);
		SPAWN_DWELLER_NATURALLY = BUILDER.comment("Do you want the dweller to spawn naturally?").define("Dweller Spawning", true);
		DWELLER_INCLUSION = BUILDER.define("Dweller Inclusion", true);
		DWELLER_FREQUENCY = BUILDER.define("Dweller Rarity", (double) 1);
		BUILDER.pop();
		BUILDER.push("Difficulty");
		DWELLER_HEALTH = BUILDER.comment("By default, the dweller boss has 350 health. Choose true to decrease this to 60 health,").define("Dweller Health", false);
		BUILDER.pop();

		SPEC = BUILDER.build();
	}

}
